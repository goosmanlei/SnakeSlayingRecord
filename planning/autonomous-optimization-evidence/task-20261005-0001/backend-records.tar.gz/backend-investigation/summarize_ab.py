#!/usr/bin/env python3
"""Summarize existing A/B evidence only; sends no requests and reads no business DB."""
import argparse
import json
import math
from pathlib import Path
import statistics


def spread(values):
    ordered=sorted(values);median=statistics.median(ordered)
    quartiles=statistics.quantiles(ordered,n=4,method='inclusive')
    return {'n':len(values),'min':min(values),'max':max(values),'median':median,
            'p95_nearest_rank':ordered[math.ceil(.95*len(values))-1],
            'q1_inclusive':quartiles[0],'q3_inclusive':quartiles[2],
            'mad':statistics.median(abs(value-median) for value in values),'raw':values}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('directory',type=Path);args=parser.parse_args()
    out=args.directory.resolve();http={};rss={}
    rows={label:[json.loads(line) for line in (out/(label+'-http')/'samples.jsonl').read_text().splitlines()]
          for label in ('baseline','candidate')}
    for name in dict.fromkeys(row['name'] for row in rows['baseline']):
        values={label:[row for row in data if row['name']==name and row['phase']=='sample'] for label,data in rows.items()}
        item={label:spread([row['elapsed_ms'] for row in data]) for label,data in values.items()}
        item['saved_median_ms']=item['baseline']['median']-item['candidate']['median']
        item['saved_median_percent']=100*item['saved_median_ms']/item['baseline']['median']
        item['all_statuses']=sorted({row['status'] for data in values.values() for row in data})
        item['json_hashes']={label:sorted({row['json_sha256'] for row in data}) for label,data in values.items()}
        item['raw_body_hashes']={label:sorted({row['body_sha256'] for row in data}) for label,data in values.items()}
        http[name]=item
    for op in ('index','material_list','scene','entity','history'):
        values={label:[json.loads((out/'rss'/f'{op}-{pair}-{label}'/'summary.json').read_text())['samples'][0]
                       for pair in range(1,6)] for label in ('baseline','candidate')}
        rss[op]={field:{label:spread([sample[field] for sample in data]) for label,data in values.items()}
                 for field in ('read_ms','cpu_ms','json_serialize_ms','peak_rss_after_read_bytes','peak_rss_after_serialization_bytes')}
        rss[op]['paired_hash_equal']=[values['baseline'][n]['json_sha256']==values['candidate'][n]['json_sha256'] for n in range(5)]
    result={'statistics':'HTTP 50 samples after 3 warmups; p95 nearest rank, inclusive quartiles, MAD from median. RSS five separate processes per label, pair order alternates.',
            'http':http,'rss':rss}
    (out/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print('HTTP: name medianA medianB saved% p95A p95B IQR_A IQR_B MAD_A MAD_B')
    for name,item in http.items():
        a=item['baseline'];b=item['candidate']
        print(name,*[round(v,3) for v in (a['median'],b['median'],item['saved_median_percent'],a['p95_nearest_rank'],b['p95_nearest_rank'],a['q1_inclusive'],a['q3_inclusive'],b['q1_inclusive'],b['q3_inclusive'],a['mad'],b['mad'])])
    print('RSS: name readA_MiB readB_MiB serializeA_MiB serializeB_MiB CPU_Ams CPU_Bms readAms readBms')
    for name,item in rss.items():
        result=[]
        for field in ('peak_rss_after_read_bytes','peak_rss_after_serialization_bytes','cpu_ms','read_ms'):
            for label in ('baseline','candidate'):
                value=item[field][label]['median'];result.append(round(value/(1048576 if field.endswith('_bytes') else 1),3))
        print(name,*result)


if __name__=='__main__':main()
