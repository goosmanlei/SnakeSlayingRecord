/* Test-only probe. Never shipped with the product. */
(() => {
  'use strict';
  const CONFIRM_MS = 180, TIMEOUT_MS = 60000;
  const samples = [], media = [], resources = [], longtasks = [], requests = [], scrolls = [];
  const responseRequests = new WeakMap();
  const nativeFetch = window.fetch.bind(window), nativeNow = performance.now.bind(performance);
  let sequence = 0, pendingFetches = 0, pendingBodies = 0, active = null;
  let lastMutation = 0, lastNetwork = 0, mutationVersion = 0, timer = null, attempt = 0, deadlineTimer = null;
  const relativeNow = () => nativeNow();
  // Capture content at the measured instant. Scenario assertions are applied
  // to this evidence, never inferred from a screenshot taken afterwards.
  function semanticEvidence() {
    const start = relativeNow();
    const visible = node => {
      if (node.closest('[hidden]') || !node.getClientRects().length) return false;
      const style = getComputedStyle(node);
      return style.visibility !== 'hidden' && style.visibility !== 'collapse';
    };
    const describe = node => ({tag:node.tagName,id:node.id, label:(node.getAttribute('aria-label') || node.textContent || '').trim().slice(0,240),
      value:['SELECT','INPUT','TEXTAREA'].includes(node.tagName)?node.value:undefined,
      selected:node.getAttribute('aria-selected'),pressed:node.getAttribute('aria-pressed'),disabled:node.disabled});
    const regions = [...document.querySelectorAll('#approach-body,#source-view,#structure-reader,#screenplay-reader,#configuration-view,#production-view,#comment-panel,dialog[open],[role="dialog"]')].filter(visible).map(node=>{
      const text=node.textContent || '';
      return {id:node.id,role:node.getAttribute('role'),length:text.length,first:text.slice(0,1400),last:text.slice(-400)};
    });
    const headings = [...document.querySelectorAll('main h1,main h2,main h3,dialog h1,dialog h2,[role="dialog"] h2')].filter(visible).slice(0,100).map(describe);
    const controls = [...document.querySelectorAll('[aria-selected="true"],[aria-pressed="true"],button.active,button.selected,select,input:checked')].filter(visible).slice(0,150).map(describe);
    return {url:location.href,regions,headings,controls,capture_start_ms:start,capture_finished_ms:relativeNow()};
  }
  const summary = element => {
    const target = element instanceof Element ? element : element?.parentElement;
    if (!target) return null;
    const control = target.closest('button,a,input,select,textarea,[role="tab"]') || target;
    return {tag: control.tagName, id: control.id, role: control.getAttribute('role'),
      label: (control.getAttribute('aria-label') || control.textContent || '').trim().slice(0, 160),
      value: ['SELECT', 'INPUT'].includes(control.tagName) ? control.value : undefined};
  };
  const snapshot = () => ({
    schema: 'review-performance-probe-v1', metadata: window.__probeMetadata,
    measurement: {quiet_confirmation_ms: CONFIRM_MS, timeout_ms: TIMEOUT_MS,
      availability_rule: 'last relevant DOM or completed fetch/body + two animation frames, then 180ms unchanged confirmation',
      content_ready_ms_excludes_stability_confirmation: true,
      media_readiness_is_separate: true,
      navigation_requires_complete_load: true,
      navigation_and_interaction_samples_must_not_be_combined: true,
      smooth_scroll_completion: 'trusted scrollend events recorded separately; two animation frames do not imply scroll completion',
      scrollend_supported: 'onscrollend' in window,
      limitation: 'DOM stability is a readiness proxy; operator must verify correct visible content. Image requests appear in resource timing; image decoding, native dialogs, CSS animation completion, and workers are not readiness gates. Media readiness is recorded separately.'},
    browser: {user_agent: navigator.userAgent, viewport: {width: innerWidth, height: innerHeight},
      device_pixel_ratio: devicePixelRatio, visibility: document.visibilityState, time_origin: performance.timeOrigin},
    url: location.href, navigation: performance.getEntriesByType('navigation').map(e => e.toJSON()),
    active: active ? {id: active.id, type: active.type, start_ms: active.start_ms, target: active.target} : null,
    pending: {fetches: pendingFetches, bodies: pendingBodies}, samples, requests, media, resources, longtasks, scrolls,
  });
  function publish() {
    if (!document.documentElement) return;
    let node = document.getElementById('performance-probe-results');
    if (!node) {
      node = document.createElement('script'); node.id = 'performance-probe-results';
      node.type = 'application/json'; node.dataset.performanceProbe = 'true';
      document.documentElement.append(node);
    }
    node.textContent = JSON.stringify(snapshot());
    node.dataset.probeActive = active ? String(active.id) : "none";
    node.dataset.probeCompletion = samples.at(-1)?.completion_reason || "pending";
    node.dataset.probeCount = String(samples.length);
  }
  function finish(reason, readyAt = relativeNow(), semantic = null) {
    if (!active) return;
    const failures = requests.filter(request => request.start_ms >= active.start_ms &&
      (request.status >= 400 || request.error || request.body_error));
    samples.push({...active, end_url: location.href, completion_reason: reason,
      content_ready_at_ms: readyAt, content_ready_ms: Math.max(0, readyAt - active.start_ms),
      stability_confirm_at_ms: relativeNow(), stability_confirm_ms: relativeNow() - active.start_ms,
      last_dom_mutation_at_ms: lastMutation, last_network_at_ms: lastNetwork,
      semantic_at_ready:semantic,
      semantic_capture_ms:semantic?semantic.capture_finished_ms-semantic.capture_start_ms:null,
      scenario_ready_ms:semantic?semantic.capture_finished_ms-active.start_ms:null,
      visibility_at_end: document.visibilityState,
      request_error_count: failures.length,
      failed_requests: failures.map(({url, status, error, body_error}) => ({url, status, error, body_error})),
      pending_at_end: {fetches: pendingFetches, bodies: pendingBodies}});
    active = null; clearTimeout(timer); clearTimeout(deadlineTimer); publish();
  }
  function eligible() {
    if (pendingFetches || pendingBodies) return false;
    if (active?.type === 'navigation' && document.readyState !== 'complete') return false;
    return true;
  }
  function consider() {
    const currentAttempt = ++attempt;
    clearTimeout(timer);
    if (!active) return;
    if (relativeNow() - active.start_ms >= TIMEOUT_MS) { finish('timeout'); return; }
    if (!eligible()) { timer = setTimeout(consider, 40); return; }
    const version = mutationVersion, network = lastNetwork, id = active.id;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      if (!active || active.id !== id || currentAttempt !== attempt) return;
      if (version !== mutationVersion || network !== lastNetwork || !eligible()) { consider(); return; }
      const readyAt = relativeNow();
      const semantic = semanticEvidence();
      timer = setTimeout(() => {
        if (!active || active.id !== id || currentAttempt !== attempt) return;
        if (version !== mutationVersion || network !== lastNetwork || !eligible()) { consider(); return; }
        finish('stable', readyAt, semantic);
      }, CONFIRM_MS);
    }));
  }
  function begin(type, target = null, start = relativeNow()) {
    if (active) finish('superseded_by_' + type);
    active = {id: ++sequence, type, start_ms: start, start_url: location.href,
      target, visibility_at_start: document.visibilityState};
    const node=document.getElementById('performance-probe-results');
    if(node){node.dataset.probeActive=String(active.id);node.dataset.probeCompletion='pending';}
    const id = active.id;
    deadlineTimer = setTimeout(() => { if (active?.id === id) finish('timeout'); }, TIMEOUT_MS);
    consider();
  }
  function networkFinished() { lastNetwork = relativeNow(); consider(); }
  window.fetch = (...args) => {
    const start = relativeNow(), request = {start_ms: start, url: String(args[0]?.url || args[0]), method: args[1]?.method || args[0]?.method || 'GET'};
    requests.push(request); pendingFetches++;
    return nativeFetch(...args).then(response => {
      request.headers_ms = relativeNow(); request.status = response.status;
      responseRequests.set(response, request);
      return response;
    }, error => { request.error = String(error); throw error; })
      .finally(() => { request.fetch_settled_ms = relativeNow(); pendingFetches--; networkFinished(); });
  };
  for (const name of ['json', 'text', 'blob', 'arrayBuffer', 'formData']) {
    const original = Response.prototype[name];
    if (typeof original !== 'function') continue;
    Response.prototype[name] = function (...args) {
      pendingBodies++;
      try {
        const request = responseRequests.get(this);
        return original.apply(this, args).catch(error => { if (request) request.body_error = String(error); throw error; })
          .finally(() => { pendingBodies--; networkFinished(); });
      } catch (error) { pendingBodies--; networkFinished(); throw error; }
    };
  }
  const observer = new MutationObserver(records => {
    const useful = records.some(record => {
      const target = record.target.nodeType === Node.ELEMENT_NODE ? record.target : record.target.parentElement;
      if (target?.closest?.('[data-performance-probe]')) return false;
      if (record.type === 'childList' && [...record.addedNodes, ...record.removedNodes].every(node => node.nodeType === Node.ELEMENT_NODE && node.matches?.('[data-performance-probe]'))) return false;
      return true;
    });
    if (!useful) return;
    mutationVersion++; lastMutation = relativeNow(); consider();
  });
  observer.observe(document, {subtree: true, childList: true, characterData: true, attributes: true,
    attributeFilter: ['hidden', 'class', 'aria-pressed', 'aria-expanded', 'aria-busy', 'aria-selected', 'src', 'open', 'disabled', 'value', 'style']});
  for (const type of ['click', 'change', 'input']) document.addEventListener(type, event => {
    if (!event.isTrusted || event.target?.closest?.('[data-performance-probe]')) return;
    const raw = event.timeStamp;
    const start = raw > performance.timeOrigin ? raw - performance.timeOrigin : raw;
    begin(type, summary(event.target), start);
  }, true);
  for (const type of ['loadedmetadata', 'loadeddata', 'canplay', 'playing', 'waiting', 'error']) {
    document.addEventListener(type, event => {
      if (!(event.target instanceof HTMLMediaElement)) return;
      media.push({type, at_ms: relativeNow(), current_src: event.target.currentSrc,
        ready_state: event.target.readyState, network_state: event.target.networkState,
        duration: Number.isFinite(event.target.duration) ? event.target.duration : null,
        current_time: event.target.currentTime, action_id: active?.id ?? samples.at(-1)?.id ?? null});
      if (!active) publish();
    }, true);
  }
  document.addEventListener('scrollend', event => {
    if (!event.isTrusted) return;
    const target = event.target === document ? document.scrollingElement : event.target;
    const at = relativeNow(), last = active || samples.at(-1);
    scrolls.push({at_ms: at, action_id: last?.id ?? null,
      elapsed_since_action_ms: last ? at - last.start_ms : null,
      target: {tag: target?.tagName, id: target?.id},
      scroll_top: target?.scrollTop, scroll_left: target?.scrollLeft});
    if (!active) publish();
  }, true);
  for (const type of ['resource', 'longtask']) {
    try {
      new PerformanceObserver(list => {
        const destination = type === 'resource' ? resources : longtasks;
        destination.push(...list.getEntries().map(entry => entry.toJSON()));
      }).observe({type, buffered: true});
    } catch (error) { (window.__probeMetadata.unsupported_observers ||= []).push({type, error: String(error)}); }
  }
  window.addEventListener('load', consider);
  window.addEventListener('pageshow', publish);
  document.addEventListener('visibilitychange', publish);
  begin('navigation', null, 0);
  publish();
})();
