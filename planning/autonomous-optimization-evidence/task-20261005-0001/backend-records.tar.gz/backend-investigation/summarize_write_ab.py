#!/usr/bin/env python3
"""Read saved write measurements only; no product import, requests, or DB writes."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import statistics


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stat(values):
    assert values
    values=list(values)
    q=statistics.quantiles(values,n=4,method='inclusive') if len(values)>1 else [values[0]]*3
    median=statistics.median(values)
    return {'n':len(values),'values':values,'minimum':min(values),'median':median,'maximum':max(values),
            'q1':q[0],'q3':q[2],'mad':statistics.median(abs(x-median) for x in values)}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('run',type=Path)
    args=parser.parse_args();run=args.run
    receipt=json.loads((run/'receipt.json').read_text());environment=json.loads((run/'environment.json').read_text())
    assert receipt['error'] is None and receipt['completed']==['baseline','candidate']
    assert receipt['source_unchanged'] and receipt['systems_unchanged'] and receipt['fixed_payloads_equal'] and receipt['deterministic_business_state_equal']
    result={'environment':environment,'receipt_checks_passed':True,'arms':{},'comparison':{},
        'timing_note':'No sums of explicit_commit and context_commit: on the measured Python 3.9.6 these overlap. transaction_boundary_ms chooses outer context_commit if present, otherwise explicit_commit. No claim of complete SQL time.',
        'limitations':['one sequential warm-cache A/B window','five formal samples per write operation','synthetic entity without media requirements','single-thread HTTPServer competition, not multi-writer SQLite','configuration new event count verified; event payload bodies not captured in request-loop snapshots'],
        'timestamp_omissions':['project.updated_at','comments[].created_at','comments[].updated_at','comment_events[].at','decision.created_at','decision.updated_at','decision_history[].created_at'],
        'raw_file_sha256':{}}
    operations=('comment-create','comment-edit','configuration-save','entity-accept','entity-revoke')
    for arm in ('baseline','candidate'):
        evidence=run/arm/'evidence';requests=json.loads((evidence/'requests.json').read_text())
        logs=[json.loads(x) for x in (evidence/'server-metrics.jsonl').read_text().splitlines()]
        metrics={r['request_id']:r for r in logs};assert len(metrics)==len(logs)==len(requests)==93
        assert all(metrics[r['request_id']]['status']==r['status'] for r in requests)
        fixture=json.loads((evidence/'fixture.json').read_text());audit=json.loads((evidence/'preservation-audit.json').read_text())
        assert len([k for k in audit if k not in ('project_other_fields','foreign_keys')])==23
        assert all(not row.get('unexpected_new_or_modified') and not row.get('missing_or_modified_original') for row in audit.values())
        assert audit['project_other_fields']['equal'] and audit['foreign_keys']['violations']==[]
        final=json.loads((evidence/'final-state.json').read_text());comments={r['id']:r for r in final['comments']}
        for i in range(6):
            cid='ao-write-fixture-comment-'+str(i)
            events=[r for r in final['comment_events'] if r['comment_id']==cid]
            assert [r['action'] for r in events]==(['CREATE','EDIT','EDIT'] if i==5 else ['CREATE','EDIT'])
            assert events[0]['body']=='隔离性能评论 '+str(i)
            assert events[1]['body']=='隔离性能评论 '+str(i)+' 已编辑'
            assert events[-1]['body']==comments[cid]['body']
            assert comments[cid]['status']=='OPEN' and comments[cid]['anchor']=={'type':'global'}
            assert comments[cid]['target_revision_id']==fixture['comment_target']['target_revision_id']
        assert [r['payload']['verdict'] for r in final['decision_history']]==['accepted','revoked']*6
        arm_result={'requests':len(requests),'statuses':dict(collections.Counter(r['status'] for r in requests)),
            'samples':{},'conflicts':{},'fixture':fixture,'preservation_tables':23,
            'saved_comment_actions_bodies_and_anchors_checked':True,'decision_history_sequence_checked':True}
        for operation in operations:
            rows=[r for r in requests if r['name']==operation and r['phase']=='sample'];assert len(rows)==5
            assert len([r for r in requests if r['name']==operation and r['phase']=='warmup'])==1
            ms=[metrics[r['request_id']] for r in rows]
            assert all(len(m['logical'])==1 for m in ms)
            values={'http_ms':[r['elapsed_ms'] for r in rows],'handler_ms':[m['handler_ms'] for m in ms],
                'logical_ms':[m['logical'][0]['elapsed_ms'] for m in ms],
                'sql_write_execute_ms':[m.get('sql_write_execute_ms',0) for m in ms],
                'sql_other_execute_ms':[m.get('sql_other_execute_ms',0) for m in ms],
                'explicit_commit_ms':[m.get('explicit_commit_ms',0) for m in ms],
                'context_commit_ms':[m.get('context_commit_ms',0) for m in ms],
                'transaction_boundary_ms':[m['context_commit_ms'] if m.get('context_commit_calls') else m.get('explicit_commit_ms',0) for m in ms]}
            sample={key:stat(value) for key,value in values.items()}
            sample['raw_request_ids']=[r['request_id'] for r in rows]
            sample['sql_write_execute_calls']=[m.get('sql_write_execute_calls',0) for m in ms]
            sample['explicit_commit_calls']=[m.get('explicit_commit_calls',0) for m in ms]
            sample['context_commit_calls']=[m.get('context_commit_calls',0) for m in ms]
            # All measured paths have either one standalone explicit commit or
            # one context exit and its nested commit. The boundary is narrower
            # than the Store logic and therefore cannot double count the commit.
            assert all(v<=m['logical'][0]['elapsed_ms'] for v,m in zip(values['transaction_boundary_ms'],ms))
            arm_result['samples'][operation]=sample
        for name in ('comment-stale','configuration-stale','entity-accept-stale','entity-revoke-stale'):
            rows=[r for r in requests if r['name']==name];assert len(rows)==6 and all(r['status']==409 for r in rows)
            arm_result['conflicts'][name]=stat(r['elapsed_ms'] for r in rows)
        for prefix in ('comment-competing-','configuration-competing-'):
            rows=[r for r in requests if r['name'].startswith(prefix)]
            assert len(rows)==2 and sorted(r['status'] for r in rows)==[200,409]
        result['arms'][arm]=arm_result
        for name in ('requests.json','server-metrics.jsonl','fixture.json','initial-state.json','final-state.json','deterministic-state.json','preservation-audit.json'):
            p=evidence/name;result['raw_file_sha256'][str(p.relative_to(run))]=digest(p)
    for name in operations:
        b=result['arms']['baseline']['samples'][name]['http_ms'];c=result['arms']['candidate']['samples'][name]['http_ms']
        result['comparison'][name]={'baseline_median_ms':b['median'],'candidate_median_ms':c['median'],
            'candidate_minus_baseline_ms':c['median']-b['median'],
            'median_reduction_percent':100*(b['median']-c['median'])/b['median'],
            'full_ranges_overlap':max(b['minimum'],c['minimum'])<=min(b['maximum'],c['maximum'])}
    (run/'comparison.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result['comparison'],ensure_ascii=False,indent=2))


if __name__=='__main__':main()
