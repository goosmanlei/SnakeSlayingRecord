#!/usr/bin/env python3
"""Task-only read-only adapter around the unchanged page probe; run one stage."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import sqlite3
import subprocess
import sys
import time
from http.server import HTTPServer

HERE = Path(__file__).resolve().parent
TASK = HERE.parents[2]
EXPECTED_DB = '5c6d00ee6efa7506201bbef46ffd69bde49f7300c4697fe66036e87ace7ed4f0'
EXPECTED_PROBE = '74a80b7f730a450f4fc00f5424120f8f60406e7fe9c4c65234e3d317958a804c'
COMMITS = {'A': 'b874b959af9c918a482e8488dc25cb0204ab5772',
           'B': '3b20d609448365103ebcf381776e33869913fe8b'}
T0 = 1791177710.0


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_sha(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


def guard():
    result = subprocess.run([sys.executable, str(TASK / 'scripts/autonomous_optimization_guard.py'),
                             'check'], cwd=TASK, capture_output=True, text=True, timeout=20)
    if result.returncode:
        raise RuntimeError('guard check failed; inspect guard locally, raw lease is not exported')
    value = json.loads(result.stdout)
    safe = {key: value.get(key) for key in ('task_id', 't0', 'phase', 'watcher')}
    watcher = value.get('watcher') or {}
    if (value.get('task_id') != 'task-20261005-0001' or value.get('t0') != T0
            or value.get('phase') != 'armed' or not watcher.get('supervision_confirmed')
            or not watcher.get('lock_held') or not watcher.get('running')
            or watcher.get('last_error') or time.time() >= T0 + 9 * 3600):
        raise RuntimeError('guard not armed/supervised for this reset window')
    return safe


def identity(system, instance):
    db = instance / '.runtime/review.sqlite3'
    sidecars = [str(db) + suffix for suffix in ('-wal', '-shm', '-journal')
                if Path(str(db) + suffix).exists()]
    if sidecars:
        raise RuntimeError('frozen input has SQLite sidecars')
    commit = subprocess.check_output(['git', '-C', str(system), 'rev-parse', 'HEAD'], text=True).strip()
    dirty = subprocess.check_output(['git', '-C', str(system), 'status', '--porcelain', '--',
                                      'review_desk'], text=True)
    code_files = sorted(path for path in (system / 'review_desk').rglob('*')
                        if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc')
    # No whole-media reread: prior original-preservation evidence remains authoritative.
    # Name/size/mtime detects ordinary changes; it is not proof of all original bytes.
    inputs = []
    for path in sorted(instance.rglob('*')):
        if not path.is_file() or '.runtime' in path.relative_to(instance).parts:
            continue
        stat = path.stat()
        inputs.append({'path': path.relative_to(instance).as_posix(), 'bytes': stat.st_size,
                       'mtime_ns': stat.st_mtime_ns, 'symlink': path.is_symlink()})
    return {'database_sha256': sha(db), 'database_bytes': db.stat().st_size,
            'probe_sha256': sha(HERE / 'probe.js'), 'probe_server_sha256': sha(HERE / 'probe_server.py'),
            'adapter_sha256': sha(Path(__file__)), 'system_commit': commit, 'product_dirty': dirty,
            'product_tree_sha256': canonical_sha([(str(p.relative_to(system)), sha(p)) for p in code_files]),
            'instance_config_sha256': sha(instance / 'config/instance.json'),
            'input_metadata_sha256': canonical_sha(inputs), 'input_file_count': len(inputs),
            'input_metadata_limitation': 'name/size/mtime only; no new whole-media byte verification'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', required=True, choices=['A1', 'B1', 'A2', 'B2'])
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--max-seconds', default=1800, type=int)
    args = parser.parse_args()
    if not 1 <= args.max_seconds <= 1800:
        parser.error('max-seconds must be 1..1800')
    system = HERE.parent / ('system-baseline' if args.stage.startswith('A') else 'system-worktree')
    instance = HERE.parent / 'preview'
    output = args.output.resolve()
    if HERE not in output.parents or output.exists():
        parser.error('output must be a new directory inside backend-investigation')
    safe_guard = guard()
    before = identity(system, instance)
    if (before['database_sha256'] != EXPECTED_DB or before['probe_sha256'] != EXPECTED_PROBE
            or before['system_commit'] != COMMITS[args.stage[0]] or before['product_dirty']):
        raise RuntimeError('frozen database, probe or exact clean candidate identity changed')
    output.mkdir(parents=True)
    def save(name, value):
        (output / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    save('identity-before.json', before)
    save('guard-before.json', safe_guard)
    sys.path.insert(0, str(system))
    from review_desk import server as product_server
    from review_desk.store import Store
    from review_desk.material_storage import row_factory

    class ReadOnlyHandler(product_server.ReviewHandler):
        def do_POST(self):
            self.close_connection = True
            return self._json({'error': 'measurement instance is read-only'}, 405)
        do_PATCH = do_POST
        def do_PUT(self):
            return self.do_POST()
        def do_DELETE(self):
            return self.do_POST()

    class ReadOnlyServer(product_server.ReviewServer):
        def __init__(self, address, instance_root, config):
            HTTPServer.__init__(self, address, ReadOnlyHandler)
            self.root, self.config = Path(instance_root).resolve(), config
            self.store = Store.__new__(Store)
            self.store.db_path = self.root / '.runtime/review.sqlite3'
            self.store.db = sqlite3.connect(self.store.db_path.as_uri() + '?mode=ro&immutable=1', uri=True)
            self.store.db.execute('PRAGMA query_only=ON')
            self.store.db.execute('PRAGMA foreign_keys=ON')
            self.store.db.row_factory = row_factory(self.store)

    product_server.ReviewHandler, product_server.ReviewServer = ReadOnlyHandler, ReadOnlyServer
    import probe_server
    receipt = {'stage': args.stage, 'pid': os.getpid(), 'port': 62606,
               'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
               'stop_signal': None, 'error': None, 'identity_unchanged': None}
    save('process.json', receipt)
    def stop(signum, frame):
        receipt['stop_signal'] = signum
        raise KeyboardInterrupt
    for signum in (signal.SIGINT, signal.SIGTERM, signal.SIGALRM):
        signal.signal(signum, stop)
    signal.alarm(max(1, min(args.max_seconds, int(T0 + 9 * 3600 - time.time()))))
    sys.argv = ['probe_server.py', '--system', str(system), '--instance', str(instance),
                '--port', '62606', '--label', 'page-final-' + args.stage, '--output', str(output)]
    try:
        probe_server.main()
    except KeyboardInterrupt:
        if receipt['stop_signal'] == signal.SIGALRM:
            receipt['error'] = 'stage time limit reached; samples require explicit completion review'
    except BaseException as exc:
        receipt['error'] = type(exc).__name__ + ': ' + str(exc)
        raise
    finally:
        signal.alarm(0)
        try:
            after = identity(system, instance)
            save('identity-after.json', after)
            receipt['identity_unchanged'] = before == after
            save('guard-after.json', guard())
        except BaseException as exc:
            receipt['final_check_error'] = type(exc).__name__ + ': ' + str(exc)
        receipt['finished_at_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        save('receipt.json', receipt)


if __name__ == '__main__':
    main()
