#!/usr/bin/env python3
"""Task-only writable probe. Never use with an existing or shared instance."""
import argparse
import functools
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import time
from urllib.parse import urlsplit

PREFIX='ao-write-fixture-'
ENTITY=PREFIX+'entity'
ACTIVE=None


def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))


class TimedConnection(sqlite3.Connection):
    def _timed(self,category,call,*args,**kwargs):
        metric=ACTIVE
        if metric is None:return call(*args,**kwargs)
        started=time.perf_counter()
        try:return call(*args,**kwargs)
        finally:
            elapsed=(time.perf_counter()-started)*1000
            metric[category+'_ms']=metric.get(category+'_ms',0)+elapsed
            metric[category+'_calls']=metric.get(category+'_calls',0)+1

    def execute(self,sql,*args,**kwargs):
        verb=sql.lstrip().split(None,1)[0].upper()
        category='sql_write_execute' if verb in ('INSERT','UPDATE','DELETE','REPLACE') else 'sql_other_execute'
        return self._timed(category,super().execute,sql,*args,**kwargs)

    def executemany(self,sql,*args,**kwargs):
        verb=sql.lstrip().split(None,1)[0].upper()
        category='sql_write_execute' if verb in ('INSERT','UPDATE','DELETE','REPLACE') else 'sql_other_execute'
        return self._timed(category,super().executemany,sql,*args,**kwargs)

    def commit(self):return self._timed('explicit_commit',super().commit)
    def rollback(self):return self._timed('explicit_rollback',super().rollback)

    def __exit__(self,*args):
        # CPython Connection.__exit__ performs COMMIT/ROLLBACK in C and does not
        # delegate to the Python commit override. Keep a separate, honest metric.
        category=('context_rollback' if args[0] else 'context_commit') if self.in_transaction else 'context_no_transaction'
        return self._timed(category,super().__exit__,*args)


def logical(name,function):
    @functools.wraps(function)
    def call(*args,**kwargs):
        metric=ACTIVE;started=time.perf_counter()
        try:return function(*args,**kwargs)
        finally:
            elapsed=(time.perf_counter()-started)*1000
            if metric is not None:metric.setdefault('logical',[]).append({'name':name,'elapsed_ms':elapsed})
    return call


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--system',type=Path,required=True)
    parser.add_argument('--instance',type=Path,required=True)
    parser.add_argument('--evidence',type=Path,required=True)
    args=parser.parse_args();here=Path(__file__).resolve().parent
    instance=args.instance.absolute();evidence=args.evidence.absolute();dbpath=instance/'.runtime/review.sqlite3'
    allowed=here/'write-ab'
    if allowed.resolve()!=allowed or instance.resolve()!=instance or evidence.resolve()!=evidence:
        parser.error('measurement paths must not pass through symlinks')
    if not instance.is_relative_to(allowed) or not evidence.is_relative_to(allowed):
        parser.error('only backend-investigation/write-ab descendants are allowed')
    if not dbpath.is_file() or dbpath.is_symlink() or dbpath.resolve()!=dbpath:
        parser.error('an ordinary independent database copy is required')
    marker=json.loads((instance/'isolated-write-copy.json').read_text())
    source=Path(marker['origin'])
    if source.resolve()!=source or not source.is_file() or source.stat().st_ino==dbpath.stat().st_ino:
        parser.error('database must be independent of the ordinary source snapshot')
    if marker.get('database_sha256')!=hashlib.sha256(dbpath.read_bytes()).hexdigest():
        parser.error('initial independent-copy hash mismatch')
    sys.path.insert(0,str(args.system.resolve()))
    from review_desk.store import Store
    from review_desk import production as p,generation as g
    from review_desk.server import ReviewHandler,ReviewServer
    real_connect=sqlite3.connect
    sqlite3.connect=lambda *a,**kw:real_connect(*a,**dict(kw,factory=TimedConnection))
    store=Store(dbpath)
    # Startup alone may initialize schema. All fixture preparation is outside
    # any request/timing sample and uses the original supported write methods.
    if store.db.execute('SELECT 1 FROM objects WHERE id LIKE ?',(PREFIX+'%',)).fetchone():
        raise RuntimeError('fixture namespace already exists')
    episode_id=PREFIX+'episode'
    episode=store.put_object(episode_id,'EPISODE',{'title':'隔离性能测试片段，非故事正文',
        'blocks':[{'id':'note','text':'仅用于隔离保存性能测试，无创作含义。'}],
        'scenes':[{'id':'scene','block_ids':['note']}]})
    source={'object_id':episode_id,'revision_id':episode['revision'],'scene_id':'scene','block_ids':['note']}
    def spec(oid,kind,fields):
        return {'object_id':oid,'kind':kind,'expected_version':0,'payload':{
            'format':'production-'+p.KINDS[kind]+'-v1','title':oid,
            'blocks':[{'id':'note','text':'隔离性能技术测试，非作品认可'}],**fields}}
    entity=spec(ENTITY,'ENTITY',{'entity_type':'prop','subtype':'test','aliases':[],
        'facts':['仅技术 fixture'],'choices':[],'unknowns':[],'sources':[source],
        'production_description':'仅作隔离数据验证的合成物体。'})
    er=p.import_records(store,{'format':'production-import-v1','records':[entity]})['records'][0]
    state=spec(PREFIX+'state','STATE',{'entity':{'object_id':ENTITY,'revision_id':er['revision']},
        'state_model':'complete-v1','dimensions':{'structure':'测试结构','condition':'测试状态','contents':'测试内容','placement':'测试位置'},
        'reference_media':'none','sources':[source],'facts':[],'choices':[],'unknowns':[],
        'production_description':'只出现于测试数据库的完整状态。'})
    p.import_records(store,{'format':'production-import-v1','records':[state]})
    # Global comments are supported on production objects, not plain EPISODE.
    # Validate the exact public contract before the service reports ready.
    comment_target={'target_object_id':ENTITY,'target_revision_id':er['revision']}
    store.validate_target(ENTITY,er['revision'],{'type':'global'})
    fixture={'entity_id':ENTITY,'decision_id':g.decision_id(ENTITY),
        'comment_target':comment_target,'comment_anchor_validated':True,
        'fixture_object_ids':[episode_id,ENTITY,PREFIX+'state'],
        'fixture_sha256':hashlib.sha256(canonical([entity,state]).encode()).hexdigest(),
        'initial_project':store.configuration('PROJECT'),
        'journal_mode':store.db.execute('PRAGMA journal_mode').fetchone()[0],
        'synchronous':store.db.execute('PRAGMA synchronous').fetchone()[0]}
    (evidence/'fixture.json').write_text(json.dumps(fixture,ensure_ascii=False,indent=2)+'\n')
    for name in ('create_comment','change_comment','set_configuration'):
        setattr(store,name,logical(name,getattr(store,name)))
    g.decide=logical('generation.decide',g.decide)
    metrics=(evidence/'server-metrics.jsonl').open('a',buffering=1)

    class Handler(ReviewHandler):
        def log_message(self,*args):pass

        def _input(self,*args,**kwargs):
            value=super()._input(*args,**kwargs)
            if self.command=='POST' and self.path=='/api/comments':
                if not str(value.get('id','')).startswith(PREFIX) or value.get('target_object_id')!=ENTITY or value.get('target_revision_id')!=er['revision'] or value.get('anchor')!={'type':'global'}:
                    raise ValueError('probe only permits exact fixture comment targets')
            if self.path=='/api/production/entity-decision':
                if value.get('entity_id')!=ENTITY or value.get('actor')!='隔离性能技术测试':
                    raise ValueError('probe only permits synthetic fixture decisions')
            if self.path=='/api/configurations/PROJECT' and set(value.get('updates',{}))!={'audience'}:
                raise ValueError('probe configuration allowlist permits audience only')
            return value

        def send_response(self,status,*args,**kwargs):
            if ACTIVE is not None:ACTIVE['status']=status
            return super().send_response(status,*args,**kwargs)

        def measured(self,call):
            global ACTIVE
            metric={'request_id':self.headers.get('X-Measurement-Id'),'method':self.command,'path':self.path}
            ACTIVE=metric;started=time.perf_counter()
            try:return call()
            except BaseException as exc:
                metric['exception']=type(exc).__name__;raise
            finally:
                metric['handler_ms']=(time.perf_counter()-started)*1000
                ACTIVE=None
                # All JSON formatting and log writes are outside measured work.
                metrics.write(json.dumps(metric,ensure_ascii=False)+'\n')

        def do_GET(self):
            path=urlsplit(self.path).path
            if path not in ('/api/instance','/api/comments','/api/configurations','/api/production/entity-review','/api/production'):
                return self._json({'error':'measurement GET allowlist'},405)
            return self.measured(super().do_GET)

        def do_POST(self):
            if self.path not in ('/api/comments','/api/production/entity-decision'):
                return self._json({'error':'measurement POST allowlist'},405)
            return self.measured(super().do_POST)

        def do_PATCH(self):
            if self.path!='/api/configurations/PROJECT' and not self.path.startswith('/api/comments/'+PREFIX):
                return self._json({'error':'measurement PATCH allowlist'},405)
            return self.measured(super().do_PATCH)

        def do_PUT(self):return self._json({'error':'measurement write blocked'},405)
        do_DELETE=do_PUT

    from http.server import HTTPServer
    server=ReviewServer.__new__(ReviewServer)
    HTTPServer.__init__(server,('127.0.0.1',62607),Handler)
    server.root=instance;server.config={'id':'isolated-write-probe','title':'隔离写性能测试'};server.store=store
    (evidence/'ready.json').write_text(json.dumps({'port':62607,'database':str(dbpath),'fixture':fixture},ensure_ascii=False)+'\n')
    try:server.serve_forever()
    finally:server.server_close();metrics.close()


if __name__=='__main__':main()
