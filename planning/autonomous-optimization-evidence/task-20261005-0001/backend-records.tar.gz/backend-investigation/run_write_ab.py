#!/usr/bin/env python3
"""Assigned-window write A/B on two disposable copies; never a product tool."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from datetime import datetime
import hashlib
import itertools
import json
import os
from pathlib import Path
import platform
import shutil
import signal
import socket
import sqlite3
import subprocess
import sys
import threading
import time
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import ProxyHandler,Request,build_opener

PREFIX='ao-write-fixture-'
SOURCE_SHA='5c6d00ee6efa7506201bbef46ffd69bde49f7300c4697fe66036e87ace7ed4f0'
GUARD_T0=datetime.fromisoformat('2026-10-05T13:21:50+08:00').timestamp()


def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def connection(path):
    db=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
    db.execute('PRAGMA query_only=ON');return db


def db_state(path,fixture):
    # Each call uses a new read-only connection, not the server transaction.
    with closing(connection(path)) as db:
        saved=db.execute("SELECT * FROM configurations WHERE scope='PROJECT'").fetchone()
        project=dict(saved) if saved else dict(fixture['initial_project'])
        if saved:project['body']=json.loads(project['body'])
        comments=[dict(r) for r in db.execute('SELECT * FROM comments WHERE id LIKE ? ORDER BY id',(PREFIX+'%',))]
        for row in comments:row['anchor']=json.loads(row['anchor'])
        events=[dict(r) for r in db.execute('SELECT * FROM comment_events WHERE comment_id LIKE ? ORDER BY id',(PREFIX+'%',))]
        decision=db.execute('SELECT * FROM objects WHERE id=?',(fixture['decision_id'],)).fetchone()
        history=[dict(r) for r in db.execute('SELECT * FROM revisions WHERE object_id=? ORDER BY version',(fixture['decision_id'],))]
        for row in history:row['payload']=json.loads(row['payload'])
        return {'project':project,'configuration_event_count':db.execute("SELECT COUNT(*) FROM configuration_events WHERE scope='PROJECT'").fetchone()[0],
                'comments':comments,'comment_events':events,'decision':dict(decision) if decision else None,'decision_history':history}


def deterministic_state(state):
    # Exact, explicitly documented omissions; do not recursively drop fields
    # from business payloads merely because they resemble metadata.
    value=json.loads(canonical(state))
    value['project'].pop('updated_at',None)
    for row in value['comments']:
        for key in ('created_at','updated_at'):row.pop(key,None)
    for row in value['comment_events']:row.pop('at',None)
    if value['decision']:
        for key in ('created_at','updated_at'):value['decision'].pop(key,None)
    for row in value['decision_history']:row.pop('created_at',None)
    return value


def audit_preserved(source,path,fixture):
    with closing(connection(path)) as db:
        db.execute('ATTACH DATABASE ? AS original',(source.as_uri()+'?mode=ro',))
        tables=[r[0] for r in db.execute("SELECT name FROM original.sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        ids=[*fixture['fixture_object_ids'],fixture['decision_id']]
        marks=','.join('?' for _ in ids)
        filters={'objects':(f'id NOT IN ({marks})',ids),'revisions':(f'object_id NOT IN ({marks})',ids),
            'dependencies':(f'from_revision NOT IN (SELECT id FROM main.revisions WHERE object_id IN ({marks}))',ids),
            'comments':('id NOT LIKE ?',[PREFIX+'%']),'comment_events':('comment_id NOT LIKE ?',[PREFIX+'%']),
            'configurations':("scope!='PROJECT'",[]),
            'configuration_events':("id <= (SELECT COALESCE(MAX(id),0) FROM original.configuration_events)",[])}
        results={}
        for table in tables:
            where,args=filters.get(table,('1=1',[]));quoted='"'+table.replace('"','""')+'"'
            left=f'SELECT * FROM main.{quoted} WHERE {where}'
            right=f'SELECT * FROM original.{quoted} WHERE {where}'
            extra=db.execute(f'SELECT * FROM ({left} EXCEPT {right}) LIMIT 1',args+args).fetchone()
            missing=db.execute(f'SELECT * FROM ({right} EXCEPT {left}) LIMIT 1',args+args).fetchone()
            results[table]={'unexpected_new_or_modified':extra is not None,'missing_or_modified_original':missing is not None}
        saved=db.execute("SELECT body FROM original.configurations WHERE scope='PROJECT'").fetchone()
        original_project=json.loads(saved[0]) if saved else fixture['initial_project']['body']
        final_project=json.loads(db.execute("SELECT body FROM main.configurations WHERE scope='PROJECT'").fetchone()[0])
        results['project_other_fields']={'equal':{k:v for k,v in original_project.items() if k!='audience'}=={k:v for k,v in final_project.items() if k!='audience'}}
        results['foreign_keys']={'violations':[tuple(row) for row in db.execute('PRAGMA foreign_key_check')]}
        assert all(not row.get('unexpected_new_or_modified') and not row.get('missing_or_modified_original') for row in results.values()),results
        assert results['project_other_fields']['equal'] and not results['foreign_keys']['violations'],results
        return results


def main():
    started=time.monotonic();started_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    parser=argparse.ArgumentParser();parser.add_argument('--output-name',required=True)
    parser.add_argument('--max-seconds',type=int,default=180)
    parser.add_argument('--candidate-commit',default='e91c57a4a1136e55946d4a2a6377949a932a76fa')
    args=parser.parse_args();here=Path(__file__).resolve().parent;root=here.parent
    if Path(args.output_name).name!=args.output_name or not 30<=args.max_seconds<=180:parser.error('plain output name, 30..180 seconds only')
    out=here/'write-ab'/args.output_name
    if out.absolute()!=out.resolve():parser.error('measurement paths must not pass through symlinks')
    if out.exists():parser.error('never overwrite prior evidence/copies')
    out.mkdir(parents=True)
    source=root/'preview/.runtime/generation-base.sqlite3'
    if not source.is_file() or source.is_symlink() or source.absolute()!=source.resolve():parser.error('ordinary immutable source required')
    systems={'baseline':root/'system-baseline','candidate':root/'system-worktree'}
    expected={'baseline':'b874b959af9c918a482e8488dc25cb0204ab5772','candidate':args.candidate_commit}
    def fingerprint(system):return {'head':subprocess.check_output(['git','-C',str(system),'rev-parse','HEAD'],text=True,timeout=2).strip(),
        'python_sources':{str(p.relative_to(system)):sha(p) for p in sorted((system/'review_desk').glob('*.py'))}}
    deadline=started+args.max_seconds;before=None
    metadata={'started_at_utc':started_at_utc,'max_seconds':args.max_seconds,
        'source':str(source),'source_sha256':SOURCE_SHA,'warmups':1,'samples':5,'http_order':['baseline','candidate'],
        'python':platform.python_version(),'machine':platform.platform(),'database_bytes':source.stat().st_size,
        'cache_state':'OS cache not flushed; new server per arm; one operation warmup; sequential baseline then candidate',
        'tools':{p:sha(here/p) for p in ('run_write_ab.py','write_probe_server.py')},
        'timing':'HTTP complete body; handler; logical Store; sqlite write execute and active-transaction commit/context-exit separately. No-transaction context exits are separate. Execute excludes later cursor fetching; SQL categories do not sum to complete DB time. Instrumentation overhead present in both arms.',
        'database_mode':'independent disposable writable copies; original never opened for write'}
    dump(out/'environment.json',metadata)
    report={'completed':[],'error':None};server=None
    stopped=threading.Event()
    def hard_limit():
        if stopped.wait(max(0,deadline-time.monotonic())):return
        # Emergency fallback if a library call or cleanup ignores normal timeouts.
        # Only the server created by this process is in scope. Preserve a small
        # separate terminal receipt rather than falsifying the ordinary audit.
        if server is not None and server.poll() is None:
            try:server.kill()
            except ProcessLookupError:pass
        dump(out/'hard-deadline.json',{'reason':'180-second assigned window exhausted','elapsed_seconds':time.monotonic()-started,
            'completed':report['completed'],'cleanup_and_final_audits_complete':False,'owned_server_pid':server.pid if server else None})
        os._exit(75)
    threading.Thread(target=hard_limit,daemon=True).start()
    def timeout(*_):raise TimeoutError('assigned write window reached cleanup reserve')
    signal.signal(signal.SIGALRM,timeout);signal.setitimer(signal.ITIMER_REAL,max(.001,deadline-time.monotonic()-10))
    def remaining():
        left=deadline-time.monotonic()
        if left<=20:raise TimeoutError('reserving final 20 seconds for server stop and receipts')
        return left
    try:
        before={label:fingerprint(path) for label,path in systems.items()}
        assert all(before[k]['head']==v for k,v in expected.items()),before
        assert sha(source)==SOURCE_SHA,'immutable source SHA mismatch'
        metadata['systems']=before;dump(out/'environment.json',metadata)
        guard=subprocess.check_output([sys.executable,'scripts/autonomous_optimization_guard.py','check'],cwd=root.parent.parent,text=True,timeout=min(10,remaining()))
        dump(out/'guard-before.json',json.loads(guard));status=json.loads(guard)
        assert status['phase']=='armed' and status['stop'] is None and status['watcher']['lock_held'] and status['watcher']['supervision_confirmed']
        assert status['task_id']=='task-20261005-0001' and status['t0']==GUARD_T0, 'wrong task or reset timing epoch'
        metadata['guard_t0']=status['t0'];metadata['guard_root_thread_id']=status['root_thread_id'];dump(out/'environment.json',metadata)
        fixture_hashes={};request_vectors={};deterministic_states={}
        for label,system in systems.items():
            remaining();base=out/label;instance=base/'instance';evidence=base/'evidence';evidence.mkdir(parents=True)
            (instance/'.runtime').mkdir(parents=True);(instance/'export/assets').mkdir(parents=True)
            database=instance/'.runtime/review.sqlite3';shutil.copyfile(source,database)
            assert database.stat().st_ino!=source.stat().st_ino and sha(database)==SOURCE_SHA
            dump(instance/'isolated-write-copy.json',{'database_sha256':SOURCE_SHA,'origin':str(source)})
            check=socket.socket()
            try:check.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);check.bind(('127.0.0.1',62607))
            finally:check.close()
            log=(evidence/'server.log').open('w')
            server=subprocess.Popen([sys.executable,str(here/'write_probe_server.py'),'--system',str(system),'--instance',str(instance),'--evidence',str(evidence)],stdout=log,stderr=log)
            readiness_deadline=time.monotonic()+min(20,remaining())
            while not (evidence/'ready.json').exists():
                if server.poll() is not None:raise RuntimeError('write probe startup failed: '+label)
                if time.monotonic()>readiness_deadline:raise TimeoutError('write probe startup timeout')
                time.sleep(.05)
            fixture=json.loads((evidence/'fixture.json').read_text());fixture_hashes[label]=fixture['fixture_sha256']
            assert fixture['comment_anchor_validated'] and fixture['comment_target']['target_object_id']==fixture['entity_id']
            requests=[];counter=itertools.count();opener=build_opener(ProxyHandler({}));request_lock=threading.Lock()
            def request(name,path,method='GET',payload=None,expected_status=200,phase='check'):
                seq=next(counter);rid=f'{label}-{seq:04d}-{name}'
                body=None if payload is None else canonical(payload).encode()
                req=Request('http://127.0.0.1:62607'+path,data=body,method=method,
                    headers={'Content-Type':'application/json','X-Measurement-Id':rid})
                remaining();start=time.perf_counter()
                try:
                    try:response=opener.open(req,timeout=min(15,remaining()))
                    except HTTPError as exc:response=exc
                    with response:raw=response.read();code=response.status
                    elapsed=(time.perf_counter()-start)*1000
                    value=json.loads(raw)
                    row={'request_id':rid,'sequence':seq,'name':name,'phase':phase,'method':method,'path':path,
                         'payload':payload,'status':code,'elapsed_ms':elapsed,'bytes':len(raw),
                         'request_sha256':hashlib.sha256(body or b'').hexdigest(),'response_sha256':hashlib.sha256(raw).hexdigest()}
                    if method!='GET':row['response']=value
                    with request_lock:requests.append(row)
                    assert code==expected_status,(name,code,value)
                    return value
                finally:
                    # Each request is small except entity readback; only fixed
                    # payloads and write responses are retained, no secret data.
                    with request_lock:dump(evidence/'requests.json',sorted(requests,key=lambda r:r['sequence']))
            def comment_read(cid,body,version,event_count):
                path='/api/comments?'+urlencode(fixture['comment_target'])
                rows=request('comment-readback',path);row=next(row for row in rows if row['id']==cid)
                assert row['body']==body and row['version']==version and row['anchor']=={'type':'global'}
                state=db_state(database,fixture);dbrow=next(row for row in state['comments'] if row['id']==cid)
                assert dbrow['body']==body and dbrow['version']==version and dbrow['target_revision_id']==fixture['comment_target']['target_revision_id']
                assert len([event for event in state['comment_events'] if event['comment_id']==cid])==event_count
                return state
            def entity_read(verdict,version):
                data=request('entity-readback','/api/production/entity-review?'+urlencode({'entity_id':fixture['entity_id']}))
                state=db_state(database,fixture)
                assert data['decision_version']==version and state['decision']['version']==version
                assert len(state['decision_history'])==version and state['decision_history'][-1]['payload']['verdict']==verdict
                assert bool(data['can_revoke'])==(verdict=='accepted')
                return data,state
            initial=db_state(database,fixture);dump(evidence/'initial-state.json',initial)
            for iteration in range(6):
                phase='warmup' if iteration==0 else 'sample';cid=PREFIX+'comment-'+str(iteration)
                body='隔离性能评论 '+str(iteration);payload={'id':cid,**fixture['comment_target'],'anchor':{'type':'global'},'body':body}
                request('comment-create','/api/comments','POST',payload,201,phase)
                comment_read(cid,body,1,1)
                changed=body+' 已编辑';edit={'action':'EDIT','expected_version':1,'body':changed}
                request('comment-edit','/api/comments/'+cid,'PATCH',edit,200,phase)
                stable=comment_read(cid,changed,2,2)
                request('comment-stale','/api/comments/'+cid,'PATCH',edit,409)
                assert db_state(database,fixture)==stable
            for iteration in range(6):
                phase='warmup' if iteration==0 else 'sample';before_state=db_state(database,fixture)
                version=before_state['project']['version'];audience='隔离技术测试受众 '+str(iteration)
                payload={'expected_version':version,'updates':{'audience':audience}}
                request('configuration-save','/api/configurations/PROJECT','PATCH',payload,200,phase)
                current=request('configuration-readback','/api/configurations')['values']['PROJECT'];stable=db_state(database,fixture)
                assert current['version']==version+1 and current['body']['audience']==audience
                assert stable['project']==current and stable['configuration_event_count']==before_state['configuration_event_count']+1
                request('configuration-stale','/api/configurations/PROJECT','PATCH',payload,409)
                assert db_state(database,fixture)==stable
            data=request('entity-initial','/api/production/entity-review?'+urlencode({'entity_id':fixture['entity_id']}))
            first_accepted=None
            for iteration in range(6):
                phase='warmup' if iteration==0 else 'sample'
                assert data['can_accept'] and data['decision_version']==iteration*2
                payload={'entity_id':fixture['entity_id'],'action':'accept','expected_version':data['decision_version'],
                    'scope':data.get('decision_scope') or data['scope'],'acceptance_mode':data['acceptance_mode'],
                    'decision_ref':data['revoke_target'],'actor':'隔离性能技术测试','reason':'仅技术 fixture，非作品认可'}
                request('entity-accept','/api/production/entity-decision','POST',payload,201,phase)
                data,stable=entity_read('accepted',iteration*2+1)
                if first_accepted is None:first_accepted=stable['decision_history'][-1]['id']
                request('entity-accept-stale','/api/production/entity-decision','POST',payload,409)
                assert db_state(database,fixture)==stable
                payload={**payload,'action':'revoke','expected_version':data['decision_version'],'decision_ref':data['revoke_target'],
                    'scope':data.get('decision_scope') or data['scope'],'acceptance_mode':data['acceptance_mode']}
                request('entity-revoke','/api/production/entity-decision','POST',payload,201,phase)
                data,stable=entity_read('revoked',iteration*2+2)
                request('entity-revoke-stale','/api/production/entity-decision','POST',payload,409)
                assert db_state(database,fixture)==stable
            history=request('entity-history','/api/production?'+urlencode({'object_id':fixture['decision_id'],'revision_id':first_accepted}))
            assert history['record']['id']==first_accepted and history['record']['payload']['verdict']=='accepted'
            deterministic_states[label]=deterministic_state(db_state(database,fixture))
            dump(evidence/'deterministic-state.json',deterministic_states[label])
            # Competing HTTP requests have a shared expected_version. Original
            # HTTPServer serializes handlers; this is not a multi-writer DB test.
            if remaining()<35:raise TimeoutError('insufficient budget for bounded competition check and cleanup')
            before_state=db_state(database,fixture);version=before_state['project']['version']
            def competing(n):
                payload={'expected_version':version,'updates':{'audience':'隔离竞争测试 '+str(n)}}
                try:return request('configuration-competing-'+str(n),'/api/configurations/PROJECT','PATCH',payload,200)['version']
                except AssertionError as exc:
                    if exc.args and isinstance(exc.args[0],tuple) and exc.args[0][1]==409:return 'conflict'
                    raise
            with ThreadPoolExecutor(max_workers=2) as pool:outcomes=list(pool.map(competing,(1,2)))
            assert sorted(map(str,outcomes))==sorted([str(version+1),'conflict'])
            final=db_state(database,fixture)
            assert final['configuration_event_count']==before_state['configuration_event_count']+1 and final['project']['version']==version+1
            visible=request('configuration-competition-readback','/api/configurations')['values']['PROJECT']
            assert visible==final['project']
            cid=PREFIX+'comment-5';before_competition=db_state(database,fixture)
            version=next(r['version'] for r in before_competition['comments'] if r['id']==cid)
            def competing_comment(n):
                payload={'action':'EDIT','expected_version':version,'body':'隔离竞争评论 '+str(n)}
                try:return request('comment-competing-'+str(n),'/api/comments/'+cid,'PATCH',payload,200)['version']
                except AssertionError as exc:
                    if exc.args and isinstance(exc.args[0],tuple) and exc.args[0][1]==409:return 'conflict'
                    raise
            with ThreadPoolExecutor(max_workers=2) as pool:outcomes=list(pool.map(competing_comment,(1,2)))
            assert sorted(map(str,outcomes))==sorted([str(version+1),'conflict'])
            final=db_state(database,fixture);winner=next(r for r in final['comments'] if r['id']==cid)
            assert len(final['comment_events'])==len(before_competition['comment_events'])+1
            assert winner['body'] in ('隔离竞争评论 1','隔离竞争评论 2')
            comment_read(cid,winner['body'],version+1,3)
            dump(evidence/'final-state.json',final)
            # Ensure the last write metrics were flushed before terminating own PID.
            request('final-flush','/api/instance')
            server.terminate();server.wait(timeout=3);server=None;log.close()
            audit=audit_preserved(source,database,fixture);dump(evidence/'preservation-audit.json',audit)
            metrics=[json.loads(line) for line in (evidence/'server-metrics.jsonl').read_text().splitlines()]
            byid={row['request_id']:row for row in metrics}
            for row in requests:
                if row['method']!='GET':
                    assert row['request_id'] in byid and byid[row['request_id']]['status']==row['status']
            # Competition order is nondeterministic; fixed sequential measurement
            # payloads must match exactly across the two arms.
            request_vectors[label]=[(r['name'],r['phase'],r['method'],r['path'],r['payload']) for r in sorted(requests,key=lambda r:r['sequence']) if r['phase'] in ('warmup','sample')]
            report['completed'].append(label)
        assert fixture_hashes['baseline']==fixture_hashes['candidate'],'fixture payload mismatch'
        assert request_vectors['baseline']==request_vectors['candidate'],'measurement payloads differ'
        assert deterministic_states['baseline']==deterministic_states['candidate'],'deterministic write outcomes differ'
        report['fixture_sha256']=fixture_hashes['baseline'];report['fixed_payloads_equal']=True
        report['deterministic_business_state_equal']=True
    except BaseException as exc:
        report['error']={'type':type(exc).__name__,'message':str(exc)}
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        if server is not None and server.poll() is None:
            server.terminate()
            try:server.wait(timeout=3)
            except subprocess.TimeoutExpired:server.kill();server.wait(timeout=1)
        try:
            report['source_sha256_after']=sha(source);report['systems_after']={k:fingerprint(v) for k,v in systems.items()}
            report['source_unchanged']=report['source_sha256_after']==SOURCE_SHA;report['systems_unchanged']=report['systems_after']==before
        except Exception as exc:report['final_identity_audit_error']=str(exc)
        try:
            guard=subprocess.check_output([sys.executable,'scripts/autonomous_optimization_guard.py','check'],cwd=root.parent.parent,text=True,timeout=max(.1,min(3,deadline-time.monotonic()-1)))
            dump(out/'guard-after.json',json.loads(guard))
        except Exception as exc:report['guard_after_error']=str(exc)
        report['ended_at_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());report['elapsed_seconds']=time.monotonic()-started
        dump(out/'receipt.json',report);stopped.set();print(json.dumps(report,ensure_ascii=False))


if __name__=='__main__':main()
