#!/usr/bin/env python3
"""Original API handler with an existing read-only Store; task A/B only."""
import argparse
from http.server import HTTPServer
import json
from pathlib import Path
import sqlite3
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--system', required=True, type=Path)
    parser.add_argument('--instance', required=True, type=Path)
    parser.add_argument('--database', required=True, type=Path)
    parser.add_argument('--port', type=int, default=62607, choices=(62607,))
    args = parser.parse_args()
    instance, database = args.instance.resolve(), args.database.resolve()
    if '.runtime' not in instance.parts or not database.is_relative_to(instance) or not database.is_file():
        parser.error('task-only existing snapshot under the isolated instance is required')
    sys.path.insert(0, str(args.system.resolve()))
    from review_desk.server import ReviewServer, ReviewHandler
    from review_desk.store import Store
    from review_desk.material_storage import row_factory

    class ReadOnlyHandler(ReviewHandler):
        def do_POST(self):
            return self._json({'error': 'measurement server is read-only'}, 405)

        do_PATCH = do_POST
        do_PUT = do_POST
        do_DELETE = do_POST

    store = Store.__new__(Store)
    store.db_path = database
    store.db = sqlite3.connect(database.as_uri() + '?mode=ro', uri=True)
    store.db.execute('PRAGMA query_only=ON')
    store.db.row_factory = row_factory(store)
    server = ReviewServer.__new__(ReviewServer)
    HTTPServer.__init__(server, ('127.0.0.1', args.port), ReadOnlyHandler)
    server.root = instance
    server.config = json.loads((instance / 'config/instance.json').read_text())
    server.store = store
    print(json.dumps({'port': args.port, 'system': str(args.system.resolve()),
                      'database': str(database), 'read_only': True}), flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
