#!/usr/bin/env python3
"""Opt-in measurement server; never used by the production candidate.

Run from the task workspace and point --instance at a task-only preview. This
retains ReviewServer's single-threaded request model and Store initialization.
Only index.html receives an additional synchronous script before app scripts.
"""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--system', required=True, type=Path)
    parser.add_argument('--instance', required=True, type=Path)
    parser.add_argument('--port', required=True, type=int)
    parser.add_argument('--label', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    system, instance = args.system.resolve(), args.instance.resolve()
    if '.runtime' not in instance.parts:
        parser.error('measurement server requires an isolated .runtime instance')
    args.output.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(system))
    from review_desk.server import ReviewHandler, ReviewServer
    probe = Path(__file__).with_name('probe.js').read_bytes()
    metadata = {
        'label': args.label, 'system': str(system), 'instance': str(instance),
        'python': sys.version, 'machine': platform.platform(),
        'probe_sha256': hashlib.sha256(probe).hexdigest(),
        'system_commit': subprocess.check_output(['git', '-C', str(system), 'rev-parse', 'HEAD'], text=True).strip(),
        'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'port': args.port,
    }
    (args.output / 'environment.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')

    class ProbeHandler(ReviewHandler):
        def send_response(self, code, message=None):
            self._probe_status = code
            return super().send_response(code, message)

        def _measured(self, action):
            self._probe_status = None
            started = time.perf_counter()
            error = None
            try:
                return action()
            except BaseException as exc:
                error = type(exc).__name__
                raise
            finally:
                elapsed = (time.perf_counter() - started) * 1000
                sample = {'at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                          'method': self.command, 'path': self.path,
                          'status': self._probe_status, 'error_type': error,
                          'server_elapsed_ms': elapsed}
                # Formatting and append happen after stopping the stopwatch.
                # No payload or response body is persisted here.
                with (args.output / 'http.jsonl').open('a') as stream:
                    stream.write(json.dumps(sample, ensure_ascii=False) + '\n')

        def do_GET(self):
            return self._measured(self._get)

        def do_POST(self):
            return self._measured(super().do_POST)

        def do_PATCH(self):
            return self._measured(super().do_PATCH)

        def _get(self):
            if self.path.split('?', 1)[0] == '/__probe__/probe.js':
                data = ('window.__probeMetadata=' + json.dumps(metadata, ensure_ascii=False) + ';\n').encode() + probe
                self.send_response(200)
                self.send_header('Content-Type', 'text/javascript; charset=utf-8')
                self.send_header('Content-Length', str(len(data)))
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(data)
                return
            return super().do_GET()

        def _file(self, path, mime):
            if path.name != 'index.html' or not mime.startswith('text/html'):
                return super()._file(path, mime)
            data = path.read_bytes().replace(b'<head>', b'<head><script src="/__probe__/probe.js"></script>', 1)
            self.send_response(200)
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            self.wfile.write(data)

    config = json.loads((instance / 'config' / 'instance.json').read_text())
    server = ReviewServer(('127.0.0.1', args.port), instance, config)
    server.RequestHandlerClass = ProbeHandler
    print(json.dumps(metadata, ensure_ascii=False), flush=True)
    try:
        server.serve_forever()
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
