#!/usr/bin/env python3
"""Run only in an assigned exclusive CPU/browser window. Uses own port/PIDs."""
import argparse
import hashlib
import json
from pathlib import Path
import socket
import subprocess
import sys
import time
from urllib.request import ProxyHandler, build_opener


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-name', required=True)
    parser.add_argument('--max-seconds', type=int, default=480)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    if not args.output_name or Path(args.output_name).name != args.output_name or not 30 <= args.max_seconds <= 600:
        parser.error('a plain output directory name and 30..600 second budget are required')
    out = here / args.output_name
    if out.exists():
        parser.error('choose a new output name; prior raw evidence is never overwritten')
    out.mkdir()
    root = here.parent
    systems = {'baseline': root / 'system-baseline', 'candidate': root / 'system-worktree'}
    instance = root / 'preview'
    database = instance / '.runtime/generation-base.sqlite3'
    def fingerprint(system):
        return {'commit': subprocess.check_output(['git', '-C', str(system), 'rev-parse', 'HEAD'], text=True).strip(),
                'python_sources': {str(path.relative_to(system)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted((system / 'review_desk').glob('*.py'))}}
    metadata = {'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'database': str(database), 'database_sha256': hashlib.sha256(database.read_bytes()).hexdigest(),
                'systems': {label: fingerprint(system) for label, system in systems.items()},
                'api_port': 62607, 'http_order': ['baseline', 'candidate'],
                'rss_pair_orders': [['baseline', 'candidate'] if n % 2 == 0 else ['candidate', 'baseline'] for n in range(5)],
                'budget_seconds': args.max_seconds, 'read_only': True}
    (out / 'environment.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
    deadline = time.monotonic() + args.max_seconds
    report = {'completed_http': [], 'completed_rss': [], 'error': None}
    opener = build_opener(ProxyHandler({}))
    def remaining():
        value = deadline - time.monotonic()
        if value <= 0:
            raise TimeoutError('assigned measurement window exhausted')
        return value
    def command(argv, log, limit=None):
        with log.open('w') as stream:
            result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT,
                                    timeout=min(remaining(), limit or remaining()))
        if result.returncode:
            raise RuntimeError(f'command failed ({result.returncode}); see {log.name}')
    try:
        for label, system in systems.items():
            # A successful bind is a precondition; never terminate another listener.
            check = socket.socket()
            try:
                check.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                check.bind(('127.0.0.1', 62607))
            finally:
                check.close()
            with (out / f'{label}-server.log').open('w') as log:
                server = subprocess.Popen([sys.executable, str(here / 'readonly_api_server.py'),
                    '--system', str(system), '--instance', str(instance), '--database', str(database)], stdout=log, stderr=log)
                try:
                    ready = False
                    for _ in range(50):
                        if server.poll() is not None:
                            raise RuntimeError(f'{label} measurement server exited before readiness')
                        try:
                            with opener.open('http://127.0.0.1:62607/api/instance', timeout=1) as response:
                                ready = response.status == 200
                            if ready:
                                break
                        except OSError:
                            time.sleep(.1)
                    if not ready:
                        raise RuntimeError(f'{label} measurement server did not become ready')
                    command([sys.executable, str(here / 'http_baseline.py'), '--base-url', 'http://127.0.0.1:62607',
                        '--routes', str(here / 'routes-window1.json'), '--output', str(out / (label + '-http')),
                        '--label', label + '-AO-PERF-001', '--repeat', '50', '--warmup', '3',
                        '--request-timeout', '30', '--max-seconds', str(min(480, remaining()))], out / f'{label}-http-run.log')
                    summary = json.loads((out / (label + '-http') / 'summary.json').read_text())
                    if summary['aborted'] or summary['sample_count'] != 795:
                        raise RuntimeError(f'{label} HTTP batch incomplete')
                    report['completed_http'].append(label)
                finally:
                    # Only the exact subprocess created above is stopped.
                    if server.poll() is None:
                        server.terminate()
                        try:
                            server.wait(timeout=5)
                        except subprocess.TimeoutExpired:
                            server.kill(); server.wait()
        baseline = json.loads((out / 'baseline-http/summary.json').read_text())['results']
        candidate = json.loads((out / 'candidate-http/summary.json').read_text())['results']
        mismatches = [name for name in baseline if name not in candidate or
            baseline[name]['n'] != 50 or candidate[name]['n'] != 50 or
            baseline[name]['response_json_hashes'] != candidate[name]['response_json_hashes']]
        report['http_hash_mismatches'] = mismatches
        if mismatches:
            raise RuntimeError('HTTP full response hashes differ: ' + ', '.join(mismatches))
        operations = [('index', []), ('material_list', []),
                      ('scene', ['--object-id', 'preparation-s001', '--revision-id', 'dd7e073959fd188f3aecb2620fab4b967b8a4ba3f5b88fbdeaeb5c736e1b4e72']),
                      ('entity', ['--object-id', 'entity-li-ji']), ('history', [])]
        for operation, extra in operations:
            for pair, labels in enumerate(metadata['rss_pair_orders'], 1):
                for label in labels:
                    name = f'{operation}-{pair}-{label}'
                    command([sys.executable, str(here / 'db_diagnostics.py'), '--system', str(systems[label]),
                        '--database', str(database), '--output', str(out / 'rss' / name), '--label', name,
                        '--operation', operation, '--mode', 'timing', '--repeat', '1',
                        '--max-seconds', str(min(30, remaining()))] + extra, out / (name + '.log'), limit=35)
                    result = json.loads((out / 'rss' / name / 'summary.json').read_text())
                    if result['error'] or len(result['samples']) != 1:
                        raise RuntimeError(f'{name} diagnostic incomplete')
                    report['completed_rss'].append(name)
        report['rss_hash_mismatches'] = []
        for operation, _ in operations:
            for pair in range(1, 6):
                left = json.loads((out / 'rss' / f'{operation}-{pair}-baseline' / 'summary.json').read_text())['samples'][0]
                right = json.loads((out / 'rss' / f'{operation}-{pair}-candidate' / 'summary.json').read_text())['samples'][0]
                if left['json_sha256'] != right['json_sha256']:
                    report['rss_hash_mismatches'].append(f'{operation}-{pair}')
    except (TimeoutError, OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
        report['error'] = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        report['ended_at_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        report['database_sha256_after'] = hashlib.sha256(database.read_bytes()).hexdigest()
        report['systems_after'] = {label: fingerprint(system) for label, system in systems.items()}
        (out / 'receipt.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
