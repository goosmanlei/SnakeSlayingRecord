#!/usr/bin/env python3
"""Bounded, serial GET measurement. Default is one discovery read per route."""
import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import platform
import signal
import statistics
import time
from urllib.error import HTTPError
from urllib.parse import urlsplit
from urllib.request import ProxyHandler, Request, build_opener


class DeadlineExceeded(TimeoutError):
    pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--base-url', required=True)
    parser.add_argument('--routes', required=True, type=Path, help='JSON list of {name,path}')
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--label', required=True)
    parser.add_argument('--repeat', type=int, default=1)
    parser.add_argument('--warmup', type=int, default=0)
    parser.add_argument('--request-timeout', type=float, default=30)
    parser.add_argument('--max-seconds', type=float, default=180)
    args = parser.parse_args()
    base = urlsplit(args.base_url)
    if base.scheme != 'http' or base.hostname != '127.0.0.1' or base.port not in (62605, 62606, 62607):
        parser.error('only task preview http://127.0.0.1 ports 62605, 62606 or 62607 are allowed')
    if base.path not in ('', '/') or base.query or base.fragment or base.username:
        parser.error('base URL must contain only scheme, loopback host and task port')
    if not 1 <= args.repeat <= 50 or not 0 <= args.warmup <= 5:
        parser.error('repeat must be 1..50 and warmup 0..5; repeat requires explicit selection after discovery')
    if args.request_timeout <= 0 or args.max_seconds <= 0 or args.max_seconds > 1800:
        parser.error('positive timeouts required; whole measurement window cannot exceed 1800 seconds')
    out = args.output.resolve()
    if not out.is_relative_to(Path(__file__).resolve().parent):
        parser.error('output must remain under backend-investigation')
    routes = json.loads(args.routes.read_text())
    for route in routes:
        path = route['path']
        if not isinstance(route.get('name'), str) or not isinstance(path, str) or not path.startswith('/api/') or path.startswith('//') or urlsplit(path).netloc:
            parser.error('each route needs name and a same-origin /api/ GET path')
    out.mkdir(parents=True, exist_ok=True)
    metadata = {'label': args.label, 'base_url': args.base_url, 'routes': routes,
                'repeat': args.repeat, 'warmup': args.warmup,
                'request_timeout_seconds': args.request_timeout, 'max_seconds': args.max_seconds,
                'machine': platform.platform(), 'python': platform.python_version(),
                'at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'cache_scope': 'No OS/browser cache purge. Samples are ordered and first request is explicit.',
                'timing': 'Request creation through complete response body; JSON digest computation excluded.'}
    (out / 'environment.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
    opener = build_opener(ProxyHandler({}))
    samples, aborted = [], None
    overall = time.perf_counter()
    deadline = overall + args.max_seconds

    def alarm_handler(_signum, _frame):
        raise DeadlineExceeded('entire request wall-clock deadline exceeded')

    previous_handler = signal.signal(signal.SIGALRM, alarm_handler)
    try:
        for route in routes:
            for index in range(args.warmup + args.repeat):
                remaining = deadline - time.perf_counter()
                if remaining <= 0:
                    aborted = 'total measurement window exhausted'; break
                sample = {'name': route['name'], 'path': route['path'], 'sequence': len(samples) + 1,
                          'phase': 'warmup' if index < args.warmup else 'sample',
                          'iteration': index - args.warmup + 1,
                          'at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
                started = time.perf_counter()
                try:
                    budget = min(args.request_timeout, remaining)
                    signal.setitimer(signal.ITIMER_REAL, budget)
                    request = Request(args.base_url.rstrip('/') + route['path'], method='GET')
                    try:
                        response = opener.open(request, timeout=budget)
                    except HTTPError as exc:
                        response = exc
                    with response:
                        status = response.status
                        body = response.read()
                    ended = time.perf_counter()
                    signal.setitimer(signal.ITIMER_REAL, 0)
                    sample.update(status=status, elapsed_ms=(ended - started) * 1000, bytes=len(body),
                                  body_sha256=hashlib.sha256(body).hexdigest())
                    try:
                        canonical = json.dumps(json.loads(body), ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
                        sample['json_sha256'] = hashlib.sha256(canonical).hexdigest()
                    except (ValueError, UnicodeError):
                        sample['json_sha256'] = None
                except (TimeoutError, OSError) as exc:
                    signal.setitimer(signal.ITIMER_REAL, 0)
                    sample.update(status=None, elapsed_ms=(time.perf_counter() - started) * 1000,
                                  error_type=type(exc).__name__, error=str(exc))
                    aborted = 'request failed or timed out; stop because single-thread server may still be busy'
                finally:
                    signal.setitimer(signal.ITIMER_REAL, 0)
                samples.append(sample)
                with (out / 'samples.jsonl').open('a') as stream:
                    stream.write(json.dumps(sample, ensure_ascii=False) + '\n')
                print(json.dumps(sample, ensure_ascii=False), flush=True)
                if aborted:
                    break
            if aborted:
                break
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)
    groups = defaultdict(list)
    for sample in samples:
        if sample['phase'] == 'sample' and sample.get('status') == 200:
            groups[sample['name']].append(sample)
    summary = {'aborted': aborted, 'elapsed_seconds': time.perf_counter() - overall,
               'sample_count': len(samples), 'results': {}}
    for name, rows in groups.items():
        values = sorted(row['elapsed_ms'] for row in rows)
        summary['results'][name] = {'n': len(values), 'min_ms': values[0], 'max_ms': values[-1],
                                    'median_ms': statistics.median(values),
                                    'p95_ms': values[math.ceil(len(values) * .95) - 1],
                                    'response_json_hashes': sorted({r['json_sha256'] for r in rows if r['json_sha256']})}
    (out / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(summary, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
