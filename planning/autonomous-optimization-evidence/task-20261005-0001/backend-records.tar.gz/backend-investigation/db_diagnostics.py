#!/usr/bin/env python3
"""Bounded diagnostics on an existing read-only task snapshot; no Store init."""
import argparse
from collections import Counter
import cProfile
import hashlib
import io
import json
from pathlib import Path
import platform
import pstats
import re
import resource
import signal
import sqlite3
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--system', required=True, type=Path)
    parser.add_argument('--database', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--label', required=True)
    parser.add_argument('--operation', required=True, choices=('material_entries', 'material_list', 'index', 'history', 'scene', 'entity', 'comments', 'production', 'card', 'inventory'))
    parser.add_argument('--object-id')
    parser.add_argument('--revision-id')
    parser.add_argument('--mode', choices=('timing', 'profile', 'trace'), default='profile')
    parser.add_argument('--repeat', type=int, default=1)
    parser.add_argument('--max-seconds', type=float, default=30)
    args = parser.parse_args()
    system, database, out = args.system.resolve(), args.database.resolve(), args.output.resolve()
    if not out.is_relative_to(Path(__file__).resolve().parent):
        parser.error('output must remain under backend-investigation')
    if '.runtime' not in database.parts or not database.is_file():
        parser.error('an existing task-only .runtime database is required')
    if not 1 <= args.repeat <= 50 or not 0 < args.max_seconds <= 600:
        parser.error('repeat must be 1..50, time budget 0..600 seconds')
    if args.operation in ('scene', 'entity', 'production', 'card') and not args.object_id:
        parser.error('--object-id required for selected operation')
    if args.mode != 'timing' and args.repeat != 1:
        parser.error('trace/profile are single diagnostics, never mixed with repeat timing samples')
    out.mkdir(parents=True, exist_ok=True)
    sys.path.insert(0, str(system))
    from review_desk.store import Store
    from review_desk import production as p, ui_projection as ui, production_breakdown as b, entity_review
    from review_desk.material_storage import row_factory
    store = Store.__new__(Store)
    store.db_path = database
    store.db = sqlite3.connect(database.as_uri() + '?mode=ro', uri=True)
    store.db.execute('PRAGMA query_only=ON')
    store.db.row_factory = row_factory(store)
    statements = Counter()
    templates = Counter()
    examples = {}

    def trace(sql):
        statements[sql] += 1
        normalized = re.sub(r"'(?:''|[^'])*'", '?', sql)
        normalized = re.sub(r'\b\d+\b', '?', normalized)
        normalized = ' '.join(normalized.split())
        templates[normalized] += 1
        examples.setdefault(normalized, sql)

    def read():
        if args.operation == 'comments':
            # Match the existing GET route exactly, including no added scope.
            return [{**c, 'anchor_state': store.anchor_state(c['target_object_id'], c['target_revision_id'], c['anchor'])} for c in store.comments()]
        if args.operation == 'production':
            return p.snapshot(store, object_id=args.object_id, revision_id=args.revision_id)
        if args.operation == 'entity':
            return entity_review.snapshot(store, args.object_id, args.revision_id)
        if args.operation == 'inventory':
            tables = [r[0] for r in store.db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
            return {'tables': {name: store.db.execute('SELECT COUNT(*) FROM "' + name.replace('"', '""') + '"').fetchone()[0] for name in tables},
                    'kinds': {r[0]: r[1] for r in store.db.execute('SELECT kind,COUNT(*) FROM objects GROUP BY kind')},
                    'comment_targets': store.db.execute('SELECT COUNT(DISTINCT target_revision_id) FROM comments').fetchone()[0],
                    'indexes': [dict(r) for r in store.db.execute("SELECT name,tbl_name,sql FROM sqlite_master WHERE type='index' ORDER BY name")]}
        with p.read_scope(store):
            if args.operation == 'material_entries':
                return ui.material_entries(store)
            if args.operation == 'material_list':
                return ui.material_list(store)
            if args.operation == 'index':
                return b.index(store, 'settings')
            if args.operation == 'history':
                return b.index(store, 'history')
            if args.operation == 'scene':
                return ui.scene(store, args.object_id, args.revision_id)
            if args.operation == 'card':
                return ui.card(store, args.object_id, args.revision_id)

    metadata = {'label': args.label, 'operation': args.operation, 'mode': args.mode,
                'object_id': args.object_id, 'revision_id': args.revision_id,
                'system': str(system), 'database': str(database),
                'database_bytes': database.stat().st_size,
                'database_mtime_ns': database.stat().st_mtime_ns,
                'python': platform.python_version(), 'machine': platform.platform(),
                'max_seconds': args.max_seconds, 'repeat': args.repeat,
                'at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                'read_only': True, 'store_initialization_skipped': True,
                'timing_not_comparable_across_modes': True,
                'rss_unit': 'bytes',
                'native_ru_maxrss_unit': 'bytes' if sys.platform == 'darwin' else 'KiB',
                'rss_scope': 'Process lifetime peak, not incremental allocation. Use a fresh subprocess per one-shot A/B sample.'}
    (out / 'environment.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n')
    profiler = cProfile.Profile()
    samples, error = [], None
    started = time.perf_counter()

    def timeout(_signum, _frame):
        raise TimeoutError('diagnostic wall-clock budget exceeded')

    old_handler = signal.signal(signal.SIGALRM, timeout)
    signal.setitimer(signal.ITIMER_REAL, args.max_seconds)
    store.db.set_progress_handler(lambda: int(time.perf_counter() - started > args.max_seconds), 10000)
    try:
        for index in range(args.repeat):
            if args.mode == 'trace':
                store.db.set_trace_callback(trace)
            if args.mode == 'profile':
                profiler.enable()
            wall, cpu = time.perf_counter(), time.process_time()
            result = read()
            read_ms, cpu_ms = (time.perf_counter() - wall) * 1000, (time.process_time() - cpu) * 1000
            peak_after_read = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1 if sys.platform == 'darwin' else 1024)
            profiler.disable()
            store.db.set_trace_callback(None)
            serial_start = time.perf_counter()
            body = json.dumps(result, ensure_ascii=False).encode()
            serial_ms = (time.perf_counter() - serial_start) * 1000
            canonical = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
            samples.append({'iteration': index + 1, 'read_ms': read_ms, 'cpu_ms': cpu_ms,
                            'json_serialize_ms': serial_ms, 'bytes': len(body),
                            'peak_rss_after_read_bytes': peak_after_read,
                            'peak_rss_after_serialization_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1 if sys.platform == 'darwin' else 1024),
                            'json_sha256': hashlib.sha256(canonical).hexdigest()})
            if args.operation == 'inventory':
                (out / 'inventory.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    except (TimeoutError, sqlite3.Error, ValueError, KeyError) as exc:
        error = {'type': type(exc).__name__, 'message': str(exc)}
    finally:
        profiler.disable()
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old_handler)
        store.db.set_trace_callback(None)
        store.db.close()
    report = {'samples': samples, 'error': error, 'elapsed_seconds': time.perf_counter() - started,
              'peak_rss_bytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1 if sys.platform == 'darwin' else 1024)}
    if args.mode == 'trace':
        report['sql_count'] = sum(statements.values())
        report['distinct_sql_count'] = len(statements)
        (out / 'sql.json').write_text(json.dumps({'templates': [{'sql': sql, 'count': count, 'example': examples[sql]} for sql, count in templates.most_common()],
            'statements': [{'sql': sql, 'count': count} for sql, count in statements.most_common()]}, ensure_ascii=False, indent=2) + '\n')
    if args.mode == 'profile':
        profiler.dump_stats(out / 'profile.pstats')
        stream = io.StringIO()
        pstats.Stats(profiler, stream=stream).strip_dirs().sort_stats('cumulative').print_stats(80)
        (out / 'profile.txt').write_text(stream.getvalue())
    (out / 'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
