async(...args)=>{await args[0].playwright.locator('#performance-probe-results[data-probe-active="none"]').waitFor({state:'attached',timeoutMs:60000});return unpreparedUIWriteSampler(...args)}
