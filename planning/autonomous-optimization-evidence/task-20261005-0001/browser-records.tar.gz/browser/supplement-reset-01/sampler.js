async function(tab,phase,id,index,action,expected){
 const path=supplementDir+'/'+id+'-'+phase+'-'+index+'.json';
 try{await evidenceFs.access(path);throw Error('refuse overwrite '+path)}catch(e){if(e.code!=='ENOENT')throw e}
 await tab.playwright.locator('#performance-probe-results[data-probe-active="none"]').waitFor({state:'attached',timeoutMs:60000});
 const before=await tab.playwright.evaluate(()=>JSON.parse(document.querySelector('#performance-probe-results').textContent));
 const start=Date.now();let actionError=null;
 try{await action();await tab.playwright.locator('#performance-probe-results[data-probe-active="none"]:not([data-probe-count="'+before.samples.length+'"])').waitFor({state:'attached',timeoutMs:60000})}catch(e){actionError=String(e)}
 const probe=await tab.playwright.evaluate(()=>JSON.parse(document.querySelector('#performance-probe-results').textContent));
 const sample=probe.samples.at(-1),sem=sample.semantic_at_ready,u=new URL(sample.end_url);
 const observed=await tab.playwright.evaluate(()=>({url:location.href,
  dialogs:[...document.querySelectorAll('dialog[open]')].map(e=>({label:e.getAttribute('aria-label'),text:e.innerText.slice(0,500),scrollTop:e.scrollTop})),
  images:[...document.images].filter(e=>e.getBoundingClientRect().width>0).map(e=>({src:e.currentSrc,complete:e.complete,width:e.naturalWidth,height:e.naturalHeight,rect:e.getBoundingClientRect().toJSON()})),
  media:[...document.querySelectorAll('audio,video')].map(e=>({src:e.currentSrc,readyState:e.readyState,networkState:e.networkState,duration:e.duration,currentTime:e.currentTime,paused:e.paused,error:e.error?.code,rect:e.getBoundingClientRect().toJSON()})),
  pressed:[...document.querySelectorAll('#production-index button[aria-pressed="true"]')].map(e=>({id:e.dataset.objectId,text:e.innerText})),
  marks:[...document.querySelectorAll('.comment-flash')].filter(e=>e.getBoundingClientRect().width>0).map(e=>{const r=e.getBoundingClientRect();const x=Math.max(0,Math.min(innerWidth-1,r.x+r.width/2)),y=Math.max(0,Math.min(innerHeight-1,r.y+r.height/2));return {text:e.innerText,rect:r.toJSON(),hit:e.contains(document.elementFromPoint(x,y))}})
 }));
 const end=Date.now();
 const checks={noActionError:!actionError,phase:probe.metadata.label==='page-supplement-'+phase,commit:probe.metadata.system_commit===(phase.startsWith('A')?'b874b959af9c918a482e8488dc25cb0204ab5772':'204c4696f0ecd4595b395a14520eacf0c54ef2bf'),probe:probe.metadata.probe_sha256==='74a80b7f730a450f4fc00f5424120f8f60406e7fe9c4c65234e3d317958a804c',newClick:probe.samples.length===before.samples.length+1&&sample.type==='click',stable:sample.completion_reason==='stable',noErrors:sample.request_error_count===0,noPending:!Object.values(sample.pending_at_end).some(Boolean),foreground:sample.visibility_at_start==='visible'&&sample.visibility_at_end==='visible',viewport:probe.browser.viewport.width===1440&&probe.browser.viewport.height===900,route:Object.entries(expected.params||{}).every(([k,v])=>u.searchParams.get(k)===v),content:(expected.includes||[]).every(t=>sem.regions.some(r=>(r.first+' '+r.last).includes(t)))};
 if(expected.image)checks.image=observed.images.some(e=>e.src.endsWith(expected.image)&&e.complete&&e.width>0&&e.height>0);
 if(expected.pressed)checks.pressed=observed.pressed.length===1&&observed.pressed[0].id===expected.pressed;
 const snapshot=await tab.playwright.domSnapshot();
 await evidenceFs.writeFile(path,JSON.stringify({phase,id,index,expected,checks,actionError,before:{url:before.url,count:before.samples.length,last:before.samples.at(-1)},tool_start_epoch_ms:start,tool_end_epoch_ms:end,probe,observed,snapshot},null,2)+'\n',{flag:'wx'});
 if(!Object.values(checks).every(Boolean))throw Error(JSON.stringify({phase,id,index,checks}));
 return {phase,id,index,ready_ms:sample.scenario_ready_ms,observation_upper_ms:end-start,observed};
}
