# -*- coding: utf-8 -*-
"""Lightweight audit of existing JSON only; no browser, service, or load generation."""
import json,re,hashlib,statistics,collections
from pathlib import Path
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'history-inventory'; BROWSER=ROOT/'browser'
files=sorted(BROWSER.glob('*baseline*action.json'))
rows=[];acc={}
for p in files:
 raw=p.read_bytes();d=json.loads(raw);probe=d['probe'];s=probe['samples'][-1];q=s.get('semantic_at_ready')or{};origin=probe['browser']['time_origin']
 start=origin+s['start_ms'];end=d['observation_end_epoch_ms']
 for previous in probe['samples']:acc[(origin,previous['id'])]={'file':str(p.relative_to(ROOT)), 'sample':previous}
 summary={'id':d['id'],'file':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(raw).hexdigest(),'scenario_assertions':d['assertions'],'expected':d['expected'],'sample_id':s['id'],'type':s['type'],'target':s.get('target'),'start_url':s['start_url'],'end_url':s['end_url'],'semantic_ready_ms':s.get('scenario_ready_ms'),'tool_upper_bound_ms':end-d['observation_start_epoch_ms'],'probe_sha256':probe['metadata']['probe_sha256'],'system_commit':probe['metadata']['system_commit'],'viewport':probe['browser']['viewport'],'completion_reason':s['completion_reason'],'request_error_count':s['request_error_count'],'pending_at_end':s['pending_at_end'],'headings':[x['label']for x in q.get('headings',[])],'controls':q.get('controls',[]),'regions':[{'id':x['id'],'length':x['length'],'first':x['first'],'last':x['last']}for x in q.get('regions',[])], 'independent_checks':{'event_within_cua_window':d['observation_start_epoch_ms']-2<=start<=end,'semantic_url_equals_final':q.get('url')==s['end_url']==probe['url'],'stable':s['completion_reason']=='stable','no_request_errors':s['request_error_count']==0,'no_pending':not any(s['pending_at_end'].values()),'foreground':s['visibility_at_start']==s['visibility_at_end']=='visible'},'observation_excerpt':'\n'.join(l for l in d['observation'].splitlines() if any(t in l for t in ['[selected]','[pressed]','- dialog ','- img ','- heading ','0 项素材','没有符合']))}
 summary['group']=re.sub(r'-\d+$','',d['id']);rows.append(summary)
byid={x['id']:x for x in rows};groups=collections.defaultdict(list)
for x in rows:groups[x['group']].append(x)
failed=[x for x in rows if not all(x['scenario_assertions'].values())]
invalid_checks=[{'id':x['id'],'checks':x['independent_checks']}for x in rows if not all(x['independent_checks'].values())]
# Expected tokens are independent of broad original scenario asserts: verify actual selected state/route and populated content.
for x in rows:
 g=x['group'];url=x['end_url'];h='|'.join(x['headings']);cs=x['controls'];ok=True;notes=[]
 if g.startswith('S1-novel'):ok=('refinement-08-' if g.endswith('8') else 'refinement-09-')in url and ('第八版'if g.endswith('8')else'定稿候选')in h
 elif g.startswith('S2-version'):ok=('5cec42bf63f56983d1091b28bbcfcfdef468ea85ce6d062f6e176f194f9e1bbd'if g.endswith('8')else'73e1de6bd288b2211f0cd8001cc07a3f5863f99f3414bae67a0a77a3ec899a58')in url and ('精修七'if g.endswith('8')else'精修九定稿候选')in h
 elif g.startswith('S3-version'):ok=('script=screenplay-03-'if g.endswith('3')else'script=screenplay-04-')in url and 'S001 米铺门口'in h
 elif g.startswith('S3-episode')or g.startswith('S3-scene'):
  scene='s003'if g=='S3-episode2'else's002'if g=='S3-scene2'else's001';ok=('scene='+scene)in url and scene.upper()in h
 elif g.startswith('D1-episode')or g.startswith('D1-scene')or g=='D1-nav':
  scene='s003'if g=='D1-episode2'else's002'if g=='D1-scene2'else's001';ok=('breakdown_scene=preparation-'+scene)in url and scene.upper()in h and 'SH'in h
 elif g in ('D2-aheng','D2-liji'):ok=('production_entity=entity-a-heng'if g=='D2-aheng'else'production_entity=entity-li-ji')in url and ('阿蘅'if g=='D2-aheng'else'李寄')in h and all(t in h for t in ['基础信息','关系','完整状态'])
 elif g=='D3-video':ok='material_media=video'in url and 'SH001'in h and '镜头有声视频候选'in h;notes.append('D3-video-0 的旧预期词“待生成”未出现；实际显示“视频 · 未生成”，独立判定路由与真实无结果方案正确。')
 elif g=='D3-page1':ok='material_media=video'in url and 'need-shot-e01-001-video'in url and 'SH001'in h
 elif g=='D3-page2':ok='material_media=video'in url and 'need-shot-e02-008-video'in url and 'SH008'in h
 elif g=='D3-search-none-key':ok='material_search=zzq'in url and '0 项素材'in x['observation_excerpt'];notes.append('性能起点为最后一个可信 input q，不等于首次输入 z 的完整检索动作。')
 elif g.startswith('D3-clear')or g.startswith('D3-search-clear')or g=='D3-reset-search':ok='material_media=&material_status=&material_search='in url and 'S001'in h
 elif g=='D3-generated':ok='material_status=generated'in url and 'material_version=2'in url and '阿禾'in h;notes.append('AO-UX-002 表达歧义成立；历史聚合筛选及当前版本 2 无结果符合契约，不改记筛选逻辑失败。')
 elif g=='X-image-zoom':ok='material_version=1'in url and 'asset-fg3-a-he-base-image-01'in url and '- dialog "阿禾'in x['observation_excerpt'] and '- img "阿禾'in x['observation_excerpt'];notes.append('准确旧版及放大弹窗输出已观察；没有图片解码完成或完整图幅几何，不作为媒体可见真值或性能重复样本。')
 elif g=='X-source-locate':ok='refinement-08-lantern-home-v8'in url and any(r['id']=='comment-panel'for r in x['regions']);notes.append('AO-UX-001 原文被遮挡已由截图及 geometry 单独证实；就绪探针不能将该路径判为用户验收通过，flash 延时可能进入 DOM 稳定口径。')
 else:
  tabs={'A-nav':'故事创作','A1-tab':'故事创作','A2-tab':'生产制作','C1-tab':'故事项目','C2-tab':'系统与 AI','S-nav':'故事采编','S1-tab':'故事采编','S2-tab':'故事结构','S3-tab':'剧本创作','D2-tab':'实体管理','D3-tab':'素材管理'}
  if g in tabs:ok=any(c.get('selected')=='true'and c.get('label')==tabs[g]for c in cs)and bool(x['regions'])
 x['independent_scenario_match']=ok;x['notes']=notes
 x['performance_sample_eligible']=all(x['scenario_assertions'].values())and all(x['independent_checks'].values())and ok and g not in ('X-image-zoom','X-source-locate')
statistics_rows=[]
for g,xs in groups.items():
 good=[x for x in xs if x['performance_sample_eligible']];vals=[x['semantic_ready_ms']for x in good]
 statistics_rows.append({'group':g,'raw_n':len(xs),'eligible_n':len(vals),'raw_ms':vals,'median_ms':statistics.median(vals)if vals else None,'range_ms':[min(vals),max(vals)]if vals else None,'repetition_status':'REPEATED_SCOPED_PROXY'if len(vals)>=5 else'SINGLE_OR_INSUFFICIENT'if vals else'NOT_TIMED_AS_FUNCTIONAL_SUCCESS','excluded_ids':[x['id']for x in xs if not x['performance_sample_eligible']]})
# Original statuses remain; action rows are explicitly partial rather than declaring all stated edge cases passed.
m=json.loads((OUT/'coverage-draft.json').read_text());index={x['id']:x for x in m['coverage']}
nav={'A1-02':['A1-tab'],'A2-02':['A2-tab'],'S1-02':['S1-tab'],'S2-02':['S2-tab'],'S3-02':['S3-tab'],'D1-02':['D1-nav'],'D2-02':['D2-tab'],'D3-02':['D3-tab'],'C1-02':['C1-tab'],'C2-02':['C2-tab']}
updates={}
for i,gs in nav.items():updates[i]=(gs,'桌面可信 click 后子页及限定正文内容一致','键盘左右/Home/End、前进后退、窄屏、快速切页竞态及未提交草稿未覆盖')
updates.update({
'S1-03':(['S1-novel8','S1-novel9'],'精修八/九各 5 次切换，长文区域 28673/29408 UTF-16 长度与标题匹配；展开目录输出可见','其余资料/精修版本、实际章节点击、收起、无效章节、末章和逐段滚动未覆盖'),
'S1-04':(['X-source-locate'],'精修八已有评论打开与定位动作；原圈选仍被面板覆盖，登记 AO-UX-001','拖选、跨段 Unicode、正文外松手、已关闭评论、无遮挡定位成功未覆盖'),
'S2-03':(['S2-version8','S2-version10'],'结构第 8/10 稿各 5 次切换，准确修订和内容匹配','章节、旧链接恢复、各类评论及图片解码未覆盖'),
'S3-03':(['S3-version3','S3-version4','S3-episode1','S3-episode2','S3-scene1','S3-scene2'],'剧本三/四、E01/E02、S001/S002/S003 的有序切换和准确上下文；每条方向 5 次','全 17 集 42 场、末场、快速切换竞态、草稿和旧评论定位未覆盖'),
'D1-03':(['D1-episode1','D1-episode2','D1-scene1','D1-scene2'],'E01/E02 各 1 次；S001/S002 各 5 次，准确场修订及逐镜正文输出匹配','整场逐镜真实滚动、末集末场、历史镜链接、快速切换及窄屏未覆盖'),
'D2-04':(['D2-liji','D2-aheng'],'李寄/阿蘅各 5 次实体切换，四区、基础状态及素材默认输出一致','没有遍历 13/6 状态、无素材、实体历史切换及竞态；关系控件存在不等于已操作'),
'D3-03':(['D3-video','D3-clear','D3-generated','D3-search-none-key','D3-reset-search','D3-search-clear','D3-search-clear-final'],'视频筛选、历史有结果筛选、键入 zzq 的零结果和清除均有实际输出；AO-UX-002 独列','集场联动、组合筛选、无需求历史原件未覆盖；失败旧预期 D3-video-0 保留并排除性能汇总'),
'D3-04':(['D3-page1','D3-page2'],'视频第 1/2 页往返各 5 次，首项 SH001/SH008 及准确需求修订一致','没有最后一页边界、筛选外准确链接、刷新和长名称交互证据'),
'D3-05':(['D3-generated','X-image-zoom'],'同一阿禾素材当前版本 2 无结果与历史版本 1 单候选图像实际输出已见；版本 1 精确 ASSET 修订匹配','素材版本 select 的原生选择不是独立同条件计时；多候选、多组成、旧别名和快速切换未覆盖'),
'X-04':(['X-image-zoom'],'准确阿禾版本 1 图像的放大按钮可信 click，具名 dialog 与 img 出现','单次功能输出；全幅/解码、关闭、焦点、音视频播放/静音/seek/选段及嵌套返回未覆盖'),
'X-06':(['A-nav','S-nav','D1-nav'],'已观察三种主入口及各已测子页的普通有序导航','未测快速切换、迟到响应、无效参数、窄屏；不能由逐个等待完成推断竞态通过')})
for i,(gs,covered,missing)in updates.items():
 xs=[x for x in rows if x['group']in gs];row=index[i]
 row['browser_status']='PARTIAL_WITH_CONFIRMED_FINDING'if i=='S1-04'else'PARTIAL_FUNCTIONAL_OUTPUT_OBSERVED'
 row['backend_status']='NOT_INDEPENDENTLY_VERIFIED';row['performance_status']='SCOPED_ACTION_PROXY_SAMPLES_AVAILABLE'if any(x['performance_sample_eligible']for x in xs)and i not in ('D3-05','X-04','X-06')else'FUNCTIONAL_ONLY_OR_DIAGNOSTIC_SINGLE_SAMPLE'
 row['raw_samples']=[{k:x[k]for k in ('id','file','sha256','sample_id','semantic_ready_ms','tool_upper_bound_ms','performance_sample_eligible','independent_scenario_match','notes')}for x in xs]
 row['functional_coverage']={'observed':covered,'not_verified':missing,'evidence_groups':gs,'complete_action':False}
 row['note']=covered+'；'+missing;row['performance_groups']=gs;row['audit_detail']='action-baseline-audit.json'
for row in m['coverage']:
 if row['id']not in updates and not row['id'].endswith('-01'):
  row['not_run_reason']='本批可信交互文件未覆盖该动作；现有按钮/表单出现在快照中不代表已经操作或验证。'
for i in ('X-01','X-02'):
 index[i]['note']='本批只观察现有评论面板开/关（累积样本 79/81）；没有提交、编辑、关闭/重开记录、草稿或快捷键操作，保持 NOT_RUN。'
index['P1-06']['note']='初始页面有未生成镜头方案输出；未见提示词引用/实际输入的独立交互，不标为功能通过。真实视频结果因该预览未生成而不适用。'
m['status']='12页初始语义基线与136份交互证据已审；动作按已观察范围标为部分覆盖，未声明整项验收通过'
m['action_baseline_audit']='action-baseline-audit.json';m['action_audited_at']=datetime.now(timezone.utc).isoformat()
counts=collections.Counter(x['browser_status']for x in m['coverage'])
nonstable=[{'file':v['file'],'sample_id':v['sample']['id'],'type':v['sample']['type'],'target':v['sample'].get('target'),'completion_reason':v['sample']['completion_reason'],'request_error_count':v['sample']['request_error_count']}for v in acc.values()if v['sample']['completion_reason']!='stable']
report={'task_id':m['task_id'],'audited_at':m['action_audited_at'],'files':len(files),'designated_action_samples':len(rows),'cumulative_unique_samples':len(acc),'probe_sha256s':sorted(set(x['probe_sha256']for x in rows)),'code_commits':sorted(set(x['system_commit']for x in rows)),'original_assertion_failures':[{'id':x['id'],'expected':x['expected'],'assertions':x['scenario_assertions']}for x in failed],'independent_check_exceptions':invalid_checks,'independent_scenario_mismatches':[x['id']for x in rows if not x['independent_scenario_match']],'superseded_samples':nonstable,'coverage_status_counts':dict(counts),'rows':rows,'groups':statistics_rows,'limitations':['最后可信事件到截断语义快照的就绪代理；不等于绘制/解码/无遮挡/滚动完成','动作外层 CUA 起止含工具开销，作为上界，不与探针毫秒直接比较','每份文件含累积 samples，主动作只取末样本，以 time_origin + sample_id 去重，不将旧样本重复计入','原生 select 中选版本 1 的完成未作为独立 probe 样本捕获；后续放大文件只证明准确版本 1 状态输出','搜索样本从最后可信 input q 开始，不冒充从首字 z 开始','只有桌面 1440x900；初始性能基线仍独列，不用单次功能操作冒充重复性能样本']}
(OUT/'action-baseline-audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
(OUT/'coverage-draft.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
md=['# 交互基线与功能覆盖独立审计','',f'本次轻量审查 {len(files)} 份现存 `browser/*baseline*action.json`，未操作浏览器或运行测试。它们包含 {len(acc)} 个去重后的累积探针样本，指定动作 {len(rows)} 个；不能把每份文件内的旧累积样本重复算成新的验证。','', '61 项覆盖保持分层：12 项初始内容/同刻语义基线沿用前份审计；本批更新 21 项为部分功能覆盖（其中原评论定位保留 AO-UX-001 失败）；其余 28 项没有实际动作证据，保持 NOT_RUN。部分覆盖不是整项通过，更不是其中所有重要状态均已验证。','', '## 失败、限制与重要发现','','- `D3-video-0` 原断言找“待生成”失败，真实内容为“视频 · 未生成”。独立核对路由、SH001、素材版本 1 及方案正常；保留原失败，不改写原文件，并从性能统计排除。其后 `D3-video-1…5` 为 5 个有效同方向样本。','- 累积日志有 15 个被后续输入/点击替代的搜索样本（10 个 z/zz 输入、5 个失焦 change）；没有同刻终态，不用于性能中位数，不把它们自动定为应用故障。','- `X-source-locate-0` 的原断言虽通过，独立截图/几何证明原文受遮挡，保持 AO-UX-001。单次 DOM 稳定也可能包含 flash 样式等待，不表示无遮挡阅读成功。','- `D3-generated-0` 的历史聚合筛选正确，但列表与当前版“未生成”有表达歧义，见 `ux002-review.md`。该问题与性能计时分开。','- `X-image-zoom-0` 在准确旧 ASSET 修订/素材版本 1 上输出放大弹窗与 img；可认定一次功能输出，尚无解码/全幅/关闭证据。原生 select 中的版本选择完成未被独立探针记录，因此不声称已测版本切换性能。','- 场景断言须结合所选控件、准确 URL、标题和正文。仅正文出现关键词不足以证明版本切换；初始 v3 的隐藏子页文本及截断限制仍适用。','- 搜索计时起点是最后一个可信 input（q）；不是输入完整 zzq 的首字起点。所有时间均保留这个口径。','','## 已观察的动作及仍缺的状态','','| 项目 | 本批实际覆盖 | 尚未覆盖 |','| --- | --- | --- |']
for i,(gs,c,u)in updates.items():md.append('| '+i+' '+index[i]['action']+' | '+c+' | '+u+' |')
md+=['','## 重复样本与单次操作','','下表只列最后可信动作到 v3 语义快照的毫秒数，包含探针采集开销；不等同于图像解码、完整绘制或用户可读无遮挡真值。原始每次值、文件 SHA、准确路由、语义与 CUA 上界见 `action-baseline-audit.json`。各组独立，不能把不同切换方向合并后宣称全页提升。','','| 场景组 | 原始/可用样本 | 中位 ms | 最小–最大 ms | 口径 |','| --- | ---: | ---: | ---: | --- |']
for g in statistics_rows:
 fmt=lambda x:'—'if x is None else f'{x:.1f}'
 md.append(f"| {g['group']} | {g['raw_n']}/{g['eligible_n']} | {fmt(g['median_ms'])} | {'—'if not g['range_ms']else'–'.join(fmt(x)for x in g['range_ms'])} | {g['repetition_status']} |")
md+=['','## 未测与不适用','','未测项目继续在 `coverage-draft.json` 逐行保持 NOT_RUN，包含制作思路目录/故障恢复、结构图像/SVG操作、长场评论、制作归属筛选及弹窗、采纳/采用循环、配置写入、评论写入/草稿/润色、导出恢复等。后台 worker 独立读写/性能证据尚未在本审计归并，不以后台通过替代页面。','','preview 无 ASSEMBLY/DELIVERABLE，真实组合/成片预览不适用；未生成镜头只验证已有方案/空态，不生成素材填补矩阵。页面存在可点按钮不等于实际操作通过。','','本审计仅更新代理自己的覆盖草案与证据解释，主报告及产品未修改。']
(OUT/'action-baseline-audit.md').write_text('\n'.join(md)+'\n')
print(json.dumps({'files':len(files),'counts':dict(counts),'failed':[x['id']for x in failed],'check_exceptions':invalid_checks,'scenario_mismatches':report['independent_scenario_mismatches'],'superseded':len(nonstable)},ensure_ascii=False,indent=2))
