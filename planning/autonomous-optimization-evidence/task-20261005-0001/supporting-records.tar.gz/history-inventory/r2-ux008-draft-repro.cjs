// Bounded offline investigation: real production methods, local DOM/HTTP fixtures.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),{createRequire}=require('node:module');
const base=path.resolve('.runtime/autonomous-optimization/history-inventory/r2-ux008-ux009-baseline'),out=path.resolve('.runtime/autonomous-optimization/history-inventory');
function harness(name,marker,expose){
 const file=path.join(base,'tests',name),source=fs.readFileSync(file,'utf8').split(marker)[0];
 const c={require:createRequire(file),__dirname:path.dirname(file),process,console,setImmediate,URL,URLSearchParams};vm.createContext(c);vm.runInContext(source+'\n'+expose,c);return c;
}
async function p2(){
 const h=harness('production_change.test.cjs',"test('a late saved judgment",'globalThis.make=fixture;'),f=h.make(),c=f.context;
 c.document.querySelectorAll=s=>s==='#production-index button'?f.host.all().filter(n=>n.tag==='button'&&n.dataset.objectId):[];
 await c.loadProductionWorkspace();
 // Re-render the original index after initial exact read, like returning/filtering.
 f.byLabel('制作场次').onchange();await new Promise(r=>setImmediate(r));
 const cards=()=>f.host.all().filter(n=>n.tag==='button'&&n.dataset.objectId),snap=()=>({selected:c.state.productionSelected?.object_id,url:c.location.href,cards:cards().map(n=>({id:n.dataset.objectId,pressed:n.attrs['aria-pressed']}))});
 const before=snap(),ids=cards().map(n=>n.dataset.objectId);await c.openProductionRecord(ids[1]);const after=snap();await c.openProductionRecord(ids[0]);const back=snap();
 return {before,after,back,expected_selected_pressed_true:after.cards.find(r=>r.id===after.selected)?.pressed==='true',old_still_pressed:after.cards.find(r=>r.id===before.selected)?.pressed==='true',fixture_note:'Real loadProductionWorkspace/openProductionRecord/reviewSmallCard; HTTP records technical and reader rendering stubbed. CSS inspected separately.'};
}
function draft(mode,storageFailure,method='locate',switchContext=false,caret=false){
 const h=harness('polish_draft.test.cjs','for(const success of [true,false])', 'globalThis.make=fixture;globalThis.E=Element;');
 const f=h.make(),c=f.ctx,E=h.E;
 c.window={innerWidth:1440,addEventListener(){}};c.CSS={escape:s=>s};c.getSelection=()=>({removeAllRanges(){}});c.location={href:'http://fixture/?workspace='+mode};c.history={pushState(_a,_b,u){c.location.href=String(u)}};
 const sourceView=new E('section');sourceView.id='source-view';const block=new E('p');block.id='block-p';block.scrollIntoView=()=>{};sourceView.append(block);f.root.append(sourceView);
 const scriptReader=new E('section');scriptReader.id='screenplay-reader';f.root.append(scriptReader);const structureReader=new E('section');structureReader.id='structure-reader';f.root.append(structureReader);
 const originalQuery=c.document.querySelector;c.document.querySelector=s=>s.startsWith('[data-structure-block=')||s.startsWith('#screenplay-reader [data-block-id=')?block:originalQuery(s);
 c.renderDocument=()=>{};c.renderStructureReader=()=>{};c.renderScriptReader=()=>{};c.hideSelectionAction=()=>{};c.renderScriptIndex=()=>{};c.renderScriptCommentCounts=()=>{};
 // Only reader layout/panel geometry are replaced. Actual editor, locator and choose methods run.
 c.togglePanel=()=>{f.root.querySelector('#comment-panel').hidden=!f.root.querySelector('#comment-panel').hidden};
 const comment={id:'existing',target_object_id:'source-a',target_revision_id:'source-rev',anchor:{type:'text',block_id:'p',end_block_id:'p',start:0,end:5,quote:'Exact'}};
 if(mode==='story.outline'){
  vm.runInContext(fs.readFileSync(path.join(base,'review_desk/static/structure.js'),'utf8'),c);c.renderStructureReader=()=>{};
  Object.assign(c.state,{workspace:mode,structureRevision:'outline-v1',structure:{current_revision:'outline-v1',revisions:[{id:'outline-v1',payload:{sections:[]}},{id:'outline-v2',payload:{sections:[]}}]}});comment.target_object_id='story-structure';comment.target_revision_id=switchContext?'outline-v2':'outline-v1';
 }else if(mode==='story.script'){
  vm.runInContext(fs.readFileSync(path.join(base,'review_desk/static/screenplay.js'),'utf8'),c);c.renderScriptReader=()=>{};c.renderScriptIndex=()=>{};c.renderScriptCommentCounts=()=>{};
  const ep=(id)=>({object_id:id,id:id+'-v1',payload:{title:id,scenes:[{id:'s1',block_ids:['p'],heading:'s1'},{id:'s2',block_ids:['q'],heading:'s2'}]}});
  Object.assign(c.state,{workspace:mode,screenplays:[{object_id:'script',episodes:[ep('episode1'),ep('episode2')]}],screenplayVersion:'script',screenplayEpisode:'episode1',screenplayScene:'s1'});comment.target_object_id=switchContext===true?'episode2':'episode1';if(switchContext==='scene'){comment.anchor.block_id='q';comment.anchor.end_block_id='q';}comment.target_revision_id=comment.target_object_id+'-v1';
 }
 if(mode!=='story.sources'){f.storage.set(c.key(),'old durable text');c.renderComments()}
 if(mode==='story.outline')c.rememberStoryDraft();if(mode==='story.script')c.rememberScriptDraft();
 const originalKey=c.key(),savedGet=c.localStorage.getItem,savedSet=c.localStorage.setItem;
 if(storageFailure==='write')c.localStorage.setItem=()=>{throw Error('quota exceeded')};
 f.input().value='  unique unsaved opinion\n';f.input().listeners.input();f.input().setSelectionRange(caret?7:3,caret?7:9,caret?'forward':'backward');
 if(storageFailure==='read')c.localStorage.getItem=()=>{throw Error('storage read denied')};
 const before=f.input();let exception=null;
 try{if(method==='toggle')c.toggleCommentsFromReader();else if(mode==='story.sources')c.locateSourceComment(comment);else c.locateComment(comment)}catch(e){exception=e.message}
 const after=f.input(),result={mode,storageFailure,method,switchContext,originalKey,currentKey:c.key(),exception,beforeValue:before.value,afterValue:after?.value??null,sameNode:after===before,selectionBefore:caret?[7,7,'forward']:[3,9,'backward'],selectionAfter:after?[after.selectionStart??null,after.selectionEnd??null,after.selectionDirection??null]:null,persisted:f.storage.get(originalKey)??null,anchorAfter:c.state.anchor,messages:f.messages,networkRequests:f.requests.length};
 if(storageFailure==='read'){c.localStorage.getItem=savedGet;try{c.renderComments();result.valueAfterReadRecovery=f.input()?.value??null}catch(e){result.readRecoveryError=e.message}}
 if(switchContext){
  c.localStorage.getItem=savedGet;c.localStorage.setItem=savedSet;
  if(mode==='story.outline')c.chooseStructureRevision('outline-v1');else c.chooseScript('script','episode1','s1');
  result.returnedValue=f.input()?.value??null;result.returnedAnchor=c.state.anchor;
 }
 return result;
}
(async()=>{
 const started=performance.now(),results={p2:await p2(),draft:[]};
 for(const mode of ['story.sources','story.outline','story.script'])for(const failure of ['none','write','read']){
  try{results.draft.push(draft(mode,failure))}catch(e){results.draft.push({mode,failure,harness_error:e.stack})}
 }
 for(const failure of ['write','read'])results.draft.push(draft('story.sources',failure,'toggle'));
 for(const mode of ['story.outline','story.script'])results.draft.push(draft(mode,'write','locate',true));
 results.draft.push(draft('story.script','write','locate','scene'));results.draft.push(draft('story.sources','write','locate',false,true));
 results.elapsed_ms=performance.now()-started;results.executed_at=new Date().toISOString();
 fs.writeFileSync(path.join(out,'r2-ux008-draft-repro-expanded.json'),JSON.stringify(results,null,2)+'\n');
 console.log(JSON.stringify(results,null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
