# -*- coding: utf-8 -*-
"""Compare only saved page probe JSON. No service/browser/test activity."""
import json,hashlib,statistics,collections,datetime
from pathlib import Path
R=Path(__file__).resolve().parent.parent;O=R/'history-inventory'
PAGES={'A1':'制作思路／故事创作','A2':'制作思路／生产制作','S1':'故事创作／故事采编','S2':'故事创作／故事结构','S3':'故事创作／剧本创作','D1':'制作设定／制作拆解','D2':'制作设定／实体管理','D3':'制作设定／素材管理','P1':'全剧制作／镜头制作','P2':'全剧制作／组合与历史','C1':'系统管理／故事项目','C2':'系统管理／系统与 AI'}
SHA='74a80b7f730a450f4fc00f5424120f8f60406e7fe9c4c65234e3d317958a804c'
def quantile(v,p):
 s=sorted(v);n=(len(s)-1)*p;i=int(n);return s[i]+(s[min(i+1,len(s)-1)]-s[i])*(n-i)
def stats(v):
 if not v:return {'n':0}
 med=statistics.median(v);return {'n':len(v),'raw_ms':v,'median_ms':med,'mean_ms':statistics.mean(v),'p95_ms':quantile(v,.95),'q1_ms':quantile(v,.25),'q3_ms':quantile(v,.75),'iqr_ms':quantile(v,.75)-quantile(v,.25),'mad_ms':statistics.median(abs(x-med)for x in v),'min_ms':min(v),'max_ms':max(v)}
data={};exceptions=[]
for phase in ['baseline','candidate1']:
 data[phase]=collections.defaultdict(list)
 for p in sorted((R/'browser').glob('*-'+phase+'-semantic-*.json')):
  raw=p.read_bytes();d=json.loads(raw);probe=d['probe'];s=probe['samples'][-1];sem=s['semantic_at_ready'];scenario=d['scenario'];idx=int(p.stem.rsplit('-',1)[-1]);nav=probe['navigation'][-1]['type']
  checks={'probe_sha':probe['metadata']['probe_sha256']==SHA,'assertions':all(d['assertion'].values()),'stable':s['completion_reason']=='stable','no_pending':not any(s['pending_at_end'].values()),'no_request_errors':s['request_error_count']==0,'foreground':s['visibility_at_start']==s['visibility_at_end']=='visible','selected_tab':any(c.get('label')==scenario['tabLabel']and c.get('selected')=='true'for c in sem['controls']),'region_nonempty':any(v['id']==scenario['regionId']and v['length']>0 for v in sem['regions']),'comments_closed':not any(v['id']=='comment-panel'for v in sem['regions']),'scenario_and_capture_time':abs(s['scenario_ready_ms']-(sem['capture_finished_ms']-s['start_ms']))<.01}
  if not all(checks.values()):exceptions.append({'file':p.name,'checks':checks})
  head=[x['label']for x in sem['headings']];controls=[{k:x.get(k)for k in ['id','label','tag','value','pressed','selected']}for x in sem['controls']]
  data[phase][scenario['id']].append({'index':idx,'file':str(p.relative_to(R)),'sha256':hashlib.sha256(raw).hexdigest(),'navigation_type':nav,'semantic_ready_ms':s['scenario_ready_ms'],'stability_proxy_ms':s['content_ready_ms'],'tool_upper_bound_ms':d['observation_end_epoch_ms']-d['observation_start_epoch_ms'],'capture_ms':s['semantic_capture_ms'],'start_epoch_ms':d['observation_start_epoch_ms'],'end_epoch_ms':d['observation_end_epoch_ms'],'end_url':s['end_url'],'headings':head,'selected_controls':controls,'region_lengths':{x['id']:x['length']for x in sem['regions']},'semantic_content_hash':hashlib.sha256(json.dumps({'headings':head,'controls':controls,'regions':sem['regions']},ensure_ascii=False,sort_keys=True).encode()).hexdigest(),'checks':checks,'browser':probe['browser'],'metadata':probe['metadata']})
 for pg in data[phase]:data[phase][pg].sort(key=lambda x:x['index'])
comparisons=[]
for page,name in PAGES.items():
 row={'page':page,'name':name,'phases':{},'content_comparison':[]}
 for phase in data:
  xs=data[phase][page];row['phases'][phase]={'samples':xs,'all':stats([x['semantic_ready_ms']for x in xs]),'navigate':stats([x['semantic_ready_ms']for x in xs if x['navigation_type']=='navigate']),'reload':stats([x['semantic_ready_ms']for x in xs if x['navigation_type']=='reload'])}
 for b,c in zip(data['baseline'][page],data['candidate1'][page]):
  row['content_comparison'].append({'index':b['index'],'same_end_url':b['end_url']==c['end_url'],'same_headings':b['headings']==c['headings'],'same_controls':b['selected_controls']==c['selected_controls'],'same_region_lengths':b['region_lengths']==c['region_lengths'],'same_semantic_content':b['semantic_content_hash']==c['semantic_content_hash']})
  if page=='D3':
   old=json.loads((R/b['file']).read_text())['observation'];new=json.loads((R/c['file']).read_text())['observation']
   for after,before in [('生成结果（含历史版本）','生成状态'),('有生成结果','已生成'),('无生成结果','未生成'),('有结果','已生成'),('无结果','未生成')]:new=new.replace(after,before)
   row['content_comparison'][-1]['full_cua_snapshot_equal_after_documented_label_normalization']=old==new
 b=row['phases']['baseline']['reload'];c=row['phases']['candidate1']['reload'];delta=b['median_ms']-c['median_ms'];threshold=max(b['iqr_ms'],c['iqr_ms'],3*b['mad_ms'],3*c['mad_ms']);separated=(c['q3_ms']<b['q1_ms']if delta>0 else b['q3_ms']<c['q1_ms']);above=abs(delta)>threshold and separated
 verdict='OBSERVED_IMPROVEMENT_ABOVE_TYPICAL_VARIATION'if above and delta>0 else'UNEXPLAINED_SLOWER_SIGNAL'if above else'NO_PAGE_BENEFIT_ESTABLISHED'
 row['reload_comparison']={'median_reduction_ms':delta,'typical_variation_threshold_ms':threshold,'nonoverlap_iqr':separated,'exceeds_rule':above,'verdict':verdict}
 if page=='P1':row['interpretation']='本批镜头制作页面的语义就绪代理刷新耗时改善超过保守典型波动规则；有限顺序前后观察，仍非随机交错因果实验，不推断固定收益比例。'
 elif page=='C2':row['interpretation']='两组刷新及 navigate 均较慢；未改业务路径，不归因本轮后端或评论布局，保留未解释变慢信号，拟同轮窄复测。'
 elif page=='D3':row['interpretation']='中位数下降但未超过本审查保守典型波动阈值；标签变化解释区域文本长度变化，不据此确认页面提速。'
 else:row['interpretation']='本批未证实超出典型波动的页面收益；局部变快/变慢不归因优化。'
 comparisons.append(row)
# C2 attribution: disjoint intervals sum to scenario time; use means for additive decomposition.
c2={'phases':{},'limitations':['fetch header wait contains browser queuing, connection, server scheduling/processing and network; not API CPU duration','last_network_at_ms covers instrumented fetch/body completion; no per-response body parse breakdown','longtasks empty means no recorded Long Task entries; not proof of zero JS work or frame loss','bootstrap resource timings overlap and queue; durations cannot be summed as independent CPU costs']}
for phase in data:
 rawrows=[];api=collections.defaultdict(list);navs=collections.defaultdict(list);resources=collections.defaultdict(list)
 for x in data[phase]['C2']:
  d=json.loads((R/x['file']).read_text());p=d['probe'];s=p['samples'][-1];rs=p['requests'];first=min(v['start_ms']for v in rs);last=s['last_network_at_ms'];ready=s['scenario_ready_ms'];static=[v for v in p['resources']if v['initiatorType']in('script','link')]
  v={'index':x['index'],'type':x['navigation_type'],'navigation_to_first_fetch_ms':first,'first_fetch_to_last_body_ms':last-first,'last_body_to_semantic_ms':ready-last,'scenario_ready_ms':ready,'last_static_resource_end_ms':max(v['responseEnd']for v in static),'last_body_to_last_dom_ms':s['last_dom_mutation_at_ms']-last,'last_dom_to_semantic_ms':ready-s['last_dom_mutation_at_ms'],'longtask_count':len(p['longtasks']),'longtask_duration_ms':sum(t.get('duration',0)for t in p['longtasks']),'resource_count':len(p['resources']),'request_count':len(rs),'static_count':len(static)}
  rawrows.append(v)
  if x['navigation_type']!='reload':continue
  for a in rs:api[a['url']].append({'index':x['index'],'start_ms':a['start_ms'],'headers_ms':a['headers_ms'],'header_wait_ms':a['headers_ms']-a['start_ms'],'status':a['status']})
  for key in ('domInteractive','domContentLoadedEventEnd','domComplete','loadEventEnd','responseStart','responseEnd'):navs[key].append(p['navigation'][-1][key])
  for a in static:resources[a['name'].split('/')[-1]].append({'index':x['index'],'start_ms':a['startTime'],'response_end_ms':a['responseEnd'],'duration_ms':a['duration'],'decoded_body_bytes':a['decodedBodySize'],'transfer_bytes':a['transferSize']})
 reload=[v for v in rawrows if v['type']=='reload'];numeric=[k for k in rawrows[0]if k not in ('index','type')]
 c2['phases'][phase]={'rows':rawrows,'reload_components':{k:stats([v[k]for v in reload])for k in numeric},'reload_api_headers':{k:{'samples':v,'header_wait':stats([x['header_wait_ms']for x in v])}for k,v in api.items()},'reload_navigation':{k:stats(v)for k,v in navs.items()},'reload_static_resources':{k:{'samples':v,'response_end':stats([x['response_end_ms']for x in v]),'duration':stats([x['duration_ms']for x in v])}for k,v in resources.items()}}
c2['mean_component_differences']={k:c2['phases']['candidate1']['reload_components'][k]['mean_ms']-c2['phases']['baseline']['reload_components'][k]['mean_ms']for k in ('navigation_to_first_fetch_ms','first_fetch_to_last_body_ms','last_body_to_semantic_ms','scenario_ready_ms','last_static_resource_end_ms')}
patch=R/'reviews/candidate-browser-1.patch'
report={'task_id':'task-20261005-0001','audited_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'80 baseline + 80 candidate1 saved page samples; read only analysis','probe_sha256':SHA,'candidate_identity':{'metadata_base_commit':'b874b959af9c918a482e8488dc25cb0204ab5772','patch':str(patch.relative_to(R)),'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'backend_commit_subsequently_recorded':'7ba65822307d2099502b3f2046a943c100d6a565','provenance_note':'root records Python loaded AO-PERF001 and static assets included UX candidates; samples metadata uses precommit base + saved patch, not a clean 7ba6582-only browser run'},'stats_method':{'quantiles':'Type 7 linear interpolation at (n-1)*p','p95_limitation':'n=5/10 and reload n=4/9: descriptive near-maximum sample quantile, not calibrated production tail estimate','iqr':'Q3-Q1','mad':'median(abs(x-median(x))); raw unscaled milliseconds','classification':'reload median difference exceeds max(IQR_baseline,IQR_candidate,3*MAD_baseline,3*MAD_candidate) and IQR intervals do not overlap; descriptive conservative audit rule, not significance test or preregistered causal study','cache':'navigate and reload are browser navigation types, not proven cold OS/HTTP cache states; per-page stratified, same sequential batch protocol'},'exceptions':exceptions,'comparisons':comparisons,'c2_decomposition':c2,'global_limitations':['12 pages have one navigate each phase: no repeated navigate inference','same machine/browser/viewport/probe and root frozen preview; files do not carry per-navigation DB hash, exact unchanged DB must be supported by root freeze record','phase order baseline then candidate can share environmental/time confounding; no max model control and no fixed speedup promise','comments panel closed in all measured samples: these timings do not measure docking interactions','semantic snapshot captures layout-visible text and controls, not paint, decoding, occlusion, focus readiness or full long-page scroll; use browser UI evidence separately','P2 has no produced ASSEMBLY/DELIVERABLE: initial list/detail timing cannot stand for absent final-media playback']}
(O/'page-performance-candidate1.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
f=lambda v:f'{v:.1f}'
md=['# 页面性能：baseline 与 candidate1 的独立比较','','本审查只分析已有 160 份页面 JSON（两阶段各 80 份），未发起 API、浏览器或测试负载。逐页场景和样本数相同；12 页各有 1 次 navigate，其余为 reload，制作拆解／实体管理／素材管理／镜头制作每阶段总计 10 次，其他页 5 次。','','本批只有 **P1 镜头制作**达到本审查的保守典型波动规则：reload 中位 1385.3 → 1262.7 ms，减少 122.6 ms，两个中间半数区间没有重叠。此为当前隔离环境的页面语义就绪代理改善，不能外推为固定比例、所有操作提速或媒体已可播放。**C2 系统与 AI**存在未解释变慢信号，reload 中位 324.95 → 377.75 ms；不将未改路径的变化归因后端优化或评论避让。其余页未确认收益。','','## 身份、口径和限制','','- 探针实现 SHA 两阶段均为 `'+SHA+'`。160 个指定样本的原断言、准确页签、非空内容、无请求错误、前台及完成状态检查均通过；未覆盖绘制／解码／无遮挡等真实可读边界。','- 基线代码 `b874b959af9c918a482e8488dc25cb0204ab5772`；候选不是同一个干净提交。样本仍记该基底，准确改动保存在 `reviews/candidate-browser-1.patch`，SHA `'+report['candidate_identity']['patch_sha256']+'`。root 记录 Python 已加载 AO-PERF001，之后后端提交为 `7ba65822307d2099502b3f2046a943c100d6a565`；静态同时包含 UX 候选。不要把该批标成只运行后端提交的纯单变量对照。','- Chrome 154、1440 × 900、DPR 1、macOS 26.6.2 arm64、preview 62606 与探针实现保持；同一隔离数据冻结由 root 运行记录证明，样本本身不含每次导航的完整 DB 哈希。','- 每次导航/刷新从浏览器 performance 起点到同刻语义捕获结束，包含捕获开销；CUA 操作起止另存为含工具开销的上界。navigate 不等于已证明的全冷缓存，reload 不等于所有 HTTP/OS 缓存状态相同。','- 所有计时样本评论面板关闭，因此这批不测桌面停靠操作。D3 文案由“生成状态/已生成”澄清为历史结果范围，区域文本由 3091 增为 3178；其他页主要区域长度不变，准确内容/控件另逐样本留证。','- P95 采用 `(n−1)×p` 线性插值，n=5/10（reload=4/9）只可描述本批接近最大值的位置，不能当作可靠生产尾延迟。IQR=Q3−Q1；MAD=各值距中位数的绝对偏差中位数，未做尺度放大。','- 为避免把小漂移写成收益，本审查要求 reload 中位差同时大于两组 IQR 与 3×MAD 的最大值，且两组 IQR 区间不交叠。这是公开的保守描述规则，不是显著性检验或预注册因果实验。原始样本全部保留，不删除慢样本；后续交错窄复测可以更新判断。','','## 逐页全部样本统计','','单位均为 ms；此表完整列出每阶段 n=5/10，含首次 navigate。最终判断优先看下面单列的 reload，不能用一次 navigate 推断冷启动收益。','','| 页面 | n/阶段 | 中位 前→后 | P95 前→后 | IQR 前→后 | MAD 前→后 | 判断 |','| --- | ---: | ---: | ---: | ---: | ---: | --- |']
for v in comparisons:
 b=v['phases']['baseline']['all'];c=v['phases']['candidate1']['all'];label='观察到改善'if v['page']=='P1'else'未解释变慢，待窄复测'if v['page']=='C2'else'未证实收益'
 md.append('| '+v['page']+' '+v['name']+' | '+str(b['n'])+' | '+' | '.join(f(b[k])+' → '+f(c[k])for k in ('median_ms','p95_ms','iqr_ms','mad_ms'))+' | '+label+' |')
md+=['','## navigate 与 reload 分开看','','| 页 | navigate 前→后（各1次） | reload n/阶段 | reload中位 前→后 | reload IQR区间 前→后 | 典型波动阈值 |','| --- | ---: | ---: | ---: | --- | ---: |']
for v in comparisons:
 b=v['phases']['baseline'];c=v['phases']['candidate1'];br=b['reload'];cr=c['reload']
 md.append('| '+v['page']+' | '+f(b['navigate']['median_ms'])+' → '+f(c['navigate']['median_ms'])+' | '+str(br['n'])+' | '+f(br['median_ms'])+' → '+f(cr['median_ms'])+' | ['+f(br['q1_ms'])+', '+f(br['q3_ms'])+'] → ['+f(cr['q1_ms'])+', '+f(cr['q3_ms'])+'] | '+f(v['reload_comparison']['typical_variation_threshold_ms'])+' |')
md+=['','P1 reload 中位减少 122.6 ms，大于阈值 98.7 ms；IQR 1352.4–1407.9 → 1248.9–1272.8。D3 虽下降 47.6 ms、IQR 分离，但没有超过 56.4 ms 的保守阈值，仍归“收益未证实”。D1/D2/P2 的变化与典型波动重叠。C2 的中位增加 52.8 ms，大于阈值 12.0 ms，而且两批所有样本范围也不重叠，因此保留变慢信号；未改路径不能据此被说成优化收益或已确定代码回退。','','## 原始数组','','下列按样本编号排列，首项是 navigate，其余均为 reload。完整精度、P95/IQR/MAD、文件 SHA、环境、准确 URL、语义控件和每个检查项保存在同名 JSON。','']
for v in comparisons:
 md+=['- '+v['page']+' 基线：`'+', '.join(f(x)for x in v['phases']['baseline']['all']['raw_ms'])+'`；候选：`'+', '.join(f(x)for x in v['phases']['candidate1']['all']['raw_ms'])+'`。']
md+=['','## C2 变慢落在哪一段','','下面仅用 reload 各 4 次，以均值分解可相加的连续区间，避免把不同样本的中位数强行相加。总均值约增加 49.1 ms，其中约 24.1 ms 在首批 API 发起前、23.20 ms 在该批请求/body 完成前，完成后的语义阶段只增加 1.75 ms。','','| 不重叠阶段 | 基线均值 ms | 候选均值 ms | 差值 ms |','| --- | ---: | ---: | ---: |']
labels={'navigation_to_first_fetch_ms':'导航起点 → 首批 API 发起','first_fetch_to_last_body_ms':'首批 API 发起 → 最后 body 完成','last_body_to_semantic_ms':'最后 body 完成 → 语义捕获结束','scenario_ready_ms':'总计'}
for k,label in labels.items():
 b=c2['phases']['baseline']['reload_components'][k]['mean_ms'];c=c2['phases']['candidate1']['reload_components'][k]['mean_ms'];md.append('| '+label+f' | {b:.2f} | {c:.2f} | {c-b:+.2f} |')
md+=['','最后一个静态脚本/CSS 结束均值 139.47 → 163.45 ms（+23.97），与 API 发起前的差值相近。每页均发起同 8 个 API，近乎同时发起但陆续结束；10 份 C2 日志都没有记录 Long Task。浏览器记录的请求等待包含排队、连接、服务调度、处理及网络，不能把下面的单项差值当作服务器 CPU 时间或各项相加。','','| API | 基线 header等待中位 ms | 候选 header等待中位 ms |','| --- | ---: | ---: |']
for k,v in c2['phases']['baseline']['reload_api_headers'].items():md.append('| `'+k+'` | '+f(v['header_wait']['median_ms'])+' | '+f(c2['phases']['candidate1']['reload_api_headers'][k]['header_wait']['median_ms'])+' |')
md+=['','现有证据支持差值主要位于启动资源与整批 API 等待；没有支持“DOM/评论布局造成此变慢”或“某一 API 服务器计算增加”的单独证据。root 已安排后续 C2 baseline/candidate 同轮窄复测；在该证据到来前，保持未解释信号，不能将它省略或宣布回归已经消除。','','本报告仅比较页面初始性能；后台接口改善、功能验收、评论避让效果和媒体播放证据分开交付。无新增付费调用、媒体生成或数据写入。']
(O/'page-performance-candidate1.md').write_text('\n'.join(md)+'\n')
print(json.dumps({'exceptions':exceptions,'verdicts':{v['page']:v['reload_comparison']['verdict']for v in comparisons},'content_differences':{v['page']:[c for c in v['content_comparison']if not all(val for key,val in c.items()if key!='index')]for v in comparisons},'c2_differences':c2['mean_component_differences']},ensure_ascii=False,indent=2))
