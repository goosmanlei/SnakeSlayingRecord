/* Test injection for this document only. Not product code or a performance probe. */
(() => {
  'use strict';
  const ORIGIN = 'http://127.0.0.1:62611';
  if (location.origin !== ORIGIN) return;
  const modes = [
    ['normal', '正常'],
    ['body-set-quota', '仅草稿正文 set 抛 QuotaExceededError'],
    ['meta-set-quota', '仅故事/剧本 meta set 抛 QuotaExceededError'],
    ['get-security', 'getItem 抛 SecurityError'],
  ];
  const events = [];
  let mode = 'normal', storage, proxy, bootError = null, installed = false;
  const descriptor = Object.getOwnPropertyDescriptor(window, 'localStorage');
  const record = (operation, key, error) => {
    events.push({sequence: events.length + 1, at: new Date().toISOString(), mode,
      operation, key: String(key), error});
    publish();
  };
  const bodyKey = key => key.startsWith('review-draft:') && !/:(submission|discussion)$/.test(key);
  const metaKey = key => key.startsWith('review-story-editor:') || key.startsWith('review-script-editor:');
  try {
    storage = window.localStorage;
    const get = storage.getItem.bind(storage), set = storage.setItem.bind(storage);
    // A Storage instance has exotic named properties. Use a document-local
    // proxy instead of replacing Storage.prototype or assigning Storage keys.
    // All unmodified methods are bound to the real Storage receiver.
    const patchedGet = key => {
      if (mode === 'get-security') {
        record('getItem', key, 'SecurityError');
        throw new DOMException('Injected localStorage getItem failure on test origin', 'SecurityError');
      }
      return get(key);
    };
    const patchedSet = (key, value) => {
      const name = String(key);
      if ((mode === 'body-set-quota' && bodyKey(name)) || (mode === 'meta-set-quota' && metaKey(name))) {
        record('setItem', name, 'QuotaExceededError');
        throw new DOMException('Injected localStorage setItem failure on test origin', 'QuotaExceededError');
      }
      return set(key, value);
    };
    const boundMethods = new Map();
    proxy = new Proxy(storage, {
      get(target, key) {
        if (key === 'getItem') return patchedGet;
        if (key === 'setItem') return patchedSet;
        const value = Reflect.get(target, key, target);
        if (typeof value !== 'function') return value;
        if (!boundMethods.has(key)) boundMethods.set(key, value.bind(target));
        return boundMethods.get(key);
      },
      set(target, key, value) { return Reflect.set(target, key, value, target); },
    });
  } catch (error) { bootError = error.name + ': ' + error.message; }

  function selectMode(next) {
    if (!modes.some(([value]) => value === next)) throw new Error('Unknown fault mode');
    try {
      if (next === 'normal') {
        if (installed) {
          if (descriptor) Object.defineProperty(window, 'localStorage', descriptor);
          else delete window.localStorage;
        }
        installed = false;
      } else {
        if (bootError || !storage || !proxy) throw new Error(bootError || 'Native localStorage unavailable');
        Object.defineProperty(window, 'localStorage', {configurable: true,
          enumerable: descriptor?.enumerable ?? true, get: () => proxy});
        if (window.localStorage !== proxy) throw new Error('Proxy installation failed');
        installed = true;
      }
      mode = next;
      record('control', next, null);
    } catch (error) {
      bootError = error.name + ': ' + error.message;
      record('control', next, bootError);
    }
    publish();
  }

  function publish() {
    const result = {format:'ux009-storage-fault-v1', origin:location.origin,
      test_only:true, performance_measurement:false, injection:'document-local localStorage method proxy',
      real_browser_security_policy_changed:false, storage_prototype_changed:false, session_storage_changed:false,
      mode, proxy_installed:installed, boot_error:bootError, events};
    const node = document.getElementById('storage-fault-test-evidence');
    if (node) node.textContent = JSON.stringify(result);
    const host = document.getElementById('storage-fault-test-controls');
    if (host) {
      host.dataset.mode = mode;
      host.dataset.ready = bootError ? 'failed' : 'true';
      host.dataset.injectedFailures = String(events.filter(event => event.error === 'QuotaExceededError' || event.error === 'SecurityError').length);
    }
    const status = document.getElementById('storage-fault-test-status');
    if (status) status.textContent = bootError ? '注入失败：' + bootError : '客户端测试注入；非浏览器真实安全策略。当前：' + modes.find(([value])=>value===mode)[1];
    const select = document.getElementById('storage-fault-test-mode');
    if (select) select.value = mode;
  }

  function mount() {
    const host = document.createElement('aside');
    host.id = 'storage-fault-test-controls'; host.dataset.testOnly = 'storage-fault';
    host.setAttribute('aria-label','仅测试：草稿存储故障');
    // Explicit test furniture; not part of any performance or layout acceptance.
    host.style.cssText = 'position:fixed;left:8px;bottom:8px;z-index:2147483647;max-width:min(480px,calc(100vw - 16px));padding:8px;background:#fff5d6;color:#171717;border:2px solid #9b6900;border-radius:6px;font:12px/1.4 system-ui;box-shadow:0 2px 8px #0003';
    const label = document.createElement('label'); label.textContent = '草稿存储故障 '; label.htmlFor = 'storage-fault-test-mode';
    const select = document.createElement('select'); select.id='storage-fault-test-mode';
    for (const [value, text] of modes) { const option=document.createElement('option'); option.value=value; option.textContent=text; select.append(option); }
    select.addEventListener('change',()=>selectMode(select.value));
    const reset = document.createElement('button'); reset.type='button'; reset.textContent='恢复正常'; reset.addEventListener('click',()=>selectMode('normal'));
    const status=document.createElement('p'); status.id='storage-fault-test-status'; status.style.margin='4px 0 0';
    const source=document.createElement('a'); source.href='/__fault__/storage-fault.js'; source.textContent='查看测试注入源码'; source.target='_blank'; source.rel='noopener';
    const evidence=document.createElement('script'); evidence.id='storage-fault-test-evidence'; evidence.type='application/json';
    host.append(label,select,reset,status,source,evidence); document.body.append(host); publish();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',mount,{once:true});
  else mount();
})();
