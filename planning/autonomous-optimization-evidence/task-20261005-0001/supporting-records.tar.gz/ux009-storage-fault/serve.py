#!/usr/bin/env python3
"""62611 read-only UX009 storage-fault browser fixture; never performance evidence."""
import argparse
import hashlib
from http.server import HTTPServer
import json
import os
from pathlib import Path
import signal
import sqlite3
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
RUNTIME = BASE.parent
sys.path.insert(0,str(RUNTIME / 'backend-investigation'))
from page_readonly_probe_server import guard, identity, sha, EXPECTED_DB, T0


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--max-seconds',type=int,default=1800)
    args=parser.parse_args()
    output=args.output.absolute()
    if output.resolve()!=output or BASE not in output.parents or output.exists():
        parser.error('new ordinary output directory under ux009-storage-fault required')
    if not 1<=args.max_seconds<=1800:parser.error('limit must be 1..1800 seconds')
    system=RUNTIME/'system-worktree';instance=RUNTIME/'preview'
    for path in (BASE,instance,instance/'.runtime',instance/'.runtime/review.sqlite3'):
        if path.resolve()!=path or path.is_symlink():raise ValueError('symlink input refused')
    safe_guard=guard();before=identity(system,instance)
    if before['database_sha256']!=EXPECTED_DB:raise ValueError('frozen preview database changed')
    script=(BASE/'storage-fault.js').read_bytes()
    output.mkdir(parents=True)
    def save(name,value):
        with (output/name).open('x') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
    save('guard-before.json',safe_guard);save('identity-before.json',before)
    related=['review_desk/static/app.js','review_desk/static/screenplay.js','review_desk/static/unified-cards.js',
             'review_desk/static/production-breakdown.js','review_desk/server.py','review_desk/store.py']
    save('environment.json',{'purpose':'UX009 real Chrome functional fault injection; not performance',
         'system_commit':before['system_commit'],'product_dirty':before['product_dirty'],
         'related_sha256':{path:sha(system/path) for path in related},
         'fault_script_sha256':hashlib.sha256(script).hexdigest(),'wrapper_sha256':sha(Path(__file__)),
         'origin':'http://127.0.0.1:62611','instance':'../preview','database_mode':'mode=ro&immutable=1; query_only',
         'database_sha256':before['database_sha256'],'browser_probe_enabled':False,
         'client_injection_scope':'localStorage method proxy in this document; no Storage.prototype/sessionStorage/security policy changes'})
    (output/'product-at-start.patch').write_bytes(subprocess.check_output(['git','-C',str(system),'diff','--binary','HEAD','--','review_desk'],timeout=10))
    (output/'storage-fault.js').write_bytes(script)
    sys.path.insert(0,str(system))
    from review_desk.server import ReviewHandler,ReviewServer
    from review_desk.store import Store
    from review_desk.material_storage import row_factory

    class Handler(ReviewHandler):
        def send_response(self,status,message=None):
            self._last_status=status
            return super().send_response(status,message)
        def _bytes(self,data,mime):
            self.send_response(200);self.send_header('Content-Type',mime)
            self.send_header('Content-Length',str(len(data)));self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff');self.end_headers();self.wfile.write(data)
        def _file(self,path,mime):
            if path.name=='index.html' and mime.startswith('text/html'):
                data=path.read_bytes()
                if b'<head>' not in data:raise ValueError('cannot insert pre-app fault script')
                data=data.replace(b'<head>',b'<head><script src="/__fault__/storage-fault.js"></script>',1)
                return self._bytes(data,mime)
            return super()._file(path,mime)
        def do_GET(self):
            error=None;self._last_status=None
            try:
                if self.headers.get('Host')!='127.0.0.1:62611':return self._json({'error':'exact test origin required'},403)
                if self.path.split('?',1)[0]=='/__fault__/storage-fault.js':return self._bytes(script,'text/javascript; charset=utf-8')
                return super().do_GET()
            except BaseException as exc:error=type(exc).__name__;raise
            finally:
                with (output/'http.jsonl').open('a') as stream:
                    stream.write(json.dumps({'at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
                       'method':'GET','path':self.path,'status':self._last_status,'error':error})+'\n')
        def do_POST(self):
            self.close_connection=True
            try:return self._json({'error':'read-only UX009 browser fixture'},405)
            finally:
                with (output/'http.jsonl').open('a') as stream:
                    stream.write(json.dumps({'at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
                       'method':self.command,'path':self.path,'status':405,'blocked':True})+'\n')
        do_PATCH=do_POST
        do_PUT=do_POST
        do_DELETE=do_POST

    class Server(ReviewServer):
        def __init__(self):
            self.root=instance;self.config=json.loads((instance/'config/instance.json').read_text())
            self.store=Store.__new__(Store);self.store.db_path=instance/'.runtime/review.sqlite3'
            self.store.db=sqlite3.connect(self.store.db_path.as_uri()+'?mode=ro&immutable=1',uri=True)
            self.store.db.execute('PRAGMA query_only=ON');self.store.db.execute('PRAGMA foreign_keys=ON')
            self.store.db.row_factory=row_factory(self.store)
            HTTPServer.__init__(self,('127.0.0.1',62611),Handler)

    receipt={'pid':os.getpid(),'port':62611,'started_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
             'stop_signal':None,'error':None,'purpose':'functional fault injection only'}
    save('process.json',receipt)
    def stop(signum,frame):receipt['stop_signal']=signum;raise KeyboardInterrupt
    for signum in (signal.SIGINT,signal.SIGTERM,signal.SIGALRM):signal.signal(signum,stop)
    signal.alarm(max(1,min(args.max_seconds,int(T0+9*3600-time.time()))))
    server=None
    try:
        server=Server()
        print(json.dumps({'url':'http://127.0.0.1:62611','pid':os.getpid(),'read_only':True,'performance':False}),flush=True)
        server.serve_forever()
    except KeyboardInterrupt:
        if receipt['stop_signal']==signal.SIGALRM:receipt['error']='functional test deadline; do not mark incomplete work as passed'
    except BaseException as exc:receipt['error']=type(exc).__name__+': '+str(exc);raise
    finally:
        signal.alarm(0)
        if server is not None:server.server_close()
        try:
            after=identity(system,instance);save('identity-after.json',after)
            receipt.update(identity_unchanged=before==after,
                database_unchanged=after['database_sha256']==before['database_sha256'],
                inputs_metadata_unchanged=after['input_metadata_sha256']==before['input_metadata_sha256'])
            save('guard-after.json',guard())
        except BaseException as exc:receipt['final_check_error']=type(exc).__name__+': '+str(exc)
        receipt['finished_at_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save('receipt.json',receipt)


if __name__=='__main__':main()
