#!/usr/bin/env python3
"""Build and verify portable task evidence in clean staging before publication."""
import argparse
import gzip
import hashlib
import io
import json
import os
import re
import shutil
import tarfile
import tempfile
import uuid
from pathlib import Path, PurePosixPath

TASK_ID = 'task-20261005-0001'
OMIT_KEYS = {'lease_digest', 'lease_token', 'access_token', 'refresh_token',
             'api_key', 'password', 'authorization'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def redact(value):
    if isinstance(value, dict):
        return {key: ('[REDACTED]' if key.lower() in OMIT_KEYS else redact(item))
                for key, item in value.items()}
    if isinstance(value, list):
        return [redact(item) for item in value]
    return value


def allowed(path):
    name = path.name.lower()
    return (path.is_file() and not path.is_symlink()
            and not any(parent.is_symlink() for parent in path.parents)
            and not any(part in {'__pycache__', 'node_modules', '.venv', 'venv', '.git'} for part in path.parts)
            and path.suffix.lower() not in {'.pyc', '.pyo', '.pstats', '.db', '.sqlite', '.sqlite3'}
            and not any(token in name for token in ('.sqlite', '.db-wal', '.db-shm', '.db-journal'))
            and not name.startswith('.env')
            and name != '.ds_store')


def sanitize(data, name):
    # One pass returns final artifact bytes, including strings inside clock JSON.
    # Unaffected inputs remain byte exact; all changes get one source/final mapping.
    if data.startswith(b'SQLite format 3\0'):
        raise ValueError('database magic in selected evidence: ' + name)
    try:
        source = data.decode('utf-8')
    except UnicodeDecodeError:
        return data
    if name.lower().endswith('.json'):
        parsed = json.loads(source)
        cleaned = redact(parsed)
        if cleaned != parsed:
            source = json.dumps(cleaned, ensure_ascii=False, indent=2) + '\n'
    elif name.lower().endswith('.jsonl'):
        lines = source.splitlines(keepends=True)
        for index, line in enumerate(lines):
            if not line.strip():
                continue
            parsed = json.loads(line)
            cleaned = redact(parsed)
            if cleaned != parsed:
                lines[index] = json.dumps(cleaned, ensure_ascii=False) + '\n'
        source = ''.join(lines)
    keys = '|'.join(re.escape(key) for key in sorted(OMIT_KEYS))
    source = re.sub(r'''(["'](?:''' + keys + r''')["']\s*:\s*)(["'])([^"'\n]+)\2''',
                    lambda match: match[1] + match[2] + '[REDACTED]' + match[2]
                    if match[3] != '[REDACTED]' else match[0], source, flags=re.I)
    return source.encode()


def safe_member(name):
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and '..' not in path.parts and str(path) == name


def collect_sources(root):
    groups = {
        'browser-records': ['browser'],
        'backend-records': ['backend-investigation'],
        'supporting-records': ['reviews', 'history-inventory', 'technical-readiness',
                               'functional-media-observation', 'ui-write-performance',
                               'ux009-storage-fault'],
    }
    selected = {group: {} for group in groups}
    excluded, sanitized_sources, names_seen = [], [], set()

    def include(group, path, artifact=None, source=None):
        name = source or path.relative_to(root).as_posix()
        if not path.exists() and not path.is_symlink():
            return
        if not allowed(path):
            excluded.append(name)
            return
        artifact = artifact or name
        if not safe_member(artifact) or artifact in names_seen:
            raise ValueError('unsafe or duplicate evidence artifact: ' + artifact)
        raw = path.read_bytes()
        final = sanitize(raw, artifact)
        entry = {'data': final, 'source': name, 'source_sha256': digest(raw)}
        selected[group][artifact] = entry
        names_seen.add(artifact)
        if final != raw:
            sanitized_sources.append({'source': name, 'source_sha256': digest(raw),
                                      'artifact': artifact, 'artifact_sha256': digest(final),
                                      'transformation': 'credential-key redaction; original source to final artifact'})

    for group, directories in groups.items():
        for directory in directories:
            base = root / directory
            if base.is_symlink():
                excluded.append(directory)
                continue
            if not base.exists():
                continue
            for path in sorted(base.rglob('*')):
                if path.is_file() or path.is_symlink():
                    include(group, path)
    group = 'supporting-records'
    for name in ('run-baseline.json', 'service-code-hashes.json',
                 'reset-authorization.json', 'recovery-prepare.txt',
                 'recovery-verification.json', 'guard-tests.log',
                 'functional-clone.json', 'resume-execution-diagnostic.json'):
        include(group, root / name)
    for path in sorted((root / 'schema6-roundtrip-reset-01').glob('*')):
        if path.is_file() or path.is_symlink():
            include(group, path)
    for name in ('state.json', 'latest-check.json', 'stop-receipt.json', 'reset-result.json',
                 'startup-recovery.json', 'register-reset-supervisor.json',
                 'register-coverage-reviewer.json', 'register-write-performance.json',
                 'register-supplement-audit.json', 'register-final-coverage.json',
                 'register-delivery-audit.json', 'resume-1855-guard.json',
                 'completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/state.json',
                 'completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/stop-receipt.json'):
        include(group, root / name, 'clock/' + name.replace('/', '__'))
    include(group, root / 'completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/run-report.md',
            'clock/original-window-report.md')
    include(group, Path(__file__).resolve(), 'tools/build_evidence.py', 'delivery/build_evidence.py')
    return selected, sorted(set(excluded)), sanitized_sources


def write_bundle(stage, selected, excluded, sanitized_sources):
    manifest = {'task_id': TASK_ID, 'format': 'autonomous-review-evidence-v1',
                'source_base': '.runtime/autonomous-optimization', 'archives': [],
                'files': [], 'sanitized_sources': sanitized_sources,
                'excluded': excluded,
                'exclusion_rule': 'no SQLite databases/sidecars, environment files, symlinks, dependency trees, bytecode or profiler binaries; no full Schema 6 duplicate media trees',
                'clock_limit': 'snapshot of recorded state, not a completion or user-confirmation receipt'}
    for group, entries in selected.items():
        archive = stage / (group + '.tar.gz')
        with archive.open('wb') as stream:
            with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as zipped:
                with tarfile.open(fileobj=zipped, mode='w|') as tar:
                    for name, entry in sorted(entries.items()):
                        data = entry['data']
                        info = tarfile.TarInfo(name)
                        info.size, info.mode, info.mtime = len(data), 0o644, 0
                        tar.addfile(info, io.BytesIO(data))
                        manifest['files'].append({'path': name, 'archive': archive.name,
                                                  'bytes': len(data), 'sha256': digest(data),
                                                  'source': entry['source'],
                                                  'source_sha256': entry['source_sha256']})
                        if name.endswith('.md') or name.startswith('clock/'):
                            readable = stage / 'readable' / name
                            readable.parent.mkdir(parents=True, exist_ok=True)
                            readable.write_bytes(data)
            stream.flush()
            os.fsync(stream.fileno())
        manifest['archives'].append({'path': archive.name, 'bytes': archive.stat().st_size,
                                     'sha256': file_digest(archive), 'entries': len(entries)})
    with (stage / 'manifest.json').open('w') as stream:
        stream.write(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
        stream.flush()
        os.fsync(stream.fileno())
    return manifest


def verify_bundle(stage, manifest):
    if json.loads((stage / 'manifest.json').read_text()) != manifest:
        raise ValueError('manifest changed during staging')
    expected = {entry['path']: entry for entry in manifest['files']}
    if len(expected) != len(manifest['files']):
        raise ValueError('duplicate manifest entry')
    seen, readable_expected = set(), set()
    for archive in manifest['archives']:
        path = stage / archive['path']
        if path.stat().st_size != archive['bytes'] or file_digest(path) != archive['sha256']:
            raise ValueError('archive digest mismatch: ' + archive['path'])
        count = 0
        with tarfile.open(path, 'r:gz') as tar:
            for member in tar:
                if not member.isfile() or not safe_member(member.name) or member.name in seen:
                    raise ValueError('unsafe or duplicate tar entry: ' + member.name)
                entry = expected.get(member.name)
                if not entry or entry['archive'] != archive['path']:
                    raise ValueError('unlisted or misplaced entry: ' + member.name)
                data = tar.extractfile(member).read()
                if len(data) != entry['bytes'] or digest(data) != entry['sha256']:
                    raise ValueError('entry digest mismatch: ' + member.name)
                if sanitize(data, member.name) != data:
                    raise ValueError('entry still requires sanitization: ' + member.name)
                if member.name.endswith('.md') or member.name.startswith('clock/'):
                    readable_expected.add(member.name)
                    readable = stage / 'readable' / member.name
                    if readable.is_symlink() or readable.read_bytes() != data:
                        raise ValueError('readable differs from archive: ' + member.name)
                count += 1
                seen.add(member.name)
        if count != archive['entries']:
            raise ValueError('archive entry count mismatch: ' + archive['path'])
    if seen != set(expected):
        raise ValueError('missing manifest entries')
    readable_actual = {p.relative_to(stage / 'readable').as_posix()
                       for p in (stage / 'readable').rglob('*') if p.is_file() or p.is_symlink()}
    if readable_actual != readable_expected:
        raise ValueError('missing or stale readable files')
    transformed = {entry['artifact']: entry for entry in manifest['sanitized_sources']}
    if len(transformed) != len(manifest['sanitized_sources']):
        raise ValueError('multiple transformations for one artifact')
    changed = {name for name, entry in expected.items() if entry['source_sha256'] != entry['sha256']}
    if set(transformed) != changed:
        raise ValueError('incorrect transformed artifact set')
    for name, item in transformed.items():
        entry = expected[name]
        if (item['source'], item['source_sha256'], item['artifact_sha256']) != (
                entry['source'], entry['source_sha256'], entry['sha256']):
            raise ValueError('transformation does not identify original source and final artifact: ' + name)


def publish_bundle(stage, out):
    # A directory swap prevents readers from seeing archives from different builds.
    # Existing complete output remains recoverable until the new verified set is in place.
    backup = None
    if out.exists():
        if out.is_symlink() or not out.is_dir():
            raise ValueError('existing evidence output must be a real directory')
        backup = out.with_name('.' + out.name + '.previous-' + uuid.uuid4().hex)
        os.replace(out, backup)
    try:
        os.replace(stage, out)
    except BaseException:
        if backup is not None and not out.exists():
            os.replace(backup, out)
        raise
    if backup is not None:
        try:
            shutil.rmtree(backup)
        except OSError:
            return str(backup)  # Publication succeeded; report a retained complete old copy.
    return None


def build_evidence(workspace, output):
    workspace = workspace.resolve()
    if output.is_symlink():
        raise ValueError('output must not be a symlink')
    out = output.resolve()
    root = workspace / '.runtime/autonomous-optimization'
    if not (workspace / 'planning/autonomous-optimization-run-report.md').is_file():
        raise ValueError('workspace is not the task project')
    if workspace not in out.parents or out.name != TASK_ID or root == out or root in out.parents:
        raise ValueError('output must be the named task evidence directory inside workspace and outside runtime')
    selected, excluded, transformed = collect_sources(root)
    out.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.' + TASK_ID + '.staging-', dir=out.parent))
    try:
        manifest = write_bundle(stage, selected, excluded, transformed)
        verify_bundle(stage, manifest)
        retained_previous = publish_bundle(stage, out)
        return manifest, retained_previous
    finally:
        if stage.exists():
            shutil.rmtree(stage)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    manifest, retained = build_evidence(args.workspace, args.output)
    print(json.dumps({'archives': manifest['archives'], 'files': len(manifest['files']),
                      'excluded': len(manifest['excluded']), 'verified_before_publish': True,
                      'retained_previous_directory': retained}, ensure_ascii=False))


if __name__ == '__main__':
    main()
