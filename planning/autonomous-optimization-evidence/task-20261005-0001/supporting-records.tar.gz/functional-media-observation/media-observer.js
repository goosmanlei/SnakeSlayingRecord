/* Isolated functional evidence only. It never plays, pauses or changes media. */
(() => {
  const records = [], ids = new WeakMap(), tracked = new WeakSet();
  let serial = 0;
  function record(kind, media, extra = {}) {
    if (!ids.has(media)) ids.set(media, ++serial);
    records.push({at: new Date().toISOString(), kind, id: ids.get(media),
      src: media.currentSrc || media.src, paused: media.paused,
      ended: media.ended, currentTime: media.currentTime,
      duration: Number.isFinite(media.duration) ? media.duration : null,
      connected: media.isConnected, ...extra});
    if (records.length > 100) records.shift();
    let output = document.getElementById('media-lifecycle-results');
    if (!output) {
      output = document.createElement('script');
      output.id = 'media-lifecycle-results'; output.type = 'application/json';
      document.body.append(output);
    }
    output.textContent = JSON.stringify({version: 1, records});
  }
  function mediaWithin(node) {
    if (node.nodeType !== 1) return [];
    return [...(node.matches('audio,video') ? [node] : []), ...node.querySelectorAll('audio,video')];
  }
  function observe(media) {
    if (tracked.has(media)) return;
    tracked.add(media); record('attached', media);
    for (const kind of ['play', 'pause', 'ended', 'loadedmetadata']) {
      media.addEventListener(kind, event => record(kind, media, {trusted: event.isTrusted}));
    }
  }
  function start() {
    document.querySelectorAll('audio,video').forEach(observe);
    document.addEventListener('click', event => {
      const button = event.target.closest('button');
      if (!button || button.getAttribute('aria-label') !== '关闭') return;
      const dialog = button.closest('dialog');
      if (dialog) dialog.querySelectorAll('audio,video').forEach(media =>
        record('before-close-click', media, {trusted: event.isTrusted}));
    }, true);
    new MutationObserver(changes => {
      for (const change of changes) {
        for (const node of change.addedNodes) mediaWithin(node).forEach(observe);
        for (const node of change.removedNodes) {
          for (const media of mediaWithin(node)) {
            if (tracked.has(media) && !media.isConnected) {
              queueMicrotask(() => record('removed-after-observers', media));
            }
          }
        }
      }
    }).observe(document.body, {childList: true, subtree: true});
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true});
  else start();
})();
