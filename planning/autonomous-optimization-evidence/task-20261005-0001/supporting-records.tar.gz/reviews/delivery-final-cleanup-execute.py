#!/usr/bin/env python3
"""Verify evidence and exact task-owned scratch inventory; delete only with --apply.

Default is a read-only dry run. A failed/interrupting apply leaves a per-target
receipt. Resume requires the same plan and manifest plus --resume --apply.
No Git worktree, Docker object, process, formal database or service is modified.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import stat
import subprocess
import tarfile
import sys

TASK = 'task-20261005-0001'
APPROVED_TARGETS = {
    'schema6-roundtrip-reset-01/source', 'schema6-roundtrip-reset-01/empty',
    'functional', 'preview/.runtime/review.sqlite3', 'preview/config',
    'preview/content', 'preview/export', 'final-coverage-song-restore',
    'backend-investigation/write-ab/reset-window-01/baseline/instance/.runtime/review.sqlite3',
    'backend-investigation/write-ab/reset-window-01/candidate/instance/.runtime/review.sqlite3',
    'ui-write-performance/A', 'ui-write-performance/B', 'ui-write-performance/snapshot',
    'backend-investigation/startup-comments-profile-reset-01/profile.pstats',
    'backend-investigation/window2/entity-profile/profile.pstats',
    'backend-investigation/window2/material_entries-profile/profile.pstats',
    'backend-investigation/window2/production-profile/profile.pstats',
    'backend-investigation/window2/scene-profile/profile.pstats',
    'backend-investigation/window2/history-profile/profile.pstats',
}
KEYS = {'lease_digest', 'lease_token', 'access_token', 'refresh_token',
        'api_key', 'password', 'authorization'}
TEXT_SECRET = re.compile(r'''["'](?:''' + '|'.join(sorted(KEYS))
                         + r''')["']\s*:\s*(["'])([^"'\n]+)\1''', re.I)


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha_file(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def relative_name(name):
    require(isinstance(name, str) and name and name != '.', 'empty/non-string path')
    path = PurePosixPath(name)
    require(not path.is_absolute() and '..' not in path.parts
            and '.' not in path.parts and '.git' not in path.parts
            and str(path) == name, 'unsafe relative path: ' + name)
    return path


def no_symlinks(path):
    for item in [path, *path.parents]:
        require(not item.is_symlink(), 'symlink rejected: ' + str(item))


def underneath(path, parent):
    return path == parent or parent in path.parents


def identity(path):
    s = path.lstat()
    require(stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode),
            'special file/symlink rejected: ' + str(path))
    return s


def inventory(root, rel):
    relative_name(rel)
    target = root / rel
    no_symlinks(target)
    s = identity(target)
    files, directories = [], []
    paths = [target] if stat.S_ISREG(s.st_mode) else [target, *sorted(target.rglob('*'))]
    for path in paths:
        name = path.relative_to(root).as_posix()
        relative_name(name)
        value = identity(path)
        row = {'path': name, 'bytes': value.st_size, 'mtime_ns': value.st_mtime_ns,
               'inode': value.st_ino}
        if stat.S_ISREG(value.st_mode):
            files.append(row)
        else:
            directories.append({**row, 'device': value.st_dev})
    return {'files_snapshot': files, 'directories_snapshot': directories,
            'files': len(files), 'bytes': sum(x['bytes'] for x in files),
            'device': s.st_dev, 'inode': s.st_ino}


def validate_target(root, row, state):
    target = root / row['path']
    recovering = state.get('status') in {'deleting', 'partial'}
    if not target.exists():
        require(not target.is_symlink(), 'missing target replaced by symlink')
        require(state.get('status') in {'deleted', 'deleting', 'partial'},
                'unrecorded missing target: ' + row['path'])
        return None
    require(state.get('status') != 'deleted', 'deleted target reappeared: ' + row['path'])
    actual = inventory(root, row['path'])
    require((actual['device'], actual['inode']) == (row['device'], row['inode']),
            'target identity changed: ' + row['path'])
    for section in ['files_snapshot', 'directories_snapshot']:
        expected = {x['path']: x for x in row[section]}
        found = {x['path']: x for x in actual[section]}
        require(set(found) <= set(expected) if recovering else set(found) == set(expected),
                'file/directory set changed: ' + row['path'])
        for name, item in found.items():
            wanted = expected[name]
            if recovering and section == 'directories_snapshot':
                require((item['device'], item['inode']) == (wanted['device'], wanted['inode']),
                        'remaining directory identity changed: ' + name)
            else:
                require(item == wanted, 'file/directory stat changed: ' + name)
    return actual


def assert_redacted(value, name):
    if isinstance(value, dict):
        for key, item in value.items():
            if key.lower() in KEYS:
                require(item == '[REDACTED]', 'credential key not redacted in ' + name)
            else:
                assert_redacted(item, name)
    elif isinstance(value, list):
        for item in value:
            assert_redacted(item, name)


def verify_package(package, expected_sha, required):
    no_symlinks(package)
    manifest_path = package / 'manifest.json'
    no_symlinks(manifest_path)
    require(sha_file(manifest_path) == expected_sha, 'manifest SHA confirmation mismatch')
    manifest = json.loads(manifest_path.read_text())
    require(manifest['task_id'] == TASK, 'wrong evidence task')
    rows = manifest['files']
    expected = {x['path']: x for x in rows}
    require(len(expected) == len(rows), 'duplicate manifest artifact')
    require(set(required) <= set(expected), 'required restore/write evidence missing')
    wanted_archives = {'browser-records.tar.gz', 'backend-records.tar.gz', 'supporting-records.tar.gz'}
    require({x['path'] for x in manifest['archives']} == wanted_archives
            and len(manifest['archives']) == 3, 'wrong archive set')
    seen, required_json = set(), {}
    for archive in manifest['archives']:
        path = package / archive['path']
        no_symlinks(path)
        require(path.stat().st_size == archive['bytes'] and sha_file(path) == archive['sha256'],
                'archive size/hash mismatch: ' + archive['path'])
        count = 0
        with tarfile.open(path, 'r:gz') as tar:
            for member in tar:
                name = member.name
                parts = relative_name(name).parts
                require(member.isfile() and name not in seen, 'nonregular/duplicate tar member')
                row = expected.get(name)
                require(row and row['archive'] == archive['path'], 'unlisted/misplaced member: ' + name)
                require(not any(x in {'__pycache__', 'node_modules', '.venv', 'venv'} for x in parts)
                        and not any(x.startswith('.env') for x in parts)
                        and Path(name).suffix.lower() not in {'.db', '.sqlite', '.sqlite3', '.pyc', '.pyo', '.pstats'}
                        and not any(x in Path(name).name.lower() for x in ('.sqlite', '.db-wal', '.db-shm', '.db-journal')),
                        'excluded payload in archive: ' + name)
                data = tar.extractfile(member).read()
                require(not data.startswith(b'SQLite format 3\0'), 'SQLite payload in archive')
                require(len(data) == row['bytes'] == member.size
                        and hashlib.sha256(data).hexdigest() == row['sha256'], 'member hash mismatch: ' + name)
                text = None
                try:
                    text = data.decode('utf-8')
                except UnicodeDecodeError:
                    require(not name.endswith(('.json', '.jsonl')), 'invalid JSON encoding')
                if text is not None:
                    if name.endswith('.json'):
                        value = json.loads(text)
                        assert_redacted(value, name)
                        if name in required:
                            required_json[name] = value
                    elif name.endswith('.jsonl'):
                        for line in text.splitlines():
                            if line.strip():
                                assert_redacted(json.loads(line), name)
                    for match in TEXT_SECRET.finditer(text):
                        require(match[2] == '[REDACTED]', 'text credential not redacted in ' + name)
                if name.endswith('.md') or name.startswith('clock/'):
                    readable = package / 'readable' / name
                    no_symlinks(readable)
                    require(readable.read_bytes() == data, 'readable mirror mismatch: ' + name)
                seen.add(name)
                count += 1
        require(count == archive['entries'], 'archive member count mismatch')
    require(seen == set(expected), 'manifest artifact missing')
    changed = {name for name, row in expected.items() if row['source_sha256'] != row['sha256']}
    transformed = {x['artifact']: x for x in manifest['sanitized_sources']}
    require(len(transformed) == len(manifest['sanitized_sources']) and set(transformed) == changed,
            'incomplete/duplicate transformation mapping')
    for name, item in transformed.items():
        row = expected[name]
        require((item['source'], item['source_sha256'], item['artifact_sha256'])
                == (row['source'], row['source_sha256'], row['sha256']), 'transformation hash mismatch')
    for name in ['schema6-roundtrip-reset-01/receipt.json', 'reviews/schema6-roundtrip-independent.json',
                 'reviews/final-coverage-song-restore-audit.json']:
        require(required_json[name].get('passed') is True, 'restore audit not passed: ' + name)
    api = required_json['backend-investigation/write-ab/reset-window-01/receipt.json']
    require(api.get('error') is None and set(api.get('completed', [])) == {'baseline', 'candidate'}
            and api.get('source_unchanged') is True and api.get('systems_unchanged') is True,
            'API write receipt incomplete')
    for arm in ['A', 'B']:
        receipt = required_json['ui-write-performance/runs/' + arm + '-measured/receipt.json']
        require(receipt.get('error') is None and receipt.get('snapshot_unchanged') is True,
                'UI write receipt incomplete')
    require(required_json['reviews/ui-write-independent.json'].get('status')
            == 'passed_evidence_integrity_with_small_sample_timing_limits', 'UI independent audit not passed')
    song = required_json['reviews/final-coverage-song-restore-run.json']
    require(song.get('status') == 'passed' and song.get('returncode') == 0
            and song.get('candidate_unchanged') is True, 'song restore run incomplete')
    require(required_json['reviews/final-coverage-song-restore.json'].get('all_business_tables_equal') is True,
            'song business-table comparison not passed')
    return manifest


def command(args):
    value = subprocess.run(args, capture_output=True, text=True, errors='replace')
    require(value.returncode == 0, 'read-only dependency command failed: ' + args[0])
    return value.stdout


def docker_state():
    ids = command(['docker', 'ps', '-aq']).split()
    return json.loads(command(['docker', 'inspect', *ids])) if ids else []


def public_container(item):
    return {'id': item['Id'], 'name': item['Name'], 'status': item['State']['Status'],
            'image': item['Image'], 'mounts': [{'type': x['Type'], 'source': x['Source'],
            'destination': x['Destination'], 'rw': x['RW']} for x in item['Mounts']]}


def protected_check(root, plan, hashes=True):
    for row in plan['protected_identities']:
        path = root / row['path']
        no_symlinks(path)
        s = identity(path)
        require((s.st_dev, s.st_ino) == (row['device'], row['inode']),
                'protected identity changed: ' + row['path'])
        if hashes and 'sha256' in row:
            require(sha_file(path) == row['sha256'], 'protected hash changed: ' + row['path'])
    actual = {x['Name']: public_container(x) for x in docker_state()}
    for row in plan['formal_container_identities']:
        require(actual.get(row['name']) == row, 'formal container identity changed: ' + row['name'])


def dependency_report(root, rows):
    targets = [(root / x['path']).absolute() for x in rows]
    cwd, proc, descriptor, groups, samples = {}, {}, '', {}, []

    def record(user, path):
        for target in targets:
            if not underneath(path, target):
                continue
            owner = ('container:' + user['container'] if 'container' in user
                     else 'pid:' + str(user['pid']))
            key = (owner, target.relative_to(root).as_posix())
            if key not in groups:
                groups[key] = {'owner': owner, 'target': key[1], 'rows': 0}
                if 'command' in user:
                    groups[key]['command'] = user['command']
            groups[key]['rows'] += 1
            if len(samples) < 3:
                samples.append({**user, 'path': str(path), 'target': key[1]})

    for line in command(['lsof', '-nP', '-F', 'pcfn']).splitlines():
        if line.startswith('p'):
            proc, descriptor = {'pid': int(line[1:])}, ''
        elif line.startswith('c'):
            proc['command'] = line[1:]
        elif line.startswith('f'):
            descriptor = line[1:]
        elif line.startswith('n') and line[1:].startswith('/'):
            name = Path(line[1:])
            if descriptor == 'cwd':
                cwd[proc['pid']] = name
            if proc.get('pid') != os.getpid() and any(underneath(name, p) for p in targets):
                record(proc, name)
    for line in command(['ps', '-axo', 'pid=,args=']).splitlines():
        values = line.strip().split(None, 1)
        if len(values) != 2 or not values[0].isdigit() or int(values[0]) == os.getpid():
            continue
        pid = int(values[0])
        try:
            tokens = shlex.split(values[1])
        except ValueError:
            # Unparseable command only blocks if it actually names an exact target.
            require(not any(str(p) in values[1] for p in targets), 'unparseable target-consuming process')
            continue
        for token in tokens:
            candidate = token.split('=', 1)[-1] if token.startswith('--') and '=' in token else token
            if not candidate or '\n' in candidate or len(candidate) > 4096:
                continue
            if candidate.startswith('/'):
                path = Path(os.path.normpath(candidate))
            elif pid in cwd and (candidate.startswith('.') or '/' in candidate):
                path = Path(os.path.normpath(str(cwd[pid] / candidate)))
            else:
                continue
            if any(underneath(path, p) for p in targets):
                record({'pid': pid, 'kind': 'process argument'}, path)
    for item in docker_state():
        for mount in item['Mounts']:
            source = Path(mount['Source'])
            if any(underneath(source, p) for p in targets):
                record({'container': item['Name']}, source)
    values = sorted(groups.values(), key=lambda x: (x['owner'], x['target']))
    return {'blocked': bool(values), 'observed_at_utc': now(),
            'total_matching_rows': sum(x['rows'] for x in values),
            'groups': values[:30], 'omitted_groups': max(0, len(values) - 30),
            'samples': samples, 'sample_limit': 3,
            'note': 'No process/VM/container was stopped; raw command arguments are not printed.'}


def dependency_check(root, rows):
    report = dependency_report(root, rows)
    require(not report['blocked'], 'target has active users: ' + json.dumps(report, ensure_ascii=False))
    return report


def save_receipt(path, value):
    require(not path.is_symlink(), 'receipt symlink rejected')
    temporary = path.with_name(path.name + '.tmp')
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'w') as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        directory_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        if temporary.exists():
            temporary.unlink()


def secure_remove(root, row, directory=False):
    parts = relative_name(row['path']).parts
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = os.open(root, flags)
    try:
        for part in parts[:-1]:
            child = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = child
        value = os.stat(parts[-1], dir_fd=fd, follow_symlinks=False)
        if directory:
            require(stat.S_ISDIR(value.st_mode) and value.st_ino == row['inode']
                    and value.st_dev == row['device'], 'directory changed immediately before removal')
            os.rmdir(parts[-1], dir_fd=fd)
        else:
            require(stat.S_ISREG(value.st_mode)
                    and (value.st_ino, value.st_size, value.st_mtime_ns)
                    == (row['inode'], row['bytes'], row['mtime_ns']),
                    'file changed immediately before removal')
            os.unlink(parts[-1], dir_fd=fd)
    finally:
        os.close(fd)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, default=Path(__file__).absolute().parents[3])
    parser.add_argument('--plan', type=Path, default=Path(__file__).with_name('delivery-final-cleanup-plan-v2.json'))
    parser.add_argument('--package', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--receipt', type=Path, default=Path(__file__).with_name('delivery-final-cleanup-execution-receipt.json'))
    parser.add_argument('--apply', action='store_true')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--defer-final-song-restore', action='store_true',
                        help='Retain only final-coverage-song-restore; still validate its identity and report active users.')
    args = parser.parse_args()
    require(re.fullmatch('[0-9a-f]{64}', args.manifest_sha256), 'full SHA-256 required')
    require(not args.resume or args.apply, '--resume requires --apply')
    for path in [args.workspace, args.plan, args.package, args.receipt.parent]:
        no_symlinks(path.absolute())
    workspace = args.workspace.resolve()
    root = workspace / '.runtime/autonomous-optimization'
    plan_path, package, receipt_path = args.plan.resolve(), args.package.resolve(), args.receipt.absolute()
    require(plan_path.parent == root / 'reviews', 'plan outside task reviews')
    require(receipt_path.parent == root / 'reviews' and receipt_path.name.startswith('delivery-final-')
            and receipt_path.suffix == '.json', 'receipt outside allowed task review path')
    require(underneath(package, workspace) and not underneath(package, root), 'package outside task or inside runtime')
    plan = json.loads(plan_path.read_text())
    require(plan['task_id'] == TASK and plan['plan_version'] == 2, 'wrong cleanup plan')
    rows = plan['phase_a']
    require(len(rows) == 19 and {x['path'] for x in rows} == APPROVED_TARGETS,
            'plan must contain exactly the 19 approved targets')
    for row in rows:
        relative_name(row['path'])
        require(row['owner'] == TASK, 'target owner mismatch')
        target = root / row['path']
        for item in plan['protected_identities']:
            protected = root / item['path']
            require(not underneath(protected, target) and not underneath(target, protected),
                    'target overlaps protected resource')
        for section in ['files_snapshot', 'directories_snapshot']:
            for item in row[section]:
                relative_name(item['path'])
                require(underneath(root / item['path'], target), 'inventory entry outside its approved target')
        require(not any(other is not row and underneath(root / other['path'], target) for other in rows),
                'overlapping cleanup targets')
    manifest = verify_package(package, args.manifest_sha256, plan['required_artifacts'])
    # Required evidence must still identify the unchanged local source at cleanup.
    by_artifact = {x['path']: x for x in manifest['files']}
    for name in plan['required_artifacts']:
        entry = by_artifact[name]
        relative_name(entry['source'])
        source = root / entry['source']
        no_symlinks(source)
        require(sha_file(source) == entry['source_sha256'], 'required evidence changed since package: ' + name)
    protected_check(root, plan)
    fingerprint = {'task_id': TASK, 'plan_sha256': sha_file(plan_path),
                   'manifest_sha256': args.manifest_sha256, 'script_sha256': sha_file(Path(__file__))}
    if args.resume:
        require(receipt_path.is_file(), 'resume receipt absent')
        no_symlinks(receipt_path)
        receipt = json.loads(receipt_path.read_text())
        require(all(receipt.get(k) == v for k, v in fingerprint.items()), 'resume identity mismatch')
        require(receipt['status'] in {'applying', 'partial', 'complete', 'complete_with_retained'},
                'receipt is not resumable')
    else:
        require(not receipt_path.exists(), 'receipt already exists; use explicit --resume or a new receipt')
        receipt = {**fingerprint, 'started_at_utc': now(), 'status': 'validated',
                   'package': package.relative_to(workspace).as_posix(), 'targets': {
                       x['path']: {'status': 'planned', 'expected_files': x['files'],
                                   'expected_bytes': x['bytes']} for x in rows}}
    pending, retained = [], []
    for row in rows:
        state = receipt['targets'][row['path']]
        validate_target(root, row, state)
        if state['status'] == 'deleted':
            continue
        if row['path'] == 'final-coverage-song-restore' and args.defer_final_song_restore:
            report = dependency_report(root, [row])
            state.update({'status': 'retained_active_user' if report['blocked'] else 'retained_by_explicit_option',
                          'retained_files': row['files'], 'retained_bytes': row['bytes'],
                          'readback_exists': True, 'dependency_report': report,
                          'owner': 'root task coordinator',
                          'next_step': 'Keep while consumed; recheck exact users and resume with the same plan/package after release. Never stop shared VM.'})
            retained.append(row['path'])
        else:
            if state['status'].startswith('retained_'):
                state['prior_retention'] = {key: state[key] for key in ['status', 'dependency_report', 'next_step'] if key in state}
                state['status'] = 'planned'
            pending.append(row)
    dependency_check(root, pending)
    if not args.apply:
        print(json.dumps({'status': 'dry_run_passed_with_retained' if retained else 'dry_run_passed',
                          'deletion_executed': False,
                          'manifest_sha256': args.manifest_sha256,
                          'plan_totals': plan['phase_a_totals'], 'eligible_targets': len(pending),
                          'eligible_files': sum(x['files'] for x in pending),
                          'eligible_bytes': sum(x['bytes'] for x in pending),
                          'retained': {name: receipt['targets'][name] for name in retained}}, ensure_ascii=False))
        return
    receipt['status'] = 'applying'
    save_receipt(receipt_path, receipt)
    active = None
    try:
        for row in rows:
            state = receipt['targets'][row['path']]
            if state['status'] == 'deleted' or state['status'].startswith('retained_'):
                continue
            active = row
            dependency_check(root, [row])
            current = validate_target(root, row, state)
            state.update({'status': 'deleting', 'started_at_utc': now()})
            save_receipt(receipt_path, receipt)
            if current is not None:
                for item in current['files_snapshot']:
                    secure_remove(root, item)
                for item in sorted(current['directories_snapshot'],
                                   key=lambda x: len(PurePosixPath(x['path']).parts), reverse=True):
                    secure_remove(root, item, directory=True)
            require(not (root / row['path']).exists(), 'target remains after cleanup')
            protected_check(root, plan, hashes=False)
            state.update({'status': 'deleted', 'deleted_files': row['files'],
                          'deleted_bytes': row['bytes'], 'readback_exists': False,
                          'finished_at_utc': now()})
            save_receipt(receipt_path, receipt)
        protected_check(root, plan)
        for row in rows:
            if receipt['targets'][row['path']]['status'].startswith('retained_'):
                validate_target(root, row, receipt['targets'][row['path']])
        receipt.update({'status': 'complete_with_retained' if retained else 'complete',
                        'finished_at_utc': now(),
                        'actual_deleted_files': sum(x.get('deleted_files', 0) for x in receipt['targets'].values()),
                        'actual_deleted_bytes': sum(x.get('deleted_bytes', 0) for x in receipt['targets'].values()),
                        'retained_targets': len(retained),
                        'retained_files': sum(receipt['targets'][name]['retained_files'] for name in retained),
                        'retained_bytes': sum(receipt['targets'][name]['retained_bytes'] for name in retained),
                        'protected_resources_verified': True})
        save_receipt(receipt_path, receipt)
    except BaseException as error:
        receipt['status'], receipt['failed_at_utc'] = 'partial', now()
        receipt['error_type'] = type(error).__name__
        receipt['error'] = str(error)
        if active is not None:
            state = receipt['targets'][active['path']]
            if state['status'] != 'deleted':
                state['status'] = 'partial'
                state['readback_exists'] = (root / active['path']).exists()
        save_receipt(receipt_path, receipt)
        raise
    print(json.dumps({'status': receipt['status'], 'receipt': str(receipt_path),
                      'files': receipt['actual_deleted_files'], 'bytes': receipt['actual_deleted_bytes'],
                      'retained_files': receipt['retained_files'], 'retained_bytes': receipt['retained_bytes']},
                     ensure_ascii=False))


if __name__ == '__main__':
    main()
