"""Reconcile current coverage conclusions while preserving recorded observations."""
import copy
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / '.runtime/autonomous-optimization'
PATH = BASE / 'history-inventory/coverage-prioritized-checkpoint.json'
MD = PATH.with_suffix('.md')
now = datetime.now(timezone.utc).isoformat()
data = json.loads(PATH.read_text())
assert 'final_coverage_reconciliation' not in data, 'run once; follow-up must use the current matrix'
old_header = {key: copy.deepcopy(data[key]) for key in ['audited_at','reviewer_thread_id','method','counts','quality_convergence_gates','priority_next_five']}
old_header['json_sha256_before'] = hashlib.sha256(PATH.read_bytes()).hexdigest()
old_header['markdown_sha256_before'] = hashlib.sha256(MD.read_bytes()).hexdigest()
data['previous_conclusion_checkpoints'] = [old_header]
data['audited_at'] = now
data['reviewer_thread_id'] = '01a10bdc-4dd1-70e2-ac7c-5f864eb6f38f'
data['method'] = '最终独立审查复用既有真实浏览器/性能原件和非实施者独审；不重跑616项Node、135项后台复算。新增只读核对最新正式歌曲隔离副本，并用204c469做一次准确Schema6恢复；本审查者没有浏览器操作、正式库访问或产品修改。'
sources = [
 'reviews/final-page-independent.md','reviews/final-page-independent.json','reviews/final-page-independent-evidence.json',
 'reviews/final-action-independent.md','reviews/final-action-independent.json',
 'reviews/supplement-independent.md','reviews/supplement-independent.json',
 'reviews/AO-UX008-independent.json','reviews/AO-UX009-independent.json',
 'reviews/ui-write-independent.md','reviews/ui-write-independent.json',
 'reviews/final-coverage-song-audit.json','reviews/final-coverage-song-restore.json',
 'reviews/final-coverage-song-restore-run.json','reviews/final-coverage-song-restore-audit.json',
 'backend-investigation/merged-main-validation/clone.json']
manifest = [{'file': str((BASE / name).relative_to(ROOT)), 'sha256': hashlib.sha256((BASE / name).read_bytes()).hexdigest()} for name in sources]
data['final_coverage_reconciliation'] = {
 'at': now, 'system_reviewed':'204c4696f0ecd4595b395a14520eacf0c54ef2bf',
 'story_reviewed':'cea1dbd4220b4637141dd1f7e56d3fc34ea01774',
 'old_observations_preserved':True, 'manifest':manifest,
 'authority':'coverage 当前字段和 quality_convergence_gates 是本次现状；previous_conclusion_checkpoints、各行 previous_conclusion、既有独审 limits 和 counter_evidence.finding 保留其原观察时点，不能当当前未修状态。',
 'pending_new_issue':'根在最新歌曲页面验证发现现代实体成功加载只改active、漏aria-pressed，登记AO-UX010；此时修复及独审未完成，D2-04标部分。',
 'new_song_scope': {'objects':6296,'revisions':10302,'comments':285,'comment_events':314,'recorded_versions':10,'current_ungenerated_versions':4,'public_tables_restored':22},
 'performance_scope':'280页加载/312正式交互基于3b20d609；160补测动作和48UI写入基于204c469；冻结数据为6236对象/271评论。最新6296对象/285评论用于功能和恢复兼容，不混入性能对照。',
 'delivery_state':'便携包、最终候选、不可变发布包、preflight、最终确认与清理均以根最终回执为准；本矩阵不宣称已完成。'}

def source(row, *names):
    for name in names:
        path = str((BASE / name).relative_to(ROOT))
        if path not in row['evidence']:
            row['evidence'].append(path)

lookup = {row['id']: row for row in data['coverage']}
for row in data['coverage']:
    row['previous_conclusion'] = {key:copy.deepcopy(row[key]) for key in ['status','performance_status','performance_note','quality_gap'] if key in row}
    row['performance_note'] = '本行保留代表性功能与原采样边界；没有本行独立同条件对照的动作不宣称性能收益。已完成的页面、交互、媒体和写入对照在final_coverage_reconciliation指向的独审中按准确版本/动作区分，不再一律列为待测。'
    if row['id'].endswith('-01') and row['page_id'] != 'X':
        row['performance_status'] = 'FINAL_ABAB_PAGE_SEMANTIC_READY_REVIEWED'
        row['performance_note'] = '12子页共280条最终页面记录已独审，A=b874b959/B=3b20d609，冻结6236对象数据；4页双轮观察到语义就绪改善，其他页面逐项保留未证实/反向信号。不是完整媒体解码或当前新增歌曲数据的性能测量。'
        row['quality_gap'] = '本页代表性首开功能和最终页面语义就绪对照已复核；收益按本页独审结论，不据此声称全部子功能通过或同幅加速。'
        source(row,'reviews/final-page-independent.md','reviews/final-page-independent.json')

for key in ['A1-02','A2-02','C1-02','C2-02','S1-03','S2-03','S3-03','D1-03','P1-03','D3-03','D3-04']:
    row=lookup[key]
    row['performance_status']='FINAL_ABAB_SELECTED_ACTIONS_REVIEWED'
    row['performance_note']='312条正式交互已独审；仅适用于对应页签/版本/集场/媒体类型筛选/翻页中的实际测量动作。制作拆解返回S001、素材筛选和翻页四方向、镜头场次双向持续超过波动；实体两方向受新AO-UX010选中正确性调查限制，暂不计完整正确交互收益。未测同页其他组合不借此覆盖。'
    source(row,'reviews/final-action-independent.md','reviews/final-action-independent.json')

for key in ['C1-03','C2-03','X-01','D2-05']:
    row=lookup[key]
    row['performance_status']='FINAL_SMALL_FIXTURE_UI_WRITES_REVIEWED'
    row['performance_note']='独立技术克隆48次真实UI写、36正式样本已复核，465项证据检查通过；无稳定写入提速结论，评论编辑/取消5.2/7.9ms慢化信号保留。实际覆盖动作及小数据规模见独审，不能外推全部本行操作或正式规模。'
    source(row,'reviews/ui-write-independent.md','reviews/ui-write-independent.json')

lookup['S1-04']['quality_gap']='原生选字/旧评论定位、390内容可见/焦点和1200面板已闭合；204c469的UX009补齐同页面会话内存储失败草稿保护，35独立反例及三阅读器27份真实故障记录已复核。跨目标返回保证正文和身份，不保证光标选区持续；不承诺刷新/崩溃恢复。剧本跨场结尾的实际覆盖单独按S3证据判断。'
lookup['S1-04']['performance_status']='FINAL_REPEATED_LOCATION_COST_REVIEWED'
lookup['S1-04']['performance_note']='160动作补测中的定位正式样本，在候选中实际滚回2635px且整句可见，双轮中位增加849.4/849.5ms；这是已解释成本，不能称无回退，也不能把不同滚动距离当同一算法比较。'
source(lookup['S1-04'],'reviews/AO-UX009-independent.json','reviews/supplement-independent.md')
lookup['S3-04']['quality_gap'] += ' UX009的剧本跨集/场和390键盘重开已验证准确正文保留；旧UX007独审关于存储失败未处理的限制只描述其当时版本。未取得真实atEnd组合的路径不扩大为浏览器已验。'
source(lookup['S3-04'],'reviews/AO-UX009-independent.json')
lookup['D1-03']['quality_gap']='已有功能场次切换证据；最终ABAB拆解返回S001两轮超过规则，进入S002仅第二轮成立，不把两方向合并称同等改善。'
lookup['X-02']['quality_gap'] += ' UX009新增同准确目标重绘优先保留实时正文、会话失败草稿及新建/取消/提交优先级，35独立反例和三阅读器实际故障操作通过；跨目标返回不承诺持续光标选区或刷新/崩溃恢复。'
source(lookup['X-02'],'reviews/AO-UX009-independent.json')
lookup['D2-04']['status']='部分'
lookup['D2-04']['quality_gap']='原非基础状态/共享原件/历史浏览证据有效，最新歌曲10录音版本/原件SHA及4个当前未生成版本已在204c469只读核对；根最新真实页另发现现代实体切换后aria-pressed未同步（AO-UX010）。这影响准确选中判断，修复、限定外层索引且避免模态污染的独审和真实页面复验完成前保留部分。'
lookup['D2-04']['performance_status']='FINAL_ENTITY_CONTENT_TIMINGS_WITH_SELECTION_DEFECT'
lookup['D2-04']['performance_note']='旧312条交互中实体双向内容到达两轮更快，但AO-UX010新选中标记缺陷尚待逐样本归属；暂不将这两方向列为完整正确交互提速。JS修复后的功能复验不能伪装成已重测性能。'
source(lookup['D2-04'],'reviews/final-action-independent.md','reviews/final-coverage-song-audit.json')
lookup['D2-06']['performance_status']='FINAL_RELATION_ENTER_TOOL_UPPER_BOUND_ONLY'
lookup['D2-06']['performance_note']='160补测中真实Enter打开孙六的可用状态墙钟上界两轮下降95/106ms；包含工具往返，没有click探针事件，不能换算为产品自身精确提速。关闭无持续收益。'
source(lookup['D2-06'],'reviews/supplement-independent.md')
lookup['P2-03']['quality_gap'] += ' AO-UX008已同步记录选中class/aria，204c469补测每次候选均正确；基准8次进入S002选错，旧数值只支持准确正文到达路径，不构成完整正确交互等价比较。'
lookup['P2-03']['performance_status']='FINAL_HISTORY_CONTENT_TIMINGS_WITH_BASELINE_SELECTION_DEFECT'
lookup['P2-03']['performance_note']='A3/B3、A4/B4补测正文进入S002两轮超过波动，返回S001仅一轮；旧基准选中状态错误，不能据此宣称完整交互提速。'
source(lookup['P2-03'],'reviews/AO-UX008-independent.json','reviews/supplement-independent.md')
lookup['X-04']['quality_gap'] += ' 160补测进一步复核准确1086×1448图片与14.5秒音频实际推进/暂停；约20ms的DOM就绪不等于解码或出声延迟。6条媒体BrokenPipe保留，正式播放前同文件206及播放成功，逐条取消原因未知。'
lookup['X-04']['performance_status']='FINAL_WARM_MEDIA_SEMANTIC_TIMINGS_REVIEWED'
lookup['X-04']['performance_note']='图片放大/关闭及音频播放/暂停已作两轮暖路径补测，没有持续收益；媒体实际完整/播放是另份功能观察，不倒推探针终点为解码/绘制/出声。'
source(lookup['X-04'],'reviews/supplement-independent.md')
lookup['X-05']['quality_gap']='旧6236对象/271评论快照的443.575578秒恢复证据保持原范围。新增最新6296对象/285评论副本在204c469下经recover_song_publication.py一次恢复71.14秒，22业务表原始行完全相同，10302修订/314事件及两条准确PCM历史payload未改，事件高水位321/20相等。普通恢复器仍会拒绝该两条旧舍入差，须使用准确专门入口；不以单次恢复作性能对照。私有generation_publications不进入公开导出。'
source(lookup['X-05'],'reviews/final-coverage-song-restore.json','reviews/final-coverage-song-restore-run.json','reviews/final-coverage-song-restore-audit.json')
lookup['D3-05']['quality_gap'] += ' 最新歌曲4个未生成当前版与10录音历史已另经最终系统读取核对；原多候选/多组成N/A只限定原冻结快照，未对新数据作全量N/A推断。'
source(lookup['D3-05'],'reviews/final-coverage-song-audit.json')
for row in data['counter_evidence']:
    if row['id']=='COV-04':
        row['status']='closed_by_final_page_abab_with_remaining_handler_signal'
        row['resolution']='最终页面ABAB每阶段C2共14次reload未重现旧变慢方向；配置handler约6—10ms差值仍保留。原finding为当时观察，不是当前未处理结论。'
        row['resolution_source']='reviews/final-page-independent.md/json'

data['quality_convergence_gates']=[
 {'id':'G1','blocking':False,'scope':'已完成页面/交互/写入及补测性能复核','needed':'280页面、312正式交互、48UI写与160补测动作已有独审；C2旧页面变慢未重现。披露定位约850ms、写入5.2/7.9ms及handler6—10ms剩余成本，不能称全面提速或零错误。'},
 {'id':'G2','blocking':True,'scope':'新发现AO-UX010现代实体选中标记','needed':'根修复成功实体读取后的aria-pressed同步，限定外层索引、避免模态污染；另一独审者复核真实页、准确旧版本、迟到响应与模态边界。D2旧耗时暂只计内容到达。UX008/UX009已修状态保留。'},
 {'id':'G3','blocking':False,'scope':'区域可见性与会话草稿','needed':'区域轮廓和UX009已独审闭合；跨目标正文/身份与光标选区、会话内保护与刷新持久化分开。'},
 {'id':'G4','blocking':False,'scope':'文件上传外部限制和未改路径探索','needed':'C2上传仍部分；方法缺失/损坏两项探索未验。公开限制，不把环境失败写成页面通过，也不因未改故障组合未穷举自动增加改动。'},
 {'id':'G5','blocking':True,'scope':'合并后当前数据与最终交付','needed':'最新歌曲代码/数据只读和22表恢复已过；根负责代表性真实页面。固定最终两仓候选、便携证据、不可变发布包和preflight/恢复身份、可用隔离预览及准确清理回执后才能请求最终确认。'},
 {'id':'G6','blocking':False,'scope':'已解释低影响限制与保留历史','needed':'保留1200标题约14px裁切、1024阅读拥挤、旧生成说明与后续认可时态差。清理以准确用途判断；用户明确保留worktree/分支及_complete后只读优先。'}]
data['priority_next_five']=[
 {'priority':1,'scope':'关闭AO-UX010','why':'最新发现影响准确选中判断','minimum':'有界修复、独立静态/反例和真实页；同步D2性能声明范围','not_required':'不重跑与JS索引标记无关的后台/恢复全套'},
 {'priority':2,'scope':'合并后歌曲页面','why':'新正式数据晚于冻结性能输入','minimum':'结合4歌10录音只读核对与22表恢复，根补代表性准确版本/未生成版/原评论真实页','not_required':'不再次切换全部10音频或采集全站性能'},
 {'priority':3,'scope':'固定可审阅交付','why':'真实最终包和候选尚待完成','minimum':'报告/矩阵一致、便携包manifest/脱敏/解压链接、双仓候选、不可变镜像包/preflight与恢复身份','not_required':'不把builder模拟测试当成包验收'},
 {'priority':4,'scope':'准确资源清理','why':'新规则要求清理无效过程产物且用户要求保留worktree','minimum':'用途/归属/挂载核对后清理失效试验资源；保留正式历史、必要回执与分支；_complete前完成必要写入','not_required':'不强删worktree、不全局prune、不在_complete后补改受管文件'},
 {'priority':5,'scope':'限制据实交付','why':'已解释成本和外部限制仍影响结论范围','minimum':'C2上传/方法故障探索/1024/标题裁切/定位成本均保留状态与下一步','not_required':'不为未测组合制造产品改动或全面提速声明'}]
data['counts']=dict(Counter(row['status'] for row in data['coverage']))
data['corrections'].append({'at':now,'topic':'final evidence reconciliation','previous':'全部61行沿用最终PERF002页面待测说明，S1-04仍称存储失败未修，旧C2慢化未关闭。','corrected':'按已完成独审更新当前性能/UX008/UX009/最新歌曲恢复；新AO-UX010未关闭前D2-04部分。原观察与准确版本留在previous_conclusion及来源。','source':'reviews/final-coverage-*.json + final-page/action/supplement/ui-write independent reviews'})
PATH.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

intro=f'''# 代表性功能验收与探索分层检查点

最终复核时间：{now}。覆盖5个主入口、12个子页、61项动作。当前57项代表性功能通过、2项部分、2项探索未验：C2上传保留外部权限限制；新发现AO-UX010实体选中标记尚待修复独审，D2-04暂列部分。状态通过只指该行明确的功能证据，不等于所有组合、性能收益或任务已交付。

当前字段由最终独立审查依据已保存的真实证据收敛。[机器矩阵](coverage-prioritized-checkpoint.json)保留原观察、旧反证、原独审限制和前次结论；它们有各自时间与版本，不能把旧“存储失败未修”或“最终页面待测”当当前状态。原始浏览器/API数据均未改写。

页面280条、正式交互312条、真实页面写入48次和最后补测160动作均已有非实施者复核。页面对照固定b874b959与3b20d609，最后补测和写入固定204c469；它们使用6236对象/271评论冻结数据，最新歌曲6296对象/285评论单独用于兼容与恢复，不混作同条件性能样本。页面、准确正文到达、媒体完整加载、实际播放和含工具往返的键盘上界分别说明，详见[页面](../reviews/final-page-independent.md)、[交互](../reviews/final-action-independent.md)、[写入](../reviews/ui-write-independent.md)及[补测](../reviews/supplement-independent.md)独审。

UX008记录选中修正、UX009三阅读器会话内草稿保护已有真实证据与独审；35项反例和27份故障操作记录只证明同页面会话和准确身份，跨目标返回未保证光标选区持久化，刷新/崩溃持久恢复也未承诺。UX007早期独审中的限制保留其当时范围。新AO-UX010现代实体切换遗漏aria-pressed尚待根完成修复与另一审查者复验，旧实体双向数值暂按正文到达路径保留，不宣称完整正确交互提速。

最新歌曲增量已用204c469只读核对4首歌10个录音版本及原件SHA、4个当前未生成版本、285个有效评论锚点和原271评论/300事件保留；一次[最新数据恢复](../reviews/final-coverage-song-restore.json)的22张业务表与源副本原始行相同，10302修订、314事件及两条PCM历史payload不变。普通恢复器仍拒绝约0.167微秒的两条旧时长舍入差，准确恢复须用`scripts/recover_song_publication.py`；代码发布的运行恢复只切旧镜像/挂载，不恢复数据库。根的合并后代表性页面验收仍单独核对。

已有技术采用/换版/409、历史判断、实际清单下载、区域轮廓及音频关闭暂停证据保留，不代表真实作品认可。C2上传仅一次尝试被Chrome扩展file URL权限阻断；选择/默认恢复通过，上传及非法文件页面路径不能写通过。方法文件缺失/损坏两项未改路径探索保留未验。

## 质量收敛与限制
'''
lines=[intro]
for gate in data['quality_convergence_gates']:
    lines.append(f"- **{gate['id']} {gate['scope']}**（{'阻断最终收敛' if gate['blocking'] else '已关闭或解释边界'}）：{gate['needed']}\n")
lines.append('\n## 下一批有界优先序\n')
for item in data['priority_next_five']:
    lines.append(f"{item['priority']}. **{item['scope']}**：{item['minimum']}。{item['not_required']}。\n")
lines.append('\n## 逐项必要范围与探索限制\n\n| ID | 子页／动作 | 状态 | 必要范围及当前缺口 | 扩展探索／边界 |\n| --- | --- | --- | --- | --- |\n')
def cell(value):return str(value).replace('|','\\|').replace('\n',' ')
for row in data['coverage']:
    lines.append('| '+' | '.join(map(cell,[row['id'],row['subpage']+'／'+row['action'],row['status'],row['acceptance_required']+' '+row['quality_gap'],row['exploration']]))+' |\n')
lines.append('''
## 证据来源与性能边界

机器矩阵的`final_coverage_reconciliation.manifest`记录本次新增来源及SHA；原`evidence`、反证、事故和旧采样身份继续保留。此前UX006旧VM缺window的2次失败、覆盖事故中丢失的D1/D2原B1、主机中断和外部任务干扰均未抹除。已完成独审只更新当前判断，不重建遗失原件。

C2旧页面变慢在最终两轮每阶段14次reload未重现，配置handler仍有6—10ms剩余信号。补测定位的整句可见修复伴随真实849.4/849.5ms额外滚动等待；小技术写入的评论编辑/取消保留5.2/7.9ms慢化信号。原始慢样本及32条图片、6条媒体BrokenPipe均保留，不能宣称全面提速或网络零错。媒体约20ms为暖路径DOM语义就绪，不是解码/出声延迟。

N/A按准确数据版本理解：原6236对象快照没有真实视频、同版多候选或同记录多可展示媒体组成，不免除已有音频/图片能力，也不外推新增数据的全量适用性。单次功能/恢复、小样本ABAB和单机缓存状态不推出长期生产尾延迟。

剩余低影响项包括1200像素标题约14像素裁切、1024像素阅读空间、历史生成说明与后来真实认可的时态差，均保留证据和后续处置。最终便携包、候选/preflight、最新页面与清理回执完成后才能由根判断质量收敛；本矩阵不代替用户最终确认、正式切换或作品接受。
''')
MD.write_text(''.join(lines))
print(json.dumps({'counts':data['counts'],'actions':len(data['coverage']),'updated_json':str(PATH.relative_to(ROOT)),'updated_markdown':str(MD.relative_to(ROOT))},ensure_ascii=False))
