"""Read-only independent audit of one completed Schema 6 roundtrip. No Store/restore/export."""
import hashlib
import json
import signal
import sqlite3
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode = True
base = Path(__file__).resolve().parents[1]
system = base / 'system-worktree'
run = base / 'schema6-roundtrip-reset-01'
review = base / 'reviews/schema6-roundtrip-independent.json'
sys.path.insert(0, str(system))
from review_desk import material_storage, material_archives, production

started = time.monotonic()
result = {'format':'schema6-roundtrip-independent-v1', 'started_utc':datetime.now(timezone.utc).isoformat(),
          'reviewer':'01a10a85-fd7a-7021-aa28-a867f6dea1d8','read_only':True,'reran_restore':False}
def timeout(*_): raise TimeoutError('90 second independent read-only audit limit')
signal.signal(signal.SIGALRM, timeout)
signal.alarm(90)
def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda:f.read(1048576),b''): h.update(data)
    return h.hexdigest()
def canon(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def read_db(path):
    db=sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)
    db.execute('PRAGMA query_only=ON'); return db
def tables(db):return {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
def count(db,name):return db.execute('SELECT count(*) FROM "'+name+'"').fetchone()[0]
dbs=[]
try:
    receipt=json.loads((run/'receipt.json').read_text())
    result['reviewed_receipt_sha256']=digest(run/'receipt.json')
    result['reviewed_runner_sha256']=digest(base/'reviews/schema6-roundtrip-reset-01.py')
    assert receipt['passed'] and 'error' not in receipt
    result['system_head']=receipt['system_head']
    code_mismatch=[]
    for path,expected in receipt['source_code_sha256'].items():
        blob=subprocess.check_output(['git','show',receipt['system_head']+':'+path],cwd=system)
        if hashlib.sha256(blob).hexdigest()!=expected:code_mismatch.append(path)
    assert not code_mismatch,code_mismatch
    result['committed_code_files_matching_receipt']=len(receipt['source_code_sha256'])
    result['current_python_files_match_receipt']=all(digest(system/path)==value for path,value in receipt['source_code_sha256'].items() if path.endswith('.py'))
    assert result['current_python_files_match_receipt']
    paths={'frozen':base/'preview/.runtime/generation-base.sqlite3','source':run/'source/.runtime/review.sqlite3','restored':run/'empty/.runtime/review.sqlite3'}
    before_hash={key:digest(path) for key,path in paths.items()}
    assert before_hash['frozen']==receipt['snapshot_sha256']
    frozen,source,restored=[read_db(path) for path in paths.values()];dbs.extend([frozen,source,restored])
    assert tables(frozen)==tables(source)
    assert tables(frozen)-{'generation_publications'}==tables(restored)
    frozen.execute('ATTACH DATABASE ? AS copied',(paths['source'].as_uri()+'?mode=ro',))
    frozen.execute('ATTACH DATABASE ? AS restored',(paths['restored'].as_uri()+'?mode=ro',))
    result['public_tables']={}
    for name in sorted(tables(frozen)|{'sqlite_sequence'}):
        assert count(frozen,name)==count(source,name)
        assert frozen.execute(f'SELECT * FROM main."{name}" EXCEPT SELECT * FROM copied."{name}" LIMIT 1').fetchone() is None,name
        if name in {'generation_publications','sqlite_sequence'}:continue
        assert count(frozen,name)==count(restored,name)
        assert frozen.execute(f'SELECT * FROM main."{name}" EXCEPT SELECT * FROM restored."{name}" LIMIT 1').fetchone() is None,name
        rows=sorted(canon(list(row)) for row in frozen.execute('SELECT * FROM "'+name+'"'))
        h=hashlib.sha256()
        for row in rows:h.update(row.encode());h.update(b'\n')
        observed={'rows':len(rows),'sha256':h.hexdigest()}
        assert observed==receipt['tables'][name],name
        result['public_tables'][name]=observed
    assert len(result['public_tables'])==22
    assert receipt['source_initial_all_tables']==receipt['source_before_export_all_tables']==receipt['source_after_export_all_tables']
    assert receipt['restored_before_export_all_tables']==receipt['restored_after_export_all_tables']
    result['private_publication_rows_retained_in_source_only']=count(frozen,'generation_publications')
    result['event_sequences']={}
    for name in ('comment_events','configuration_events'):
        old=frozen.execute('SELECT seq FROM sqlite_sequence WHERE name=?',(name,)).fetchone()[0]
        new=restored.execute('SELECT seq FROM sqlite_sequence WHERE name=?',(name,)).fetchone()[0]
        maximum=restored.execute('SELECT max(id) FROM '+name).fetchone()[0]
        assert new==maximum
        result['event_sequences'][name]={'source':old,'restored':new,'max_id':maximum,'equal_for_this_snapshot':old==new}
    print('Raw rows and receipt hashes checked',flush=True)
    holders=[]
    for key in ('source','restored'):
        db=read_db(paths[key]);dbs.append(db);holder=SimpleNamespace(db_path=paths[key],db=db)
        db.row_factory=material_storage.row_factory(holder);holders.append(holder)
    with production.read_scope(holders[0]),production.read_scope(holders[1]):
        first=holders[0].db.execute('SELECT id,payload FROM revisions ORDER BY id')
        second=holders[1].db.execute('SELECT id,payload FROM revisions ORDER BY id')
        logical=hashlib.sha256();matched=0
        while True:
            a,b=first.fetchone(),second.fetchone()
            if a is None or b is None:assert a is None and b is None;break
            assert tuple(a)==tuple(b),a['id']
            logical.update(canon([a['id'],a['payload']]).encode());logical.update(b'\n');matched+=1
        assert matched==receipt['exact_logical_revision_payloads']==10160
        result['exact_logical_payloads']={'count':matched,'sha256':logical.hexdigest()}
    with material_archives.read_scope(holders[1]):
        roots={};archive_digest=hashlib.sha256();counted=0
        for path,container in restored.execute('SELECT path,container FROM material_archive_files ORDER BY path'):
            target=run/'empty'/path;expected=json.loads(container)
            assert target.resolve().is_relative_to((run/'empty').resolve()) and target.is_file() and not target.is_symlink()
            raw=material_archives.read_bytes(target)
            actual=hashlib.sha256(raw).hexdigest();assert actual==expected['sha256'] and len(raw)==expected['bytes'],path
            archive_digest.update(canon([path,len(raw),actual]).encode());archive_digest.update(b'\n')
            roots[path.split('/')[0]]=roots.get(path.split('/')[0],0)+1;counted+=1
        assert counted==receipt['historic_archive_original_hashes']==1855
        result['historical_archives']={'count':counted,'roots':roots,'logical_audit_sha256':archive_digest.hexdigest()}
    print('All logical revisions and archives checked',flush=True)
    manifest=json.loads((run/'source/export/manifest.json').read_text())
    baseline_manifest=json.loads((base/'preview/export/manifest.json').read_text())
    assert manifest==baseline_manifest==json.loads((run/'empty/export/manifest.json').read_text())
    for name in ('source-export.log','empty-restore.log','empty-export.log'):
        assert json.loads((run/name).read_text())==manifest,name
    for name,expected in manifest['files'].items():
        assert digest(run/'source/export'/name)==expected==digest(run/'empty/export'/name),name
    assert digest(run/'source/export/manifest.json')==digest(run/'empty/export/manifest.json')
    assert len(manifest['files'])+1==receipt['deterministic_export_files']==1314
    result['manifest_files_plus_manifest']=1314
    result['restored_asset_file_count']=sum(p.is_file() for p in (run/'empty/export/assets').iterdir())
    assert result['restored_asset_file_count']==1307
    result['source_production_directory_absent']=not (run/'source/production').exists();assert result['source_production_directory_absent']
    result['restored_production_file_count']=sum(p.is_file() for p in (run/'empty/production').rglob('*'));assert result['restored_production_file_count']==1018
    log=[json.loads(line) for line in (base/'reviews/schema6-roundtrip-reset-01.log').read_text().splitlines()]
    assert log[:-1]==receipt['stages'] and log[-1]['passed'] is True and log[-1]['elapsed_seconds']==receipt['elapsed_seconds']
    stage={value['name']:value['elapsed'] for value in receipt['stages']}
    result['roundtrip_elapsed_seconds']=receipt['elapsed_seconds']
    result['restore_stage_interval_seconds']=stage['raw tables and exact logical history']-stage['restore empty']
    for db in dbs:db.close()
    dbs=[]
    after_hash={key:digest(path) for key,path in paths.items()}
    assert before_hash==after_hash
    result['database_files_unchanged_by_review']=after_hash
    result['passed']=True
except BaseException as error:
    result['passed']=False;result['error']=type(error).__name__+': '+str(error);raise
finally:
    signal.alarm(0)
    for db in dbs:db.close()
    result['elapsed_seconds']=time.monotonic()-started
    result['finished_utc']=datetime.now(timezone.utc).isoformat()
    review.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'passed':result.get('passed'),'elapsed_seconds':result['elapsed_seconds'],'review':str(review)},ensure_ascii=False),flush=True)
