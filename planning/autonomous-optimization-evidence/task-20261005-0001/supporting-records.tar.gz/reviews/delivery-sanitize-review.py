#!/usr/bin/env python3
"""Independent in-memory sanitizer/manifest-path checks; does not build a package."""
from pathlib import Path
import importlib.util,json,hashlib,datetime,ast,sys
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent.parent;script=ROOT/'delivery/build_evidence.py'
spec=importlib.util.spec_from_file_location('delivery_reviewed',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]
def sha(d):return hashlib.sha256(d).hexdigest()
def check(label,ok,detail=None):checks.append({'check':label,'passed':bool(ok),'detail':detail});assert ok,label
files=['backend-investigation/ao-perf-001-ab-guard-after.json','backend-investigation/ao-perf-001-ab-guard-before.json','backend-investigation/ao-perf-002-guard-after.json','backend-investigation/ao-perf-002-guard-before.json','backend-investigation/write-ab/reset-window-01/guard-after.json','backend-investigation/write-ab/reset-window-01/guard-before.json']
receipts=[]
for name in files:
 raw=(ROOT/name).read_bytes();parsed=json.loads(raw);clean=m.sanitize(raw,name);after=json.loads(clean)
 check('known backend digest replaced '+name,after['lease_digest']=='[REDACTED]' and parsed['lease_digest'].encode() not in clean)
 check('only credential-key values changed '+name,after==m.redact(parsed))
 check('idempotent '+name,m.sanitize(clean,name)==clean)
 receipts.append({'source':name,'source_sha256':sha(raw),'artifact':name,'artifact_sha256':sha(clean),'changed':raw!=clean,'credential_field':'lease_digest','source_value_length':len(parsed['lease_digest']),'artifact_value_length':len(after['lease_digest'])})
clock=[]
for name in ['state.json','latest-check.json','reset-result.json','startup-recovery.json','register-reset-supervisor.json','register-coverage-reviewer.json','register-write-performance.json','completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/state.json','completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/stop-receipt.json']:
 p=ROOT/name
 if not p.is_file():continue
 raw=p.read_bytes();artifact='clock/'+name.replace('/','__');first=(json.dumps(m.redact(json.loads(raw)),ensure_ascii=False,indent=2)+'\n').encode();second=m.sanitize(first,artifact)
 check('clock current second pass no further mutation '+name,first==second)
 clock.append({'source':name,'source_sha256':sha(raw),'artifact':artifact,'artifact_sha256':sha(second),'first_pass_changed':first!=raw,'second_pass_changed':second!=first,'recorded_transform_even_if_bytes_equal':first==raw})
# Confirm ordinary immutable input bytes and parser failure behavior without files.
plain=b'{"at":"kept", "nested":[{"value":1}]}\n';check('unaffected JSON byte exact',m.sanitize(plain,'x.json')==plain)
jsonl=b'{"lease_digest":"[REDACTED]","at":2}\n\n{"value":3}\n';c=m.sanitize(jsonl,'x.jsonl');check('JSONL precise redaction and blank lines',json.loads(c.splitlines()[0])=={'lease_digest':'[REDACTED]','at':2} and c.splitlines()[1]==b'' and c.splitlines()[2]==b'{"value":3}')
txt=b"{'lease_digest': '[REDACTED]', 't0': 3}\n";check('Python repr redaction retains other facts',m.sanitize(txt,'x.log')==b"{'lease_digest': '[REDACTED]', 't0': 3}\n")
try:m.sanitize(b'SQLite format 3\0'+b'\0'*10,'opaque.bin')
except ValueError:check('database magic aborts before output mutation',True)
else:check('database magic aborts before output mutation',False)
# Current full clock bridge identity is correct; if a later regex changes a sanitized artifact,
# second manifest source refers to an intermediate artifact, not a raw runtime path.
synthetic={'lease_digest':'[REDACTED]','note':"{'lease_token': '[REDACTED]'}"}
first=(json.dumps(m.redact(synthetic),ensure_ascii=False,indent=2)+'\n').encode();second=m.sanitize(first,'clock/synthetic.json')
second_changed=first!=second
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':sha(script.read_bytes()),'scope':'in-memory only, six actual backend files and current clock snapshots plus synthetic byte strings; no package build','checks':checks,'passed':all(x['passed'] for x in checks),'actual_backend_transformations':receipts,'clock_transformations':clock,'conditional_manifest_chain_issue':{'synthetic_second_pass_changes':second_changed,'explanation':'If clock first pass leaves a textual credential assignment in a string and second sanitizer changes bytes, current manifest appends an intermediate source=clock/name that is not an original runtime path; first entry artifact_sha identifies intermediate bytes, not final tar bytes. Current real clock snapshots had no second-pass change. Consolidate each artifact to original source plus final hash, or explicitly label a transformation chain.'},'clock_noop_transformation_entries':[x['source'] for x in clock if x['recorded_transform_even_if_bytes_equal']],'static_remaining_notes':['Explicit supplemental and old_report paths use is_file without allowed; current inventoried paths are not symlinks, but the general no-symlink rule is not uniformly enforced.','readable directory is not rebuilt/cleaned and manifest does not inventory its copies; removal on a later build can leave stale readable files.','Archive replacement is per archive and readable writes happen during compression; a failed rebuild can leave old manifest with mixed new/old deliverables. Use new sibling staging directory plus verify before publication to preserve last complete package.','Deliverable reading plan must explain extracting all three archives to readable and SHA validation; source markdown paths and alias links to sanitized clock names still need explicit portable rewrite/index.']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'checks':len(checks),'backend_transformed':len(receipts),'clock_checked':len(clock),'clock_noop_entries':result['clock_noop_transformation_entries'],'synthetic_second_pass_changes':second_changed,'script_sha256':result['script_sha256']},ensure_ascii=False,indent=2))
