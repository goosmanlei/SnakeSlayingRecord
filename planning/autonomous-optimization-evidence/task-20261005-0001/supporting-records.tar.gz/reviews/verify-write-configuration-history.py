"""Offline, read-only review of the already measured write experiment."""
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parents[1]
RUN = ROOT / 'backend-investigation/write-ab/reset-window-01'
SOURCE = ROOT / 'preview/.runtime/generation-base.sqlite3'
OUTPUT = Path(__file__).with_name('write-configuration-history-independent.json')


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_database(path):
    assert path.is_file() and not path.is_symlink() and path.resolve() == path
    with closing(sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)) as db:
        db.execute('PRAGMA query_only=ON')
        assert db.execute('PRAGMA query_only').fetchone()[0] == 1
        db.row_factory = sqlite3.Row
        events = [dict(row) for row in db.execute('SELECT * FROM configuration_events ORDER BY id')]
        configurations = [dict(row) for row in db.execute('SELECT * FROM configurations ORDER BY scope')]
    return events, configurations


paths = {'source': SOURCE, **{arm: RUN / arm / 'instance/.runtime/review.sqlite3'
                             for arm in ('baseline', 'candidate')}}
before = {name: digest(path) for name, path in paths.items()}
assert before['source'] == '5c6d00ee6efa7506201bbef46ffd69bde49f7300c4697fe66036e87ace7ed4f0'
original_events, original_configs = read_database(SOURCE)
original_project = next(row for row in original_configs if row['scope'] == 'PROJECT')
base_version = original_project['version']
base_body = json.loads(original_project['body'])
maximum_id = max(row['id'] for row in original_events)
result = {'checked_at_utc': datetime.now(timezone.utc).isoformat(),
          'method': 'existing copies; sqlite mode=ro plus PRAGMA query_only=ON; no HTTP requests or new measurements',
          'source_event_count': len(original_events), 'source_max_event_id': maximum_id,
          'source_project_version': base_version, 'arms': {}}
fixed_states = {}
for arm in ('baseline', 'candidate'):
    events, configs = read_database(paths[arm])
    old = [row for row in events if row['id'] <= maximum_id]
    new = [row for row in events if row['id'] > maximum_id]
    assert old == original_events
    assert len(new) == 7 and all(row['scope'] == 'PROJECT' for row in new)
    assert [row['id'] for row in new] == list(range(maximum_id + 1, maximum_id + 8))
    assert [row['version'] for row in new] == list(range(base_version + 1, base_version + 8))
    requests_path = RUN / arm / 'evidence/requests.json'
    requests = json.loads(requests_path.read_text())
    writes = [row for row in requests if row['path'] == '/api/configurations/PROJECT']
    success = sorted((row for row in writes if row['status'] == 200), key=lambda row: row['response']['version'])
    conflicts = [row for row in writes if row['status'] == 409]
    assert len(writes) == 14 and len(success) == len(conflicts) == 7
    previous = base_body
    checked = []
    for event, request in zip(new, success):
        response = request['response']
        expected = {**previous, **request['payload']['updates']}
        assert set(request['payload']['updates']) == {'audience'}
        assert request['payload']['expected_version'] + 1 == event['version'] == response['version']
        assert response['scope'] == event['scope'] == 'PROJECT'
        assert response['schema_version'] == original_project['schema_version']
        assert json.loads(event['body']) == response['body'] == expected
        assert event['body'] == canonical(expected)
        assert event['at'] == response['updated_at']
        assert {key: value for key, value in expected.items() if key != 'audience'} == {
            key: value for key, value in base_body.items() if key != 'audience'}
        checked.append({'event_id': event['id'], 'scope': event['scope'], 'version': event['version'],
                        'at': event['at'], 'request_id': request['request_id'], 'name': request['name'],
                        'audience': expected['audience'], 'body_sha256': hashlib.sha256(event['body'].encode()).hexdigest(),
                        'full_body_matches_http_and_expected_update': True,
                        'raw_body_is_exact_canonical_expected_body': True,
                        'all_other_body_fields_unchanged': True})
        previous = expected
    winner = next(row for row in success if row['name'].startswith('configuration-competing-'))
    loser = next(row for row in conflicts if row['name'].startswith('configuration-competing-'))
    assert winner['payload']['expected_version'] == loser['payload']['expected_version']
    assert all(json.loads(row['body'])['audience'] != loser['payload']['updates']['audience'] for row in new)
    current = next(row for row in configs if row['scope'] == 'PROJECT')
    assert current['version'] == new[-1]['version']
    assert current['body'] == new[-1]['body'] and current['updated_at'] == new[-1]['at']
    assert [row for row in configs if row['scope'] != 'PROJECT'] == [
        row for row in original_configs if row['scope'] != 'PROJECT']
    fixed_states[arm] = [{key: row[key] for key in ('id', 'scope', 'version', 'body')} for row in new[:6]]
    result['arms'][arm] = {'requests_sha256': digest(requests_path), 'old_events_byte_equal': True,
                           'new_events': checked, 'new_event_count': len(new),
                           'configuration_conflict_count': len(conflicts),
                           'no_extra_event_for_conflicts': True,
                           'competition_winner': winner['request_id'], 'competition_loser': loser['request_id'],
                           'loser_body_absent_from_new_events': True,
                           'current_project_matches_last_event': True, 'other_configurations_equal': True}
assert fixed_states['baseline'] == fixed_states['candidate']
after = {name: digest(path) for name, path in paths.items()}
assert before == after
result.update(database_sha256_before=before, database_sha256_after=after,
              files_unchanged=True, six_fixed_event_bodies_and_versions_equal_between_arms=True,
              configuration_event_body_limitation_closed=True)
OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'result': 'passed', 'old_events_per_arm': len(original_events),
                  'new_events_per_arm': 7, 'versions': [base_version + 1, base_version + 7],
                  'full_bodies_and_timestamps_verified': True, 'files_unchanged': True,
                  'evidence': str(OUTPUT.relative_to(ROOT))}, ensure_ascii=False))
