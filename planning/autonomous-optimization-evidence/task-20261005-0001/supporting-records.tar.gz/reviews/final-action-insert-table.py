#!/usr/bin/env python3
import json
from pathlib import Path
p=Path(__file__).with_name('final-action-independent.md')
r=json.loads(p.with_suffix('.json').read_text())
lines=['| Operation direction | A round 1 | B round 1 | A round 2 | B round 2 | Verdict |','| --- | --- | --- | --- | --- | --- |']
for x in r['comparisons']:
 vals=[f"{y['formal']['median_ms']:.2f} [{y['formal']['min_ms']:.2f}-{y['formal']['max_ms']:.2f}]" for y in x['phases'].values()]
 verdict='Both rounds' if x['verdict']=='BOTH_ROUNDS_OBSERVED_IMPROVEMENT' else 'Not established'
 if x['id'] in ('D1-scene2','S3-version3'):verdict='Round 2 only'
 if x['id'].startswith('P2-'):verdict='Numeric only; AO-UX008'
 lines.append('| '+' | '.join([x['label']+' / '+x['id']]+vals+[verdict])+' |')
s=p.read_text();marker='\n\u5236\u4f5c\u62c6\u89e3\u8fdb\u5165 S002'
assert marker in s and '| Operation direction |' not in s
s=s.replace(marker,'\n'+ '\n'.join(lines)+'\n'+marker,1)
p.write_text(s)
print({'lines':len(s.splitlines()),'bytes':p.stat().st_size,'data_rows':sum(l.startswith('| ') for l in s.splitlines())})
