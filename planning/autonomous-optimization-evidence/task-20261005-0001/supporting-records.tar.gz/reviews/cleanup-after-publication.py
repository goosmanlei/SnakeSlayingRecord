#!/usr/bin/env python3
"""Phase B only: fixed preview PID and three fixed trees. Default: dry-run.

--capture-baseline records hashes/identities without stopping or deleting.
--apply requires authentic publication and read-only formal browser receipts.
Every changed or still-used tree is retained. No recursive whole-runtime removal.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import signal
import stat
import subprocess
import sys
import tarfile
import time

TASK = 'task-20261005-0001'
ROOT = Path(__file__).absolute().parents[3]
RUNTIME = ROOT / '.runtime/autonomous-optimization'
REVIEWS = RUNTIME / 'reviews'
CLOSING = REVIEWS / 'closing-receipts'
BASELINE = REVIEWS / 'cleanup-after-publication-baseline.json'
TARGETS = ('final-preview', 'technical-readiness/instance', 'technical-readiness/preflight-instance')
PID, PORT = 96270, 62608
SERVICE_ARGS = ('scripts/generation_review.py', '--instance',
                '.runtime/autonomous-optimization/final-preview', '--system',
                '.runtime/autonomous-optimization/system-worktree', 'serve', '--port', '62608')
FROZEN = '5c6d00ee6efa7506201bbef46ffd69bde49f7300c4697fe66036e87ace7ed4f0'
PROTECTED = ('preview/.runtime/generation-base.sqlite3',
             'preview/.runtime/generation-base.json', 'run-baseline.json')
SYSTEMS = ('system-baseline', 'system-perf001', 'system-worktree')


def need(value, reason):
    if not value:
        raise RuntimeError(reason)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def run(args, allowed=(0,)):
    p = subprocess.run(args, capture_output=True, text=True, errors='replace', timeout=30)
    need(p.returncode in allowed and not p.stderr.strip(), 'dependency command failed: ' + args[0])
    return p.stdout


def safe(path):
    path = Path(path).absolute()
    need(not any(p.is_symlink() for p in (path, *path.parents)), 'symlink path rejected')
    return path


def relative(name):
    p = PurePosixPath(name)
    need(name and name != '.' and str(p) == name and not p.is_absolute()
         and not {'.', '..', '.git'} & set(p.parts), 'unsafe relative inventory path')
    return p


def digest(path):
    h = hashlib.sha256()
    with safe(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def item(path):
    safe(path)
    s = path.lstat()
    need(stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode), 'special file rejected')
    row = {'path': str(path.relative_to(RUNTIME)), 'device': s.st_dev, 'inode': s.st_ino,
           'kind': 'file' if stat.S_ISREG(s.st_mode) else 'directory'}
    relative(row['path'])
    if row['kind'] == 'file':
        row.update(bytes=s.st_size, mtime_ns=s.st_mtime_ns, sha256=digest(path))
        t = path.lstat()
        need((s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns) ==
             (t.st_dev, t.st_ino, t.st_size, t.st_mtime_ns), 'file changed while hashing')
    return row


def inventory(rel):
    need(rel in TARGETS, 'target scope changed')
    p = RUNTIME / rel
    need(p.is_dir(), 'target is missing or not a directory: ' + rel)
    root = item(p)
    rows = [item(x) for x in [p, *sorted(p.rglob('*'))]]
    need(all(x['device'] == root['device'] for x in rows), 'nested mount rejected')
    return {'path': rel, 'rows': rows, 'files': sum(x['kind'] == 'file' for x in rows),
            'bytes': sum(x.get('bytes', 0) for x in rows)}


def process():
    line = run(['ps', '-p', str(PID), '-o', 'lstart=,command='], (0, 1)).strip()
    if not line:
        return None
    parts = line.split(None, 5)
    need(len(parts) == 6, 'cannot parse exact preview process')
    argv = shlex.split(parts[5])
    need(tuple(argv[1:]) == SERVICE_ARGS and Path(argv[0]).name in ('Python', 'python3'),
         'PID reused or preview command changed')
    cwd = run(['lsof', '-nP', '-a', '-p', str(PID), '-d', 'cwd', '-Fn'])
    need([x[1:] for x in cwd.splitlines() if x.startswith('n')] == [str(ROOT)],
         'preview working directory changed')
    listeners = run(['lsof', '-nP', '-iTCP:' + str(PORT), '-sTCP:LISTEN', '-Fp'], (0, 1))
    need({int(x[1:]) for x in listeners.splitlines() if x.startswith('p')} == {PID},
         'preview listener identity changed')
    return {'pid': PID, 'port': PORT, 'start': ' '.join(parts[:5]), 'argv': argv,
            'cwd_relative_to_workspace': '.'}


def users(rel):
    """Keep only PID/container identifiers and counts, never arbitrary argv/env."""
    target = safe(RUNTIME / rel)
    found, pid = {}, None
    output = run(['lsof', '-nP', '-Fpn', '+D', str(target)], (0, 1))
    for line in output.splitlines():
        if line.startswith('p'):
            pid = int(line[1:])
        elif line.startswith('n') and pid != os.getpid():
            found.setdefault(pid, {'pid': pid, 'open_handles': 0, 'argument_reference': False})['open_handles'] += 1
    relative_target = '.runtime/autonomous-optimization/' + rel
    for line in run(['ps', '-axo', 'pid=,command=']).splitlines():
        columns = line.strip().split(None, 1)
        if len(columns) != 2 or not columns[0].isdigit() or int(columns[0]) == os.getpid():
            continue
        try:
            tokens = shlex.split(columns[1])
        except ValueError:
            tokens = []
        if any(t == str(target) or t.startswith(str(target) + '/') or
               t == relative_target or t.startswith(relative_target + '/') for t in tokens):
            pid = int(columns[0])
            found.setdefault(pid, {'pid': pid, 'open_handles': 0, 'argument_reference': False})['argument_reference'] = True
    # A parent formal mount is protected, never stopped. Exact child mounts block deletion.
    mounts = []
    for container in run(['docker', 'ps', '-aq']).split():
        for mount in json.loads(run(['docker', 'inspect', '--format', '{{json .Mounts}}', container])):
            source = Path(mount['Source'])
            if source == target or target in source.parents:
                mounts.append({'container_id': container, 'exact_target_mount': True})
    return list(found.values()) + mounts


def protected():
    rows = [item(RUNTIME / p) for p in PROTECTED]
    need(rows[0]['sha256'] == FROZEN, 'frozen 6236-object database changed')
    systems = []
    for rel in SYSTEMS:
        p = safe(RUNTIME / rel)
        need(not run(['git', '-C', str(p), 'status', '--porcelain', '--untracked-files=no']).strip(),
             'tracked system worktree files changed: ' + rel)
        systems.append({'path': rel, 'device': p.stat().st_dev, 'inode': p.stat().st_ino,
                        'head': run(['git', '-C', str(p), 'rev-parse', 'HEAD']).strip()})
    return {'files': rows, 'git_worktrees': systems}


def write_once(path, data):
    safe(path.parent)
    need(path.parent in (REVIEWS, CLOSING) and path.name.startswith('cleanup-after-publication-')
         and path.suffix == '.json', 'receipt outside fixed reviews scope')
    fd = os.open(str(path), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')
        f.flush()
        os.fsync(f.fileno())


def load(path, expected):
    need(re.fullmatch('[a-f0-9]{64}', expected or ''), 'full input SHA-256 required')
    need(digest(path) == expected, 'input SHA mismatch: ' + Path(path).name)
    return json.loads(safe(path).read_text())


def verify_archive(manifest_path, expected_sha):
    m = load(manifest_path, expected_sha)
    need(m.get('task_id') == TASK and m.get('format') == 'autonomous-review-evidence-v1',
         'wrong final evidence manifest')
    listed = {r['path']: r for r in m['files']}
    need(len(listed) == len(m['files']), 'duplicate evidence artifact')
    seen = set()
    for archive in m['archives']:
        relative(archive['path'])
        p = Path(manifest_path).parent / archive['path']
        need(digest(p) == archive['sha256'] and p.stat().st_size == archive['bytes'], 'archive changed')
        with tarfile.open(p, 'r:gz') as tar:
            for member in tar:
                relative(member.name)
                need(member.isfile() and member.name not in seen, 'unsafe/duplicate archive member')
                row = listed.get(member.name)
                need(row is not None and row['archive'] == archive['path'], 'unlisted archive member')
                stream = tar.extractfile(member)
                h = hashlib.sha256()
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    h.update(block)
                need(h.hexdigest() == row['sha256'] and member.size == row['bytes'], 'artifact changed')
                seen.add(member.name)
    need(seen == set(listed), 'missing evidence artifact')
    return m


def gates(a):
    need(all([a.evidence_manifest, a.evidence_manifest_sha256, a.release_manifest,
              a.release_manifest_sha256, a.image_receipt_sha256, a.publication_receipt,
              a.publication_receipt_sha256, a.formal_receipt, a.formal_receipt_sha256]),
         'publication/formal acceptance inputs are not yet complete')
    verify_archive(a.evidence_manifest, a.evidence_manifest_sha256)
    release = load(a.release_manifest, a.release_manifest_sha256)
    image_path = a.release_manifest.parent / 'image.json'
    image = load(image_path, a.image_receipt_sha256)
    need(release.get('task') == TASK and release.get('format') == 'material-review-release-v1', 'wrong release')
    need(release.get('system_candidate') == run(['git', '-C', str(RUNTIME / 'system-worktree'),
                                               'rev-parse', 'HEAD']).strip(), 'release differs from reviewed system worktree')
    need(image.get('manifest_sha256') == a.release_manifest_sha256 and image.get('source_verified') is True,
         'image receipt is not bound to release manifest')
    pub = load(a.publication_receipt, a.publication_receipt_sha256)
    need(a.publication_receipt.parent.resolve() == (a.release_manifest.parent / 'run').resolve(),
         'publication receipt is outside exact release run')
    need(pub.get('status') == 'formal_browser_pending' and pub.get('business_delta') == 0
         and pub.get('complete_invoked') is False and pub.get('push') is False
         and pub.get('system_candidate') == release['system_candidate']
         and pub.get('release') == str(Path(release['story_main']) / '.runtime/service-releases' / release['release_name'])
         and bool(pub.get('service')) and bool(pub.get('rows')), 'publication apply receipt is incomplete')
    need(pub['service'].get('source_tree_equal') is True
         and pub['service'].get('instance_files_equal') is True
         and pub['service'].get('ports') == [3000, 64401]
         and all(v.get('preserved') is True for v in pub['rows'].values()),
         'formal service identity/history preservation was not verified')
    formal = load(a.formal_receipt, a.formal_receipt_sha256)
    expected = {'task': TASK, 'system_candidate': release['system_candidate'],
                'story_candidate': release['story_candidate'], 'passed': True, 'readonly': True,
                'manifest_sha256': a.release_manifest_sha256, 'image_receipt_sha256': a.image_receipt_sha256,
                'publication_receipt_sha256': a.publication_receipt_sha256}
    need(all(type(formal.get(k)) is type(v) and formal.get(k) == v for k, v in expected.items()),
         'formal read-only browser acceptance is absent, failed or bound to different inputs')
    need(formal.get('evidence'), 'formal browser evidence paths/hashes required')
    for evidence in formal['evidence']:
        relative(evidence['path'])
        need(digest(ROOT / evidence['path']) == evidence['sha256'], 'formal browser evidence changed')
    return {'evidence_manifest_sha256': a.evidence_manifest_sha256,
            'release_manifest_sha256': a.release_manifest_sha256,
            'image_receipt_sha256': a.image_receipt_sha256,
            'publication_receipt_sha256': a.publication_receipt_sha256,
            'formal_receipt_sha256': a.formal_receipt_sha256}


def remove_item(row):
    """Only preinventoried entries; reject path replacement via no-follow dir FDs."""
    parts = relative(row['path']).parts
    need(any(row['path'] == t or row['path'].startswith(t + '/') for t in TARGETS), 'delete outside three trees')
    fd = os.open(str(RUNTIME), os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        for part in parts[:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = child
        current = os.stat(parts[-1], dir_fd=fd, follow_symlinks=False)
        need((current.st_dev, current.st_ino) == (row['device'], row['inode']), 'entry identity changed during cleanup')
        if row['kind'] == 'directory':
            need(stat.S_ISDIR(current.st_mode), 'directory replaced')
            os.rmdir(parts[-1], dir_fd=fd)
        else:
            need(stat.S_ISREG(current.st_mode) and current.st_size == row['bytes']
                 and current.st_mtime_ns == row['mtime_ns'], 'file changed during cleanup')
            os.unlink(parts[-1], dir_fd=fd)
    finally:
        os.close(fd)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--capture-baseline', action='store_true')
    p.add_argument('--apply', action='store_true')
    p.add_argument('--baseline-sha256')
    for name in ['evidence-manifest', 'release-manifest', 'publication-receipt', 'formal-receipt']:
        p.add_argument('--' + name, type=Path)
        p.add_argument('--' + name + '-sha256')
    p.add_argument('--image-receipt-sha256')
    a = p.parse_args()
    need(ROOT.name == TASK, 'wrong task workspace')
    need(not (a.apply and a.capture_baseline), 'capture may never apply')
    if a.capture_baseline:
        value = {'task': TASK, 'format': 'phase-b-cleanup-baseline-v1', 'captured_at': now(),
                 'service': process(), 'targets': [inventory(t) for t in TARGETS],
                 'users': {t: users(t) for t in TARGETS}, 'protected': protected()}
        need(value['service'] is not None, 'baseline must identify the currently running exact service')
        write_once(BASELINE, value)
        print(json.dumps({'status': 'baseline_only', 'sha256': digest(BASELINE),
                          'targets': [{k: t[k] for k in ['path', 'files', 'bytes']} for t in value['targets']],
                          'users': value['users']}, ensure_ascii=False))
        return
    run_id = str(time.time_ns())
    safe(CLOSING)
    CLOSING.mkdir(exist_ok=True)
    journal_path = CLOSING / ('cleanup-after-publication-journal-' + run_id + '.jsonl')
    def journal(event):
        if not a.apply:
            return
        fd = os.open(str(journal_path), os.O_WRONLY | os.O_CREAT | os.O_APPEND | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, 'a') as f:
            f.write(json.dumps({'at': now(), **event}, ensure_ascii=False) + '\n')
            f.flush()
            os.fsync(f.fileno())
    receipt = {'task': TASK, 'started_at': now(), 'apply': a.apply, 'status': 'blocked',
               'scope': list(TARGETS), 'service_action': 'none', 'trees': [], 'raw_sources': 'retained'}
    try:
        expected_sha = a.baseline_sha256 if a.apply else (a.baseline_sha256 or digest(BASELINE))
        base = load(BASELINE, expected_sha)
        need(base.get('task') == TASK and tuple(x['path'] for x in base['targets']) == TARGETS, 'baseline scope changed')
        receipt['baseline_sha256'] = expected_sha
        need(protected() == base['protected'], 'protected frozen/source/Git identity changed')
        current_process = process()
        need(current_process == base['service'], 'preview PID/start/command identity changed or service is absent')
        if not a.apply:
            receipt['readonly_preflight'] = []
            for target in base['targets']:
                rel = target['path']
                try:
                    receipt['readonly_preflight'].append({'path': rel,
                        'unchanged': inventory(rel) == target, 'users': users(rel)})
                except Exception as e:
                    receipt['readonly_preflight'].append({'path': rel, 'error': str(e)})
        receipt['inputs'] = gates(a)
        receipt['service_identity_verified'] = True
        if a.apply:
            need(process() == base['service'], 'preview identity changed immediately before stop')
            journal({'action': 'before_SIGTERM', 'pid': PID, 'inputs': receipt['inputs'],
                     'baseline_sha256': expected_sha})
            os.kill(PID, signal.SIGTERM)
            receipt['service_action'] = 'SIGTERM_sent'
            for _ in range(80):
                if not run(['ps', '-p', str(PID), '-o', 'pid='], (0, 1)).strip():
                    break
                time.sleep(0.1)
            else:
                raise RuntimeError('preview did not exit; no SIGKILL and no trees deleted')
            need(not run(['lsof', '-nP', '-iTCP:' + str(PORT), '-sTCP:LISTEN', '-Fp'], (0, 1)).strip(),
                 '62608 has a replacement listener; no trees deleted')
            receipt['service_action'] = 'stopped_exact_preview'
            journal({'action': 'exact_preview_stopped', 'pid': PID})
        for target in base['targets']:
            rel = target['path']
            row = {'path': rel, 'status': 'retained', 'deleted_files': 0, 'deleted_bytes': 0}
            receipt['trees'].append(row)
            try:
                actual = inventory(rel)
                need(actual == target, 'tree identity/content changed; preserve the entire tree including potential new user input')
                active = users(rel)
                if not a.apply:
                    active = [u for u in active if u.get('pid') != PID]
                row['users'] = active
                need(not active, 'other users still hold this tree; no user/container is stopped')
                if not a.apply:
                    row['status'] = 'would_delete_after_stopping_exact_preview'
                    continue
                need(protected() == base['protected'], 'protected identity changed')
                need(inventory(rel) == target and not users(rel), 'tree changed or acquired a user before removal')
                journal({'action': 'before_tree_removal', 'path': rel, 'files': target['files'], 'bytes': target['bytes']})
                for entry in sorted(target['rows'], key=lambda x: len(PurePosixPath(x['path']).parts), reverse=True):
                    journal({'action': 'before_remove_entry', 'path': entry['path'], 'inode': entry['inode']})
                    remove_item(entry)
                    if entry['kind'] == 'file':
                        row['deleted_files'] += 1
                        row['deleted_bytes'] += entry['bytes']
                need(not (RUNTIME / rel).exists(), 'tree remains after cleanup')
                row['status'] = 'deleted'
                journal({'action': 'tree_deleted', 'path': rel})
            except Exception as e:
                row['reason'] = str(e)
                if row['deleted_files']:
                    row['status'] = 'partial_retained_requires_review'
                journal({'action': 'tree_retained', 'path': rel, 'reason': row['reason']})
        need(protected() == base['protected'], 'protected identity changed after cleanup')
        receipt['status'] = ('retained_or_partial' if any(t['status'] in ('retained', 'partial_retained_requires_review')
                             for t in receipt['trees']) else ('completed' if a.apply else 'dry_run_ready'))
    except Exception as e:
        receipt['reason'] = str(e)
    finally:
        receipt['finished_at'] = now()
        out = CLOSING / ('cleanup-after-publication-' + ('apply-' if a.apply else 'dry-run-') + run_id + '.json')
        write_once(out, receipt)
        print(json.dumps({'receipt': str(out.relative_to(ROOT)), **receipt}, ensure_ascii=False))
    if receipt['status'] in ('blocked', 'retained_or_partial'):
        sys.exit(2)


if __name__ == '__main__':
    main()
