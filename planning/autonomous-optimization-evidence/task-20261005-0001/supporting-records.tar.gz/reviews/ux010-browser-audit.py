"""Offline cross-check of saved UX010 snapshots and the committed song package."""
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import hashlib
import json
import re
import struct

ROOT = Path(__file__).resolve().parents[3]
RUNTIME = ROOT / '.runtime/autonomous-optimization'
EVIDENCE = RUNTIME / 'browser/merged-main-final'
PACKAGE = ROOT / 'production/publications/songs-current-model-v2.json'
OUT = Path(__file__).with_name('ux010-browser-independent.json')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
packet = json.loads(PACKAGE.read_text())
objects = {c['after']['id']: c['after'] for c in packet['changes']['objects']}
revisions = {c['after']['id']: c['after'] for c in packet['changes']['revisions']}
files = {p.stem: json.loads(p.read_text()) for p in sorted(EVIDENCE.glob('*.json'))}
checks = []

def check(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})

def query(record):
    return {k: v[0] for k, v in parse_qs(urlparse(record['observed']['url']).query).items()}

def outer_pressed(record):
    s = record['snapshot']
    start = s.find('  - navigation "制作实体":')
    if start < 0:
        return None
    end = s.find('  - article:', start)
    return re.findall(r'- button "([^"]+)"[^\n]*\[pressed\]', s[start:end])

check('exact evidence inventory', len(files) == 12 and len(list(EVIDENCE.glob('*.png'))) == 2)
for name, record in files.items():
    check(name + ': functional viewport', record['observed']['viewport'] == {'width': 2192, 'height': 1359, 'dpr': 1})
    for select in record['observed']['selects']:
        if select['label'] in ['三道滩的版本', '明月还乡的版本']:
            owner = 'entity-boat-song' if select['label'].startswith('三道滩') else 'entity-blessing-stage-song'
            expected = objects[owner]
            check(name + ': current entity revision ' + owner,
                  select['value'] == expected['current_revision'] and select['selected'] == f"版本 {expected['version']} · 当前")

media = []
for name in ['boat-v3-before', 'boat-v3-playing', 'boat-v3-paused', 'blessing-v2-comments']:
    r = files[name]
    q = query(r)
    rev = revisions[q['production_revision']]
    payload = json.loads(rev['payload'])
    original = next(c for c in payload['components'] if c['id'] == 'original')
    audios = r['observed']['audio']
    check(name + ': exactly one audio', len(audios) == 1)
    audio = audios[0]
    source = ROOT / 'export/assets' / original['file']
    check(name + ': exact original URL and duration',
          urlparse(audio['src']).path == '/api/production/files/' + original['file']
          and audio['duration'] == original['duration_seconds'] and audio['readyState'] == 4
          and audio['error'] is None)
    check(name + ': original file bytes/hash',
          source.stat().st_size == original['bytes'] and sha(source) == original['sha256'])
    check(name + ': exact selected asset revision',
          q['production_object'] == rev['object_id'] and
          any(s['label'] == '本轮候选' and s['value'] == rev['id'] for s in r['observed']['selects']))
    media.append({'evidence': name + '.json', 'revision': rev['id'], 'object': rev['object_id'],
                  'original': original, 'observed': audio, 'local_source': str(source.relative_to(ROOT))})

playing = files['boat-v3-playing']['observed']['audio'][0]
paused = files['boat-v3-paused']['observed']['audio'][0]
check('boat historical audio advances and pauses',
      not playing['paused'] and playing['currentTime'] > 0 and paused['paused']
      and paused['currentTime'] > playing['currentTime'] and playing['src'] == paused['src'])

for name, version in [('boat-v4-current', 4), ('blessing-current-selection-mismatch', 3),
                      ('ux010-boat-selected', 4), ('ux010-blessing-selected', 3)]:
    r = files[name]
    check(name + ': current empty material retains own version',
          not r['observed']['audio'] and '未生成' in r['snapshot'] and
          any(s['label'] == '素材版本' and s['selected'] == f'版本 {version} · 当前'
              for s in r['observed']['selects']))

comments_record = files['blessing-v2-comments']
panel = comments_record['snapshot'].split('- complementary "审阅评论":', 1)[1]
comments = [c['after'] for c in packet['changes']['comments'] if 'blessing' in c['after']['target_object_id']]
check('three open comments and zero closed', len(comments) == 3 and '未关闭评论 · 3' in panel
      and '已关闭评论 · 0' in panel and panel.count('    - button "关闭评论"') == 3)
for c in comments:
    check('comment body/status/anchor ' + c['id'],
          ' '.join(c['body'].split()) in panel and c['status'] == 'OPEN'
          and json.loads(c['anchor'])['quote'] in panel)
check('comments retain plan v3 / exact asset v2 grouping',
      '素材方案 · 明月还乡·完整独立歌曲 · 版本 3 · 1' in panel
      and '素材 · 明月还乡 · Lyria 完整演唱候选 · 版本 2 · 2' in panel
      and all(c['target_revision_id'] == query(comments_record)['production_revision']
              for c in comments if c['target_object_id'] == 'asset-songs-blessing-full'))

before = files['blessing-current-selection-mismatch']
check('original mismatch is reproduced in saved evidence',
      query(before)['production_entity'] == 'entity-blessing-stage-song'
      and 'heading "明月还乡" [level=2]' in before['snapshot']
      and outer_pressed(before) == ['三道滩 声音 9'])
for name, owner, label in [('ux010-boat-selected', 'entity-boat-song', '三道滩 声音 9'),
                            ('ux010-blessing-selected', 'entity-blessing-stage-song', '明月还乡 声音 3')]:
    r = files[name]
    check(name + ': unique matching outer pressed', query(r)['production_entity'] == owner
          and outer_pressed(r) == [label])

for opening, closing in [('ux010-modal-open', 'ux010-modal-closed'),
                         ('ux010-modal-doubleclick', 'ux010-doubleclick-closed')]:
    opened, closed = files[opening], files[closing]
    check(opening + ': correct related entity card and outer selection',
          '- dialog "实体与素材"' in opened['snapshot']
          and 'heading "戏班伙计与台上演员"' in opened['snapshot']
          and query(opened)['production_entity'] == 'entity-troupe-workers'
          and outer_pressed(opened) == ['明月还乡 声音 3'])
    check(closing + ': restores exact outer route and selection',
          '- dialog ' not in closed['snapshot']
          and closed['observed']['url'] == files['ux010-blessing-selected']['observed']['url']
          and outer_pressed(closed) == ['明月还乡 声音 3'])

pngs = []
for path in sorted(EVIDENCE.glob('*.png')):
    b = path.read_bytes()
    if b.startswith(b'\x89PNG\r\n\x1a\n'):
        width, height = struct.unpack('>II', b[16:24])
        image_format = 'PNG'
    else:
        assert b.startswith(b'\xff\xd8'), 'unsupported image format'
        image_format = 'JPEG'
        cursor = 2
        while cursor < len(b):
            assert b[cursor] == 255
            while b[cursor] == 255:
                cursor += 1
            marker = b[cursor]
            cursor += 1
            length = struct.unpack('>H', b[cursor:cursor + 2])[0]
            if marker in [0xc0, 0xc1, 0xc2]:
                height, width = struct.unpack('>HH', b[cursor + 3:cursor + 7])
                break
            cursor += length
    check(path.name + ': screenshot dimensions', (width, height) == (2192, 1359))
    pngs.append({'file': path.name, 'sha256': sha(path), 'format': image_format, 'width': width, 'height': height,
                 'independently_visually_inspected': True})

result = {'scope': 'Offline independent review of coordinator-captured snapshots and actual PNGs; no browser/service/DB writes',
          'inventory': [{'file': p.name, 'sha256': sha(p)} for p in sorted(EVIDENCE.glob('*.json'))],
          'package': {'file': str(PACKAGE.relative_to(ROOT)), 'sha256': sha(PACKAGE)},
          'checks': checks, 'passed': all(c['passed'] for c in checks),
          'media': media, 'comments': comments, 'pngs': pngs,
          'limits': ['2192x1359 DPR1 functional acceptance; excluded from 1440x900 performance samples',
                     'Saved snapshots do not independently bind server source commit; candidate file identity is in the offline code audit',
                     'Playback is muted, brief and proves progress/pause only; no audio quality or lyric acceptance',
                     'AX [active] is focus, not evidence of CSS .active; CSS synchronization is checked by offline fixtures',
                     'Both files named .png contain JPEG bytes; original names/bytes are preserved',
                     'Enter vs double-click is coordinator action attribution; saved snapshots prove resulting open/closed states',
                     'Comment content/anchors and grouping were read, not edited or relocated in this acceptance']} 
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'passed': result['passed'], 'failed': [c for c in checks if not c['passed']]}, ensure_ascii=False))
