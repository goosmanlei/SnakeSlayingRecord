// Independent offline checks of actual production workspace/card methods.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),{createRequire}=require('node:module'),crypto=require('node:crypto');
const base=path.resolve('.runtime/autonomous-optimization/system-worktree'),out=path.resolve('.runtime/autonomous-optimization/reviews');
const dependencies=['review_desk/static/production.js','review_desk/static/unified-cards.js','review_desk/static/navigation.js','review_desk/static/production-breakdown.js','tests/load_review_helpers.cjs','tests/production_change.test.cjs','tests/production_navigation.test.cjs'];
const hashes=()=>Object.fromEntries(dependencies.map(f=>[f,crypto.createHash('sha256').update(fs.readFileSync(path.join(base,f))).digest('hex')]));
const beforeHashes=hashes(),results=[];
function harness(file,marker,expose){
 const absolute=path.join(base,'tests',file),source=fs.readFileSync(absolute,'utf8').split(marker)[0];
 assert.ok(source.length>100);const c={require:createRequire(absolute),__dirname:path.dirname(absolute),process,console,setImmediate,URL,URLSearchParams};
 vm.createContext(c);vm.runInContext(source+'\n'+expose,c);return c;
}
function tracked(n){n._active=false;n.classList={add(){},remove(){},toggle(name,value){if(name==='active')n._active=!!value;return value}};return n}
async function actualFixture(){
 const h=harness('production_change.test.cjs',"test('a late saved judgment",'globalThis.make=fixture;globalThis.E=Node;');
 const f=h.make(),c=f.context,oldEl=c.el,oldText=c.nodeText;
 c.el=(...a)=>tracked(oldEl(...a));c.nodeText=(...a)=>tracked(oldText(...a));
 c.document.querySelectorAll=s=>s==='#production-index button'?(c.$('#production-index')?.all().filter(n=>n.tag==='button')||[]):[];
 await c.loadProductionWorkspace();
 const cards=()=>c.document.querySelectorAll('#production-index button').filter(n=>n.dataset.objectId);
 const snap=()=>({object:c.state.productionSelected?.object_id,revision:c.state.productionSelected?.id,url:c.location.href,cards:cards().map(n=>({object:n.dataset.objectId,pressed:n.attrs['aria-pressed'],active:n._active}))});
 function correct(object,revision){const s=snap();assert.equal(s.object,object);assert.equal(s.revision,revision);assert.equal(new URL(s.url).searchParams.get('production_object'),object);assert.equal(new URL(s.url).searchParams.get('production_revision'),revision);for(const n of s.cards){assert.equal(n.pressed,String(n.object===object));assert.equal(n.active,n.object===object)}return s}
 const [a,b]=cards().map(n=>n.dataset.objectId),first=correct(a,a+'-r1');results.push({name:'actual initial load creates correct pressed and active state',passed:true,evidence:first});
 const extra=tracked(new h.E('button'));c.$('#production-index').append(extra);
 await cards().find(n=>n.dataset.objectId===b).onclick();const toB=correct(b,b+'-r1');assert.equal(extra.attrs['aria-pressed'],undefined);
 await cards().find(n=>n.dataset.objectId===a).onclick();const backA=correct(a,a+'-r1');assert.equal(extra.attrs['aria-pressed'],undefined);results.push({name:'actual reviewSmallCard clicks A to B to A preserve exact displayed selection; unrelated index button never gets aria-pressed',passed:true,evidence:{toB,backA}});
 const original=c.api,old={...f.records.find(r=>r.object_id===b),id:b+'-old',version:0};
 c.api=async(url,options)=>{const u=new URL(url,'http://fixture');if(u.searchParams.get('revision_id')===old.id)return {record:old,history:[f.records.find(r=>r.object_id===b),old],uses:[]};return original(url,options)};
 await c.openProductionRecord(b,old.id);const oldSnap=correct(b,old.id);assert.equal(c.state.productionDetail.record.id,old.id);assert.equal(extra.attrs['aria-pressed'],undefined);results.push({name:'same object exact historical revision keeps object selection, old detail and route',passed:true,evidence:oldSnap});
 c.api=original;await c.openProductionRecord(b);let release;
 c.api=(url,options)=>new URL(url,'http://fixture').searchParams.get('object_id')===a?new Promise(resolve=>{release=()=>resolve({record:f.records.find(r=>r.object_id===a),history:[],uses:[]})}):original(url,options);
 const pending=c.openProductionRecord(a);await c.openProductionRecord(b);const newest=correct(b,b+'-r1');release();await pending;assert.deepEqual(snap(),newest);results.push({name:'late successful response cannot move exact route, record or either selection marker',passed:true,evidence:newest});
 c.api=async()=>{throw Error('expected offline detail failure')};await assert.rejects(c.openProductionRecord(a),/expected offline detail failure/);assert.deepEqual(snap(),newest);results.push({name:'failed detail read preserves previously displayed exact record and markers',passed:true});
 let releaseWorkspace;c.api=()=>new Promise(resolve=>{releaseWorkspace=resolve});const leaving=c.openProductionRecord(a);c.state.workspace='story.sources';releaseWorkspace({record:f.records.find(r=>r.object_id===a)});await leaving;assert.deepEqual(snap(),newest);results.push({name:'late response after workspace leave does not mutate selection',passed:true});
 assert.equal(f.posts.length,0);assert.equal(f.reads.length,0);return {posts:0,external_fetches:0,real_methods:['loadProductionWorkspace','openProductionRecord','reviewSmallCard','focusProductionReview'],stubs:['technical API records','reader rendering','DOM geometry; classList active state tracked']};
}
async function owners(){
 const h=harness('production_navigation.test.cjs',"test('history type",'globalThis.make=setup;globalThis.rowFactory=row;'),row=h.rowFactory;
 const e=row('owner','ENTITY'),other=row('other','ENTITY'),s=row('state','STATE',{entity:{object_id:'owner'}}),historical={...s,id:'state-old'};
 const records=[e,other,s],c=h.make(records,async url=>{const u=new URL(url,'http://fixture'),id=u.searchParams.get('object_id'),rev=u.searchParams.get('revision_id');const r=rev==='state-old'?historical:records.find(r=>r.object_id===id);assert.ok(r);return {record:r,history:[r],uses:[]}});
 const buttons=['owner','other','state',null].map(id=>tracked({dataset:id?{objectId:id}:{},attrs:{},setAttribute(k,v){this.attrs[k]=v}}));c.document.querySelectorAll=selector=>selector==='#production-index button'?buttons:[];
 await c.openProductionRecord('state','state-old');assert.equal(c.state.productionSelected.id,'state-old');assert.equal(c.state.productionEntityId,'owner');assert.deepEqual(buttons.slice(0,3).map(n=>[n._active,n.attrs['aria-pressed']]),[[true,'true'],[false,'false'],[false,'false']]);assert.equal(buttons[3].attrs['aria-pressed'],undefined);results.push({name:'legacy settings owner navigation selects owning entity, while exact displayed child remains historical state',passed:true,evidence:{selected:c.state.productionSelected.id,owner:c.state.productionEntityId,markers:buttons.slice(0,3).map(n=>[n.dataset.objectId,n.attrs['aria-pressed']])}});
 let called;const saved=buttons.map(n=>JSON.stringify(n.attrs));c.openEntityReview=async(owner,detail,epoch,revision)=>{called={owner,record:detail.record.id,revision}};
 await c.openProductionRecord('state','state-old');assert.deepEqual(called,{owner:'owner',record:'state-old',revision:'state-old'});assert.deepEqual(buttons.map(n=>JSON.stringify(n.attrs)),saved);results.push({name:'unified entity owner early delegation retains original owner/exact revision contract and does not enter generic marker loop',passed:true,evidence:called});
}
(async()=>{const start=performance.now();const fixture=await actualFixture();await owners();const afterHashes=hashes();assert.deepEqual(afterHashes,beforeHashes);const receipt={at_utc:new Date().toISOString(),scope:'Independent offline fixture only; no browser, HTTP, database, product mutation or performance measurement',reviewer:'/root/reset_supervisor',passed:true,checks:results,fixture,dependency_sha256:beforeHashes,dependencies_unchanged:true,elapsed_ms:performance.now()-start};fs.writeFileSync(path.join(out,'AO-UX008-independent-fixture.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify({passed:true,checks:results.length,elapsed_ms:receipt.elapsed_ms,dependencies_unchanged:true},null,2));})().catch(e=>{console.error(e.stack);process.exitCode=1});
