#!/usr/bin/env python3
"""Build the task's portable evidence from explicit local evidence directories."""
import argparse
import gzip
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path

TASK_ID = 'task-20261005-0001'
OMIT_KEYS = {'lease_digest', 'lease_token', 'access_token', 'refresh_token',
             'api_key', 'password', 'authorization'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def redact(value):
    if isinstance(value, dict):
        return {key: ('[REDACTED]' if key.lower() in OMIT_KEYS else redact(item))
                for key, item in value.items()}
    if isinstance(value, list):
        return [redact(item) for item in value]
    return value


def allowed(path):
    return (path.is_file() and not path.is_symlink()
            and not any(part in {'__pycache__', 'node_modules', '.venv', 'venv', '.git'} for part in path.parts)
            and path.suffix not in {'.pyc', '.pyo', '.pstats', '.db', '.sqlite', '.sqlite3'}
            and not any(token in path.name for token in ('.sqlite', '.db-wal', '.db-shm', '.db-journal'))
            and not path.name.startswith('.env')
            and path.name != '.DS_Store')


def sanitize(data, name):
    # Apply to every selected artifact, including old backend guard receipts.
    # Keep all unaffected bytes unchanged for exact raw-evidence verification.
    if data.startswith(b'SQLite format 3\0'):
        raise ValueError('database magic in selected evidence: ' + name)
    try:
        source = data.decode('utf-8')
    except UnicodeDecodeError:
        return data
    if name.endswith('.json'):
        parsed = json.loads(source)
        cleaned = redact(parsed)
        if cleaned != parsed:
            return (json.dumps(cleaned, ensure_ascii=False, indent=2) + '\n').encode()
    elif name.endswith('.jsonl'):
        lines = source.splitlines(keepends=True)
        for index, line in enumerate(lines):
            if not line.strip():
                continue
            parsed = json.loads(line)
            cleaned = redact(parsed)
            if cleaned != parsed:
                lines[index] = json.dumps(cleaned, ensure_ascii=False) + '\n'
        source = ''.join(lines)
    # Some historical console receipts use Python repr instead of JSON.
    keys = '|'.join(re.escape(key) for key in sorted(OMIT_KEYS))
    source = re.sub(r'''(["'](?:''' + keys + r''')["']\s*:\s*)(["'])([^"'\n]+)\2''',
                    lambda match: match[1] + match[2] + '[REDACTED]' + match[2]
                    if match[3] != '[REDACTED]' else match[0], source, flags=re.I)
    return source.encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    root = workspace / '.runtime/autonomous-optimization'
    out = args.output.resolve()
    if not (workspace / 'planning/autonomous-optimization-run-report.md').is_file():
        parser.error('workspace is not the task project')
    if workspace not in out.parents or out.name != TASK_ID:
        parser.error('output must be the named task evidence directory inside workspace')
    out.mkdir(parents=True, exist_ok=True)
    groups = {
        'browser-records': ['browser'],
        'backend-records': ['backend-investigation'],
        'supporting-records': ['reviews', 'history-inventory', 'technical-readiness',
                               'functional-media-observation', 'ui-write-performance'],
    }
    selected = {}
    excluded = []
    for group, directories in groups.items():
        selected[group] = {}
        for directory in directories:
            base = root / directory
            if not base.exists():
                continue
            for path in sorted(base.rglob('*')):
                if not path.is_file():
                    continue
                name = path.relative_to(root).as_posix()
                if not allowed(path):
                    excluded.append(name)
                    continue
                selected[group][name] = path.read_bytes()
    supplemental = selected['supporting-records']
    for name in ('run-baseline.json', 'service-code-hashes.json',
                 'reset-authorization.json', 'recovery-prepare.txt',
                 'recovery-verification.json', 'guard-tests.log',
                 'functional-clone.json', 'resume-execution-diagnostic.json'):
        path = root / name
        if path.is_file():
            supplemental[name] = path.read_bytes()
    for path in sorted((root / 'schema6-roundtrip-reset-01').glob('*')):
        if allowed(path):
            supplemental[path.relative_to(root).as_posix()] = path.read_bytes()
    sanitized_sources = []
    names = ['state.json', 'latest-check.json', 'reset-result.json',
             'startup-recovery.json', 'register-reset-supervisor.json',
             'register-coverage-reviewer.json', 'register-write-performance.json',
             'completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/state.json',
             'completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/stop-receipt.json']
    for name in names:
        path = root / name
        if not path.is_file():
            continue
        raw = path.read_bytes()
        sanitized_name = 'clock/' + name.replace('/', '__')
        data = (json.dumps(redact(json.loads(raw)), ensure_ascii=False, indent=2) + '\n').encode()
        supplemental[sanitized_name] = data
        sanitized_sources.append({'source': name, 'source_sha256': digest(raw),
                                  'artifact': sanitized_name, 'artifact_sha256': digest(data),
                                  'transformation': 'recursive credential-key redaction; not a raw copy'})
    old_report = root / 'completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/run-report.md'
    if old_report.is_file():
        supplemental['clock/original-window-report.md'] = old_report.read_bytes()
    supplemental['tools/build_evidence.py'] = Path(__file__).read_bytes()
    for entries in selected.values():
        for name, raw in list(entries.items()):
            cleaned = sanitize(raw, name)
            if cleaned != raw:
                entries[name] = cleaned
                sanitized_sources.append({'source': name, 'source_sha256': digest(raw),
                                          'artifact': name, 'artifact_sha256': digest(cleaned),
                                          'transformation': 'credential-key redaction across all selected artifacts'})
    manifest = {'task_id': TASK_ID, 'format': 'autonomous-review-evidence-v1',
                'source_base': '.runtime/autonomous-optimization', 'archives': [],
                'files': [], 'sanitized_sources': sanitized_sources,
                'excluded': sorted(excluded),
                'exclusion_rule': 'no SQLite databases/sidecars, symlinks, bytecode, profiler binaries; no full Schema 6 duplicate media trees',
                'clock_limit': 'snapshot of recorded state, not a completion or user-confirmation receipt'}
    # Always replace the same deliverable, preserving raw source files in runtime.
    for group, entries in selected.items():
        archive = out / (group + '.tar.gz')
        temporary = out / (group + '.tar.gz.tmp')
        with temporary.open('wb') as stream:
            with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as zipped:
                with tarfile.open(fileobj=zipped, mode='w|') as tar:
                    for name, data in sorted(entries.items()):
                        info = tarfile.TarInfo(name)
                        info.size, info.mode, info.mtime = len(data), 0o644, 0
                        tar.addfile(info, io.BytesIO(data))
                        manifest['files'].append({'path': name, 'archive': archive.name,
                                                  'bytes': len(data), 'sha256': digest(data)})
                        # Human explanations are available without archive extraction.
                        if name.endswith('.md') or name.startswith('clock/'):
                            readable = out / 'readable' / name
                            readable.parent.mkdir(parents=True, exist_ok=True)
                            readable.write_bytes(data)
        temporary.replace(archive)
        manifest['archives'].append({'path': archive.name, 'bytes': archive.stat().st_size,
                                     'sha256': digest(archive.read_bytes()), 'entries': len(entries)})
    (out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'archives': manifest['archives'], 'files': len(manifest['files']),
                      'excluded': len(excluded)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
