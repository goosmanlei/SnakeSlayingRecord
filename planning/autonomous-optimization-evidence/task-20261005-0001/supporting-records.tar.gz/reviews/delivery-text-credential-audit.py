#!/usr/bin/env python3
"""Read only text/log supplement files; never print or persist credential values."""
import ast,json,re,hashlib,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
SCRIPT=ROOT/'delivery/build_evidence.py';start=time.monotonic();known=[]
for name in ['state.json','completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/state.json']:
 p=ROOT/name
 if p.is_file():
  value=json.loads(p.read_text()).get('lease_digest')
  if isinstance(value,str) and value:known.append(value)
files={}
for group in ['browser','backend-investigation','reviews','history-inventory','technical-readiness','functional-media-observation','ui-write-performance']:
 for p in (ROOT/group).rglob('*'):
  if p.is_file() and not p.is_symlink() and p.suffix.lower() in ('.log','.txt','.md','.jsonl') and '__pycache__' not in p.parts:files[p.relative_to(ROOT).as_posix()]=p
for name in ['recovery-prepare.txt','guard-tests.log','completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/run-report.md']:
 p=ROOT/name
 if p.is_file():files[name]=p
for p in (ROOT/'schema6-roundtrip-reset-01').glob('*'):
 if p.is_file() and not p.is_symlink() and p.suffix.lower() in ('.log','.txt','.md','.jsonl'):files[p.relative_to(ROOT).as_posix()]=p
pattern=re.compile(r'''["']?(lease_digest|lease_token|access_token|refresh_token|api_key|password|authorization)["']?\s*[:=]\s*["']([^"'\r\n]{4,})["']''',re.I)
hits=[];known_matches=[];line_json_fields=[];bytes_read=0;hashes={};bad_jsonl=[];lines_total=0
keys={'lease_digest','lease_token','access_token','refresh_token','api_key','password','authorization','client_secret','api_secret','secret_access_key','private_key'}
def scan(v,file,line,path):
 if isinstance(v,dict):
  for k,x in v.items():
   if k.lower() in keys and x not in (None,'','[REDACTED]','REDACTED',False):line_json_fields.append({'file':file,'line':line,'field_path':path+[k],'value_type':type(x).__name__,'length':len(x) if isinstance(x,(str,list,dict)) else None,'matches_known_digest':isinstance(x,str) and x in known})
   scan(x,file,line,path+[k])
 elif isinstance(v,list):
  for i,x in enumerate(v):scan(x,file,line,path+[str(i)])
for name,p in sorted(files.items()):
 data=p.read_bytes();bytes_read+=len(data);hashes[name]=hashlib.sha256(data).hexdigest();text=data.decode('utf8',errors='replace')
 if any(x in text for x in known):known_matches.append(name)
 for lineno,line in enumerate(text.splitlines(),1):
  lines_total+=1
  for m in pattern.finditer(line):
   field,value=m.groups()
   if value in ('[REDACTED]','REDACTED'):continue
   hits.append({'file':name,'line':lineno,'field':field,'value_length':len(value),'matches_known_digest':value in known,'is_64_hex':bool(re.fullmatch('[a-f0-9]{64}',value,re.I))})
  if p.suffix.lower()=='.jsonl' and line.strip():
   try:scan(json.loads(line),name,lineno,[])
   except json.JSONDecodeError:bad_jsonl.append({'file':name,'line':lineno})
result={'at_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'scope':'text/log/md/jsonl selected trees and explicit text supplements; no databases','script_under_review_sha256':hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),'files':len(files),'bytes_read':bytes_read,'text_lines':lines_total,'current_or_original_guard_digest_match_files':known_matches,'credential_like_text_assignments_no_values':hits,'jsonl_credential_fields_no_values':line_json_fields,'malformed_jsonl_lines':bad_jsonl,'file_sha256':hashes,'elapsed_seconds':time.monotonic()-start,'limitations':['Text pattern requires quoted values and is not a complete arbitrary-language secret recognizer. Known exact guard digests independently checked across whole file text.','These paths are current snapshot only; new future logs must be checked by builder/final audit.']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='file_sha256'},ensure_ascii=False,indent=2))
