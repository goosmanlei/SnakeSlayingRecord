"""Independent, bounded comment-cache checks in disposable fixtures only."""
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

sys.dont_write_bytecode=True
base=Path(__file__).resolve().parents[1]
system=base/'system-worktree'
sys.path[:0]=[str(system),str(system/'tests')]
os.environ['NO_PROXY']='127.0.0.1,localhost'
os.environ['no_proxy']='127.0.0.1,localhost'
from review_desk.store import Store, Conflict, canonical, digest
from review_desk.polish import build_context
from test_comment_source_reuse import document, source_row

class IndependentSourceBoundaries(unittest.TestCase):
    def setUp(self):
        temporary=tempfile.TemporaryDirectory();self.addCleanup(temporary.cleanup)
        self.root=Path(temporary.name)
        self.store=Store(self.root/'.runtime/review.sqlite3');self.addCleanup(self.store.close)
        self.document=document();self.source_hash=self.store.put_source(self.document)

    def test_changed_document_with_stale_digest_column_blocks_batch_write_and_polish(self):
        row=source_row(self.store)
        self.assertTrue(self.store.comment_anchor_states([row])[0]['anchor_state']['valid'])
        changed={**self.document,'notes':'deliberately changed disposable document'}
        with self.store.db:
            self.store.db.execute('UPDATE sources SET document=? WHERE id=?',(canonical(changed),'source'))
        self.assertEqual(self.store.db.execute('SELECT revision FROM sources WHERE id=?',('source',)).fetchone()[0],self.source_hash)
        with patch.object(self.store,'source',wraps=self.store.source) as fetch:
            results=self.store.comment_anchor_states([row,row])
            self.assertEqual(fetch.call_count,1)
        self.assertTrue(all(not item['anchor_state']['valid'] and 'source revision differs' in item['anchor_state']['reason'] for item in results))
        with self.assertRaisesRegex(Conflict,'source revision differs'):self.store.create_comment(row)
        with self.assertRaisesRegex(Conflict,'source revision differs'):
            build_context(self.store,'source',row['anchor'],'核对原文',target_revision_id=row['target_revision_id'])
        self.assertEqual(self.store.comments(),[])
        with self.store.db:self.store.db.execute('UPDATE sources SET document=? WHERE id=?',(canonical(self.document),'source'))
        self.assertTrue(self.store.comment_anchor_states([row])[0]['anchor_state']['valid'])
        self.assertEqual(self.store.create_comment(row)['target_revision_id'],row['target_revision_id'])

    def test_wrong_hash_revision_first_cannot_poison_same_source_valid_revision(self):
        row=source_row(self.store,quote='甲乙𪎊')
        payload={'source_revision':'0'*64}
        revision=digest(canonical({'object_id':'source','version':2,'payload':payload}).encode())
        with self.store.db:
            self.store.db.execute('INSERT INTO revisions VALUES (?,?,?,?,?)',(revision,'source',2,canonical(payload),'2026-10-05T00:00:00Z'))
        bad={**row,'target_revision_id':revision}
        bounds={**row,'anchor':{**row['anchor'],'start':True}}
        rows=[bad,row,bounds,row]
        with patch.object(self.store,'source',wraps=self.store.source) as fetch:
            result=self.store.comment_anchor_states(rows)
            self.assertEqual(fetch.call_count,1)
        self.assertEqual([item['anchor_state']['valid'] for item in result],[False,True,False,True])
        self.assertIn('source revision differs',result[0]['anchor_state']['reason'])
        for given,observed in zip(rows,result):
            self.assertEqual(observed['anchor_state'],self.store.anchor_state(given['target_object_id'],given['target_revision_id'],given['anchor']))

    def test_missing_and_malformed_source_do_not_survive_repair_in_next_batch(self):
        row=source_row(self.store)
        with self.store.db:self.store.db.execute('DELETE FROM sources WHERE id=?',('source',))
        self.assertFalse(self.store.comment_anchor_states([row])[0]['anchor_state']['valid'])
        with self.store.db:self.store.db.execute('INSERT INTO sources VALUES (?,?,?)',('source',canonical(self.document),self.source_hash))
        self.assertTrue(self.store.comment_anchor_states([row])[0]['anchor_state']['valid'])
        with self.store.db:self.store.db.execute('UPDATE sources SET document=? WHERE id=?',('{broken','source'))
        self.assertTrue(all(not result['anchor_state']['valid'] for result in self.store.comment_anchor_states([row,row])))
        with self.store.db:self.store.db.execute('UPDATE sources SET document=? WHERE id=?',(canonical(self.document),'source'))
        self.assertTrue(self.store.comment_anchor_states([row])[0]['anchor_state']['valid'])

    def test_source_region_rechecks_file_after_cached_document_and_recovers_next_batch(self):
        doc=document('visual')
        doc['assets']=[{'file':'proof.svg','title':'Independent fixture','source_url':'https://example.org/proof'}]
        self.store.put_source(doc)
        asset=self.root/'export/assets/proof.svg';asset.parent.mkdir(parents=True);asset.write_text('<svg/>')
        row=source_row(self.store,'visual')
        row['anchor']={'type':'region','visual_id':'proof.svg','asset_file':'proof.svg',
            'points':[{'x':0,'y':0},{'x':1,'y':0},{'x':0,'y':1}]}
        def changing_files():
            yield row
            asset.unlink()
            yield row
        with patch.object(self.store,'source',wraps=self.store.source) as fetch:
            result=self.store.comment_anchor_states(changing_files())
            self.assertEqual(fetch.call_count,1)
        self.assertEqual([item['anchor_state']['valid'] for item in result],[True,False])
        self.assertIn('referenced visual asset is missing',result[1]['anchor_state']['reason'])
        asset.write_text('<svg/>')
        self.assertTrue(self.store.comment_anchor_states([row])[0]['anchor_state']['valid'])

selected=[
    'test_comment_source_reuse',
    'test_review.ReviewTest.test_anchor_comment_lifecycle',
    'test_review.ReviewTest.test_export_restore_and_integrity',
    'test_review.ReviewTest.test_configuration_and_ai_context',
    'test_review.ReviewTest.test_legacy_comment_migration',
    'test_structure.StructureTest.test_source_image_and_explicit_broken_reference',
    'test_material_relationships.MaterialRelationshipsTest.test_relationship_revision_preserves_the_original_comment_and_evidence_after_restore',
]
inputs=['review_desk/store.py','review_desk/server.py','tests/test_comment_source_reuse.py',
        'tests/test_review.py','tests/test_structure.py','tests/test_material_relationships.py']
def fingerprints():return {name:hashlib.sha256((system/name).read_bytes()).hexdigest() for name in inputs}
report={'format':'AO-PERF-003-independent-tests-v1','reviewer':'01a10a85-fd7a-7021-aa28-a867f6dea1d8',
        'started_utc':datetime.now(timezone.utc).isoformat(),'before':fingerprints(),'selected_existing':selected,
        'independent_tests':unittest.defaultTestLoader.getTestCaseNames(IndependentSourceBoundaries),
        'data_scope':'new TemporaryDirectory fixtures only; no preview, frozen or formal database',
        'paid_or_external_calls':False}
started=time.monotonic()
def alarm(*_):raise TimeoutError('30 second independent test budget')
signal.signal(signal.SIGALRM,alarm);signal.alarm(30)
try:
    loader=unittest.defaultTestLoader
    suite=unittest.TestSuite([loader.loadTestsFromNames(selected),loader.loadTestsFromTestCase(IndependentSourceBoundaries)])
    with (base/'reviews/AO-PERF-003-independent-tests.log').open('w') as output:
        result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)
    report.update(tests_run=result.testsRun,failures=len(result.failures),errors=len(result.errors),skipped=len(result.skipped),passed=result.wasSuccessful())
except BaseException as error:
    report.update(passed=False,error=type(error).__name__+': '+str(error));raise
finally:
    signal.alarm(0)
    report['after']=fingerprints();report['inputs_unchanged']=report['after']==report['before']
    report['elapsed_seconds']=time.monotonic()-started
    report['finished_utc']=datetime.now(timezone.utc).isoformat()
    (base/'reviews/AO-PERF-003-independent-tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({key:report.get(key) for key in ['passed','tests_run','failures','errors','elapsed_seconds','inputs_unchanged']},ensure_ascii=False))
if not report['passed'] or not report['inputs_unchanged']:raise SystemExit(1)
