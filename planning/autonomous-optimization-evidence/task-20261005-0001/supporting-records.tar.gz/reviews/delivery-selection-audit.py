#!/usr/bin/env python3
"""Read-only selection inventory and credential-key check; prints no secret values."""
from pathlib import Path
import ast,json,hashlib,collections,time
ROOT=Path(__file__).resolve().parent.parent
SCRIPT=ROOT/'delivery/build_evidence.py'
start=time.monotonic()
# Parse and execute only the pure predicate/redactor definitions, never main.
mod=ast.parse(SCRIPT.read_text());chosen=[n for n in mod.body if isinstance(n,(ast.FunctionDef,ast.Import,ast.ImportFrom)) and (not isinstance(n,ast.FunctionDef) or n.name in ('allowed','redact','digest')) or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='OMIT_KEYS' for t in n.targets)]
ns={};exec(compile(ast.Module(body=chosen,type_ignores=[]),str(SCRIPT),'exec'),ns)
allowed=ns['allowed'];entries={};excluded=[]
for group in ['browser','backend-investigation','reviews','history-inventory','technical-readiness','functional-media-observation','ui-write-performance']:
 for p in sorted((ROOT/group).rglob('*')):
  if not p.is_file():continue
  if allowed(p):entries[p.relative_to(ROOT).as_posix()]=p
  else:excluded.append(p.relative_to(ROOT).as_posix())
for name in ['run-baseline.json','service-code-hashes.json','reset-authorization.json','recovery-prepare.txt','recovery-verification.json','guard-tests.log','functional-clone.json','resume-execution-diagnostic.json']:
 p=ROOT/name
 if p.is_file():entries[name]=p
for p in (ROOT/'schema6-roundtrip-reset-01').glob('*'):
 if allowed(p):entries[p.relative_to(ROOT).as_posix()]=p
old=ROOT/'completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/run-report.md'
if old.is_file():entries['clock/original-window-report.md']=old
# Read only named guard digest fields to identify accidental copies; do not persist their values.
known=[]
for name in ['state.json','completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/state.json']:
 p=ROOT/name
 if p.is_file():
  d=json.loads(p.read_text());v=d.get('lease_digest')
  if isinstance(v,str) and v:known.append(v.encode())
keys={'lease_digest','lease_token','access_token','refresh_token','api_key','password','authorization','client_secret','api_secret','secret_access_key','private_key'}
credential_fields=[];known_guard_copies=[];databases=[];unknown_binaries=[];links=[];counts=collections.Counter();bytes_total=0;json_fail=[]
def scan(v,path,file):
 if isinstance(v,dict):
  for k,x in v.items():
   if k.lower() in keys and x not in (None,'','[REDACTED]','REDACTED',False):credential_fields.append({'file':file,'key_path':path+[k],'type':type(x).__name__,'length':len(x) if isinstance(x,(str,list,dict)) else None})
   scan(x,path+[k],file)
 elif isinstance(v,list):
  for i,x in enumerate(v):scan(x,path+[str(i)],file)
for name,p in entries.items():
 data=p.read_bytes();bytes_total+=len(data);counts[p.suffix.lower()]+=1
 if data.startswith(b'SQLite format 3\x00'):databases.append(name)
 if any(v in data for v in known):known_guard_copies.append(name)
 if p.suffix.lower()=='.json':
  try:scan(json.loads(data),[],name)
  except (json.JSONDecodeError,UnicodeDecodeError) as e:json_fail.append({'file':name,'error_type':type(e).__name__})
 if p.is_symlink():links.append(name)
 if p.suffix.lower() in ('.db','.env','.pem','.key','.p12','.pfx','.zip','.gz','.tar'):unknown_binaries.append(name)
result={'script_sha256':hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),'scope':'inventory and read-only current raw selection scan, no build or writes outside own reviews','selected_raw_files':len(entries),'selected_raw_bytes':bytes_total,'suffix_counts':dict(counts),'sqlite_magic_matches':databases,'credential_fields_without_values':credential_fields,'known_guard_digest_copies_without_values':known_guard_copies,'selected_symlinks':links,'high_attention_suffixes':unknown_binaries,'excluded':excluded,'json_parse_failures':json_fail,'limitation':'Named JSON fields and actual current/previous top-level lease digest only; not a general secret detector for arbitrary text, images, nested digest variants or future logs. Selection is live and new files may appear after this inventory.','elapsed_seconds':time.monotonic()-start}
p=Path(__file__).with_suffix('.json');p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('excluded',)},ensure_ascii=False,indent=2))
