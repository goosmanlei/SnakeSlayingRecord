"""Read-only final-code compatibility audit for the latest merged song data."""
import hashlib
import json
import signal
import sqlite3
import subprocess
import sys
import time
import wave
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / '.runtime/autonomous-optimization'
SYSTEM = BASE / 'system-worktree'
DB = BASE / 'final-preview/.runtime/generation-base.sqlite3'
OUT = BASE / 'reviews/final-coverage-song-audit.json'
sys.path[:0] = [str(SYSTEM), str(ROOT / 'scripts')]
from review_desk.store import Store, canonical
from review_desk import material_storage, production
from generation_publication import KEYS
from material_model_io import read_json


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            result.update(chunk)
    return result.hexdigest()


def readonly(path):
    connection = sqlite3.connect(path.resolve().as_uri() + '?mode=ro&immutable=1', uri=True)
    connection.execute('PRAGMA query_only=ON')
    connection.row_factory = sqlite3.Row
    return connection


def deadline(*_):
    raise TimeoutError('120 second bounded audit limit')


signal.signal(signal.SIGALRM, deadline)
signal.alarm(120)
started = time.time()
result = {'format': 'final-coverage-song-audit-v1', 'reviewer_thread': '01a10bdc-4dd1-70e2-ac7c-5f864eb6f38f',
          'started_epoch': started, 'formal_database_accessed': False, 'browser_actions': 0,
          'source_database': str(DB.relative_to(ROOT)), 'checks': []}


def check(name, condition, **details):
    result['checks'].append({'name': name, 'passed': bool(condition), **details})
    if not condition:
        raise AssertionError(name)


raw = readonly(DB)
store = Store.__new__(Store)
store.db_path = DB
store.db = readonly(DB)
store.db.row_factory = material_storage.row_factory(store)
try:
    result['database_sha256_before'] = sha(DB)
    result['system_commit'] = subprocess.check_output(['git', '-C', str(SYSTEM), 'rev-parse', 'HEAD'], text=True).strip()
    result['story_commit'] = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip()
    check('exact final system', result['system_commit'] == '204c4696f0ecd4595b395a14520eacf0c54ef2bf')
    check('exact latest formal clone', result['database_sha256_before'] == '56c2ba0af3666e09bd29186e66f19e1315d5061e0457c113502f9e2a5b94c3c5')
    plan = read_json(ROOT / 'production/publications/songs-current-model-v2.json')
    result['publication_sha256'] = sha(ROOT / 'production/publications/songs-current-model-v2.json')
    matched = {}
    for table, changes in plan['changes'].items():
        count = 0
        for change in changes:
            expected = change['after']
            actual = raw.execute('SELECT * FROM ' + table + ' WHERE ' + ' AND '.join(k + '=?' for k in KEYS[table]),
                                 tuple(expected[k] for k in KEYS[table])).fetchone()
            check('latest publication exact row', actual is not None and dict(actual) == expected,
                  table=table, key=[expected[k] for k in KEYS[table]])
            count += 1
        matched[table] = count
    result['publication_rows_matched'] = matched
    for event in plan['comment_events']:
        actual = raw.execute('SELECT * FROM comment_events WHERE id=?', (event['id'],)).fetchone()
        check('exact song comment event', actual is not None and dict(actual) == event, event_id=event['id'])

    previous = readonly(BASE / 'preview/.runtime/generation-base.sqlite3')
    try:
        result['previous_history_preserved'] = {}
        for table in ('comments', 'comment_events'):
            rows = [dict(row) for row in previous.execute('SELECT * FROM ' + table)]
            current = {row['id']: dict(row) for row in raw.execute('SELECT * FROM ' + table)}
            check('pre-song history retained', all(current.get(row['id']) == row for row in rows), table=table, count=len(rows))
            result['previous_history_preserved'][table] = len(rows)
    finally:
        previous.close()

    observed = json.loads((ROOT / 'production/song-publication/browser-verification.json').read_text())
    songs = {}
    with production.read_scope(store):
        for entry in observed['versions']:
            params = parse_qs(urlsplit(entry['url']).query)
            mid = params['material_id'][0]
            if mid not in songs:
                detail = production.snapshot(store, object_id=mid)
                songs[mid] = detail['material_versions'][mid]
            versions = songs[mid]
            version = next(v for v in versions if v['number'] == entry['version'])
            expected_revision = params['production_revision'][0]
            chosen = next(r for r in version['results'] if r['id'] == expected_revision)
            originals = [c for c in chosen['payload']['components'] if c['role'] == 'original']
            check('accurate song recording selection', version['state'] == 'produced' and len(originals) == 1,
                  song=entry['song'], material_version=entry['version'], revision=expected_revision)
            component = originals[0]
            check('accurate song original preserved', sha(ROOT / 'export/assets' / component['file']) == component['sha256'],
                  song=entry['song'], material_version=entry['version'], file=component['file'], duration_seconds=component.get('duration_seconds'))
        latest = {}
        for mid, versions in songs.items():
            current = max(versions, key=lambda v: v['number'])
            latest[mid] = current['number']
            check('latest ungenerated plan does not reuse old recording', current['state'] == 'preparing' and current['results'] == [],
                  material_id=mid, material_version=current['number'])
        result['song_count'] = len(songs)
        result['recorded_versions_checked'] = len(observed['versions'])
        result['current_ungenerated_versions'] = latest
        comments = store.comments()
        expected = [{**c, 'anchor_state': store.anchor_state(c['target_object_id'], c['target_revision_id'], c['anchor'])} for c in comments]
        actual = store.comment_anchor_states(comments)
        check('new cached comment endpoint equals uncached exact validation', actual == expected, count=len(comments))
        result['comment_anchor_states'] = {'total': len(actual), 'valid': sum(bool(c['anchor_state']['valid']) for c in actual)}
        legacy = read_json(ROOT / 'production/song-stage/publication-plan.json')
        originals = {r['id']: r for r in legacy['insert']['revisions']}
        result['historical_pcm_cases'] = []
        for item in plan['origin']['historical_pcm_precision_checks']:
            payload = store.db.execute('SELECT payload FROM revisions WHERE id=?', (item['revision_id'],)).fetchone()['payload']
            check('PCM exception leaves exact historical payload unchanged', payload == originals[item['revision_id']]['payload'], revision=item['revision_id'])
            file = ROOT / 'export/assets' / item['file']
            with wave.open(str(file)) as recording:
                duration = recording.getnframes() / recording.getframerate()
            check('PCM exception is exact documented rounding case', sha(file) == file.stem and duration == item['pcm_duration'] == item['range_end'] and 0 < duration - item['recorded_duration'] < 0.0000005,
                  revision=item['revision_id'])
            result['historical_pcm_cases'].append({**item, 'difference_seconds': duration - item['recorded_duration']})
    result['counts'] = {t: raw.execute('SELECT count(*) FROM ' + t).fetchone()[0] for t in ('objects','revisions','comments','comment_events')}
    result['passed'] = True
except BaseException as error:
    result['passed'] = False
    result['error'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    raw.close()
    store.db.close()
    result['database_sha256_after'] = sha(DB)
    result['database_unchanged'] = result['database_sha256_before'] == result['database_sha256_after']
    result['finished_epoch'] = time.time()
    result['elapsed_seconds'] = time.time() - started
    result['script_sha256'] = sha(__file__)
    result['system_file_sha256'] = {str(p.relative_to(SYSTEM)):sha(p) for p in [SYSTEM/'review_desk/material_storage.py',SYSTEM/'review_desk/store.py',SYSTEM/'review_desk/ui_projection.py',SYSTEM/'review_desk/material_plans.py']}
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k:result.get(k) for k in ('passed','error','counts','song_count','recorded_versions_checked','comment_anchor_states','database_unchanged','elapsed_seconds')},ensure_ascii=False))
