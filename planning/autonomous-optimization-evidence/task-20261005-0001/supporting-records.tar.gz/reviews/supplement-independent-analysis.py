"""Offline audit of frozen supplement evidence. No services, browsers, or databases."""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
from urllib.parse import urlparse, parse_qs
import hashlib
import json
import statistics

ROOT = Path(__file__).resolve().parents[1]
BROWSER = ROOT / 'browser/supplement-reset-01'
BACKEND = ROOT / 'backend-investigation/supplement-final'
OUT = Path(__file__).with_name('supplement-independent.json')
PHASES = ['A3', 'B3', 'A4', 'B4']
DIRECTIONS = ['P2-record2', 'P2-record1', 'M1-zoom', 'M1-close', 'M2-play', 'M2-pause', 'R1-dom-upper', 'R1-dom-close', 'L1-panel', 'L1-locate']
COMMITS = {'A': 'b874b959af9c918a482e8488dc25cb0204ab5772', 'B': '204c4696f0ecd4595b395a14520eacf0c54ef2bf'}
DB = '5c6d00ee6efa7506201bbef46ffd69bde49f7300c4697fe66036e87ace7ed4f0'
PROBE = '74a80b7f730a450f4fc00f5424120f8f60406e7fe9c4c65234e3d317958a804c'
IMG = '717c7bca7ecabeb45318ad1669d61ed0e440fdfc8567ad80c4b123cfc9de032a.png'
WAV = 'a7d678681c2e490de0a7dc8aca163131f68e196ceda703dc9c9282418c589272.wav'
QUOTE = '李诞转头看向女儿，又望了一眼刀。后院这八个大人，已经一个也腾不出手。'
REVISIONS = {'P2-record2': ('preparation-s002','cab284f511de11dd442b3c04391a5aaaa4201649115570e1ac368aa7571fe0c4','01-02 河街上的邀请'), 'P2-record1': ('preparation-s001','dd7e073959fd188f3aecb2620fab4b967b8a4ba3f5b88fbdeaeb5c736e1b4e72','01-01 米铺门口')}
checks, rows, raw, hashes = [], [], {}, {}

def load(p):
    b = p.read_bytes()
    hashes[str(p.relative_to(ROOT))] = hashlib.sha256(b).hexdigest()
    return json.loads(b)

def ck(scope, name, value):
    checks.append({'scope': scope, 'check': name, 'pass': bool(value)})

def query(url):
    return {k:v[0] for k,v in parse_qs(urlparse(url).query).items()}

def pct(a, p):
    s=sorted(a); x=(len(s)-1)*p; lo=int(x); hi=min(lo+1,len(s)-1)
    return s[lo]+(s[hi]-s[lo])*(x-lo)

def stats(a):
    med=statistics.median(a); q1=pct(a,.25); q3=pct(a,.75)
    return {'values_ms':a,'n':len(a),'min':min(a),'median':med,'max':max(a),'q1':q1,'q3':q3,'iqr':q3-q1,'mad':statistics.median(abs(x-med) for x in a)}

stages={}
baseline=load(ROOT/'run-baseline.json')
ck('frozen_database','recorded_object_count_same_snapshot',baseline['snapshot_sha256']==DB and baseline['snapshot_bytes']==163000320 and baseline['counts']['objects']==6236)
for phase in PHASES:
    p=BACKEND/phase
    before=load(p/'identity-before.json'); after=load(p/'identity-after.json'); receipt=load(p/'receipt.json'); env=load(p/'environment.json'); process=load(p/'process.json')
    ck(phase,'identity_before_after_exact',before==after)
    ck(phase,'identity_matches_frozen_input',before['database_sha256']==DB and before['probe_sha256']==PROBE and before['system_commit']==COMMITS[phase[0]] and before['product_dirty']=='')
    ck(phase,'receipt_identity_pid_and_clean_stop',receipt['identity_unchanged'] is True and receipt['stop_signal']==15 and receipt['error'] is None and receipt['pid']==process['pid'])
    ck(phase,'environment_commit_and_probe',env['system_commit']==before['system_commit'] and env['probe_sha256']==PROBE and env['label']=='page-supplement-'+phase)
    phttp=p/'http.jsonl'; b=phttp.read_bytes(); hashes[str(phttp.relative_to(ROOT))]=hashlib.sha256(b).hexdigest(); http=[json.loads(x) for x in b.splitlines()]
    errors=[x for x in http if x['status']>=400 or x.get('error_type')]
    stages[phase]={'identity':before,'receipt':receipt,'environment':env,'http_count':len(http),'http_statuses':dict(Counter(x['status'] for x in http)),'http_errors':errors,'wav_requests':[x for x in http if x['path'].endswith(WAV)]}
    for direction in DIRECTIONS:
        for index in range(4):
            name=f'{direction}-{phase}-{index}.json'; d=load(BROWSER/name); raw[phase,direction,index]=d
            obs=d['observed']; pr=d.get('probe',obs.get('probe')); s=pr['samples'][-1]; meta=pr['metadata']; browser=pr['browser']; url=obs.get('url',pr['url']); q=query(url)
            ck(name,'record_phase_index',d['phase']==phase and d['index']==index)
            ck(name,'metadata_commit_probe_environment',meta['system_commit']==COMMITS[phase[0]] and meta['probe_sha256']==PROBE and meta['label']=='page-supplement-'+phase and meta['started_at_utc']==env['started_at_utc'])
            ck(name,'browser_viewport_dpr_foreground',browser['viewport']=={'width':1440,'height':900} and browser['device_pixel_ratio']==1 and browser['visibility']=='visible' and 'Chrome/154.' in browser['user_agent'])
            ck(name,'raw_checks_no_failure',all(d['checks'].values()))
            start=d['tool_start_epoch_ms']; end=d['tool_end_epoch_ms']; service_start=datetime.fromisoformat(receipt['started_at_utc'].replace('Z','+00:00')).timestamp()*1000; service_end=datetime.fromisoformat(receipt['finished_at_utc'].replace('Z','+00:00')).timestamp()*1000
            ck(name,'action_inside_service_lifetime',service_start<=start<=end<=service_end+1000)
            row={'file':name,'phase':phase,'direction':direction,'index':index,'formal':index>0,'tool_start_epoch_ms':start,'tool_end_epoch_ms':end,'observation_upper_ms':end-start,'url':url,'query':q}
            if direction=='R1-dom-upper':
                ck(name,'real_keyboard_sampler_protocol',"press('Enter')" in (BROWSER/'clean-action-functions.js').read_text())
                ck(name,'correct_entity_state_and_usable_close','孙六' in obs['headings'] and '孙六·基准完整形态' in obs['dialog'] and obs['closeEnabled'] is True and 'button "关闭"' in d['snapshot'])
                row.update(metric='tool_wall_clock_upper_bound',value_ms=end-start,headings=obs['headings'],close_enabled=obs['closeEnabled'],stale_probe_last_type=s['type'],stale_probe_last_id=s['id'])
            else:
                sem=s['semantic_at_ready']; sq=query(s['end_url'])
                ck(name,'one_new_click',len(pr['samples'])==d['before']['count']+1 and s['type']=='click')
                ck(name,'stable_pending_errors_visible',s['completion_reason']=='stable' and not any(s['pending_at_end'].values()) and s['request_error_count']==0 and not s['failed_requests'] and s['visibility_at_start']==s['visibility_at_end']=='visible' and d['actionError'] is None)
                ck(name,'timing_recomputed',abs(s['scenario_ready_ms']-(sem['capture_finished_ms']-s['start_ms']))<1e-6)
                ck(name,'exact_recorded_route',all(sq.get(k)==v for k,v in d['expected'].get('params',{}).items()))
                row.update(metric='probe_semantic_ready',value_ms=s['scenario_ready_ms'],sample_id=s['id'],time_origin=browser['time_origin'],target=s['target'],before_url=d['before']['url'],semantic_headings=[x['label'] for x in sem['headings']])
                if direction in REVISIONS:
                    obj,rev,title=REVISIONS[direction]
                    ck(name,'exact_object_revision_title',sq.get('production_object')==q.get('production_object')==obj and sq.get('production_revision')==q.get('production_revision')==rev and title in row['semantic_headings'])
                    ck(name,'current_version_5_selected','option "版本 5 · 当前" [selected]' in d['snapshot'])
                    pressed=[x['id'] for x in obs['pressed']]; row['pressed_ids']=pressed;row['pressed_correct']=pressed==[obj]
                    if phase.startswith('B'): ck(name,'candidate_pressed_matches_body',row['pressed_correct'])
                elif direction in ['M1-zoom','M1-close']:
                    ck(name,'exact_image_revision',q.get('production_revision')=='d71d936487d92793f28f793c7d6e0eca5051138762a7ee99ebb976959f793561' and q.get('production_object')=='asset-fg3-a-he-base-image-01')
                    ims=[x for x in obs['images'] if x['src'] in [f'http://127.0.0.1:62606/api/production/files/{IMG}', f'http://127.0.0.1:62606/assets/{IMG}']]
                    ck(name,'exact_image_complete_natural_size',bool(ims) and all(x['complete'] and x['width']==1086 and x['height']==1448 for x in ims))
                    if direction=='M1-zoom':ck(name,'zoom_dialog_large_image',len(obs['dialogs'])==1 and '阿禾·基准完整形态 · 内置渠道首轮基准' in obs['dialogs'][0]['text'] and any(x['src']==f'http://127.0.0.1:62606/assets/{IMG}' and x['rect']['width']>1000 and x['rect']['height']>700 for x in ims))
                    else:ck(name,'zoom_closed',obs['dialogs']==[])
                    row['matching_images']=ims
                elif direction in ['M2-play','M2-pause']:
                    ck(name,'exact_audio_revision',q.get('production_revision')=='e522f05e989232e8323608cc74addd94b5e542c15c2d69692109c5fdd3e78ecb' and q.get('production_object')=='asset-fg3-aheng-voice-01')
                    media=obs['media'];ck(name,'one_exact_ready_audio',len(media)==1 and media[0]['src']==f'http://127.0.0.1:62606/api/production/files/{WAV}' and media[0]['readyState']==4 and media[0]['duration']==14.5 and not media[0].get('error'))
                    m=media[0]; ck(name,'play_pause_state_progress',m['paused']==(direction=='M2-pause') and m['currentTime']>0)
                    row['media']=m;row['current_action_media_events']=[x for x in pr['media'] if x['action_id']==s['id']]
                    if direction=='M2-play':ck(name,'playing_event_for_exact_file',any(x['type']=='playing' and x['current_src']==m['src'] and x['ready_state']==4 for x in row['current_action_media_events']))
                elif direction=='R1-dom-close':ck(name,'entity_dialog_closed',obs['dialogs']==[])
                elif direction=='L1-panel':
                    ck(name,'comment_panel_correct_source',q.get('source')=='refinement-08-lantern-home-v8' and any(x['id']=='comment-panel' and QUOTE in x['first']+x['last'] for x in sem['regions']))
                elif direction=='L1-locate':
                    g=load(BROWSER/f'L1-geometry-{phase}-{index}.json'); panel=g['panel'];source=g['source'];marks=g['marks'];rects=[r for m in marks for r in m['rects']]
                    ck(name,'correct_quote_open_panel',len(marks)==1 and marks[0]['text']==QUOTE and g['panelHidden'] is False and q.get('source')=='refinement-08-lantern-home-v8')
                    overlap=[max(0,min(r['right'],panel['right'])-max(r['left'],panel['left'])) if min(r['bottom'],panel['bottom'])>max(r['top'],panel['top']) else 0 for r in rects]
                    contained=all(r['left']>=source['left'] and r['right']<=source['right'] and r['top']>=source['top'] and r['bottom']<=source['bottom'] and 0<=r['left']<=r['right']<=1440 and 0<=r['top']<=r['bottom']<=900 for r in rects)
                    if phase.startswith('B'):ck(name,'candidate_quote_all_rects_visible',contained and not any(overlap) and all(r['hit'] for r in rects))
                    scrolls=[x for x in pr['scrolls'] if x['target'].get('id')=='source-view']; preceding=[x for x in scrolls if x['action_id']!=s['id']]; current=[x for x in scrolls if x['action_id']==s['id']]
                    row['geometry']={'source':source,'panel':panel,'quote':marks[0]['text'],'rects':rects,'panel_overlap_widths':overlap,'fully_visible':contained and not any(overlap),'source_scroll':g['sourceScroll'],'source_scroll_events':scrolls,'recorded_start_scroll':preceding[-1]['scroll_top'] if preceding else None,'recorded_end_scroll':g['sourceScroll'],'action_scrollend_elapsed_ms':[x['elapsed_since_action_ms'] for x in current]}
            rows.append(row)

for phase in PHASES:
    for i in range(4):
        play=raw[phase,'M2-play',i]['observed']['media'][0];pause=raw[phase,'M2-pause',i]['observed']['media'][0]
        ck(f'{phase}-M2-{i}','play_time_advances_until_pause',pause['currentTime']>play['currentTime'])
        for op,cl in [('M1-zoom','M1-close'),('R1-dom-upper','R1-dom-close'),('L1-panel','L1-locate'),('P2-record2','P2-record1')]:
            ck(f'{phase}-{op}-{i}','paired_action_order',raw[phase,op,i]['tool_end_epoch_ms']<=raw[phase,cl,i]['tool_start_epoch_ms'])

ck('coverage','160_exact_actions',len(rows)==160 and len({(r['phase'],r['direction'],r['index']) for r in rows})==160)
clicks=[r for r in rows if r['metric']=='probe_semantic_ready']
ck('coverage','144_distinct_click_events',len({(r['phase'],r['time_origin'],r['sample_id']) for r in clicks})==144)
stats_by={d:{p:stats([r['value_ms'] for r in rows if r['direction']==d and r['phase']==p and r['formal']]) for p in PHASES} for d in DIRECTIONS}
comparisons={}
for d in DIRECTIONS:
    pairs=[]
    for ap,bp in [('A3','B3'),('A4','B4')]:
        a,b=stats_by[d][ap],stats_by[d][bp];delta=a['median']-b['median']; threshold=max(a['iqr'],b['iqr'],3*a['mad'],3*b['mad']); separated=a['q1']>b['q3'] or b['q1']>a['q3']
        pairs.append({'pair':[ap,bp],'median_reduction_ms':delta,'median_reduction_fraction':delta/a['median'],'threshold_ms':threshold,'iqr_nonoverlap':separated,'numeric_signal':'faster' if delta>threshold and separated else 'slower' if -delta>threshold and separated else 'not_beyond_rule'})
    comparisons[d]={'pairs':pairs,'two_round_numeric_signal':pairs[0]['numeric_signal'] if pairs[0]['numeric_signal']==pairs[1]['numeric_signal'] else 'not_consistent','semantic_restriction':('P2 baseline selection mismatch; body path only' if d.startswith('P2') else 'different scroll distance/layout; disclose cost, no acceleration claim' if d=='L1-locate' else 'tool wall-clock upper bound; not exact product latency' if d=='R1-dom-upper' else 'image decode excluded; observed loaded image separate' if d.startswith('M1') else 'media readiness separate' if d.startswith('M2') else None)}

anomalies={}
anomalies['B1_interruption']=load(BACKEND/'interruption-1855.json')
anomalies['B1_interrupted_outputs']={x:(BACKEND/'B1'/x).exists() for x in ['receipt.json','http.jsonl','identity-after.json']}
anomalies['B1_resumed_receipt']=load(BACKEND/'B1-resumed/receipt.json')
anomalies['B1_warmup_assertion_correction']=load(BROWSER/'M1-B1-warmup-assertion-correction.json')
old=load(BROWSER/'M1-zoom-B1-0.json');anomalies['B1_warmup_original']={'checks':old['checks'],'expected':old['expected'],'actual_query':query(old['observed']['url'])}
old=load(BROWSER/'P2-record2-B2-2.json');late=load(BROWSER/'P2-record2-B2-2-late-observation.json');ls=late['probe']['samples'][-1]
anomalies['B2_timeout_late_same_event']={'original_checks':old['checks'],'original_error':old['actionError'],'before_count':old['before']['count'],'original_last_sample_id':old['probe']['samples'][-1]['id'],'late_sample_id':ls['id'],'late_ready_ms':ls['scenario_ready_ms'],'late_action_repeated':late['actionRepeated'],'active_original':old['probe']['active'],'late_start_ms':ls['start_ms'],'same_time_origin':old['probe']['browser']['time_origin']==late['probe']['browser']['time_origin']}
late_epoch=late['probe']['browser']['time_origin']+ls['start_ms']
anomalies['B2_timeout_late_same_event'].update(late_action_epoch_ms=late_epoch,original_tool_interval=[old['tool_start_epoch_ms'],old['tool_end_epoch_ms']],single_new_event_within_original_tool_interval=ls['id']==old['before']['count']+1 and len(late['probe']['samples'])==old['before']['count']+1 and old['tool_start_epoch_ms']<=late_epoch<=old['tool_end_epoch_ms'])
anomalies['old_standard_action_coverage']={p:sum((BROWSER/f'{d}-{p}-{i}.json').exists() for d in DIRECTIONS for i in range(4)) for p in ['A1','B1','A2','B2']}
anomalies['B2_load_interruption']=load(BACKEND/'external-load-interruption.json')
protocol=load(BACKEND/'clean-window-protocol.json');cleanload=load(BACKEND/'clean-window-load-observation.json');oldload=load(BACKEND/'B2-load-observation.json')
anomalies['clean_window_protocol']=protocol
anomalies['load_snapshots']={'clean_uptime':cleanload['uptime'],'clean_boundary':cleanload['boundary'],'old_uptime':oldload['uptime'],'old_high_cpu_lines':[x for x in oldload['process_cpu_snapshot'].splitlines() if '66403 ' in x or '66941 ' in x],'clean_high_cpu_lines':[]}
for line in cleanload['processes'].splitlines()[1:]:
    parts=line.split(None,4)
    try:
        if len(parts)>4 and float(parts[2])>=5:anomalies['load_snapshots']['clean_high_cpu_lines'].append(line)
    except ValueError:pass

for p in list(BROWSER.glob('*'))+list(BACKEND.rglob('*')):
    if p.is_file() and str(p.relative_to(ROOT)) not in hashes: hashes[str(p.relative_to(ROOT))]=hashlib.sha256(p.read_bytes()).hexdigest()

result={'reviewer_thread_id':'01a10bdc-2c5f-7550-a7fc-01f1a7401b58','reviewer':'/root/supplement_audit','scope':'independent offline audit; no new browser/service/database activity','generated_at_utc':datetime.now(timezone.utc).isoformat(),'input_sha256':hashes,'selected_phases':PHASES,'excluded_prior_phases':['A1','B1','A2','B2'],'frozen_baseline_record':baseline,'stages':stages,'rows':rows,'statistics':stats_by,'comparisons':comparisons,'checks':checks,'failed_checks':[x for x in checks if not x['pass']],'anomalies':anomalies,'visual_review':{'files':['L1-final-A4.png','L1-final-B4.png'],'method':'actual PNG inspected with view_image by reviewer','finding':'A4 right-hand part of exact selected quotation is behind comments panel; B4 complete quotation visible on two lines'},'method':{'formal_indices':[1,2,3],'warmup_index':0,'per_direction_per_stage_n':3,'quantile':'Type7: linear interpolation at (n-1)*p','MAD':'unscaled median absolute deviation','rule':'abs(median A - median B) > max(IQR A, IQR B, 3*MAD A, 3*MAD B), and IQR intervals disjoint, same direction in both pairs; descriptive only, not significance','no_pooling':True,'row_metric_note':'16 R1 Enter observations use only tool wall-clock upper bound; 144 click observations use frozen scenario_ready_ms recomputed from capture_finished_ms-start_ms'},'limitations':['n=3 per direction per stage; fixed ABAB order and nonzero background load do not establish randomized causality','Input media identity recordings cover name/size/mtime; no independent whole-media byte hashing','Database frozen hash and 6236 object baseline record cross-matched; database not reopened or queried by reviewer','Adapter protocol records only-label change and before/after hashes; no before-image diff inspected','A3 stale browser-handle recovery is coordinator-reported; no dedicated raw tool-call record in supplied directory','Warm-cache image readiness timing excludes decode and paint; media playback observation does not establish audible output','HTTP logs include six WAV BrokenPipe errors; probe fetch error count must not be generalized to all HTTP requests']}
OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'output':str(OUT.relative_to(ROOT)),'rows':len(rows),'failed_checks':result['failed_checks'],'comparisons':comparisons},ensure_ascii=False,indent=2))
