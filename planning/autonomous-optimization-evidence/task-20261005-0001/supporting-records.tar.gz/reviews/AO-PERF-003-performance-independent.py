#!/usr/bin/env python3
"""Offline independent audit. Reads saved JSON/log/code only; no HTTP/DB access."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / 'backend-investigation/comments-reuse-abab-reset-01'
OUTPUT = Path(__file__).with_suffix('.json')
started = time.perf_counter()
files = {}
checks = []

def read(path):
    b = path.read_bytes()
    files[str(path.relative_to(ROOT))] = hashlib.sha256(b).hexdigest()
    return b

def jread(path):
    return json.loads(read(path))

def require(name, value):
    checks.append({'check': name, 'passed': bool(value)})
    if not value:
        raise AssertionError(name)

def canonical(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def epoch(utc):
    return datetime.strptime(utc, '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc).timestamp()

def quantile(values, q):
    p = (len(values)-1) * q
    lower = math.floor(p)
    upper = math.ceil(p)
    return values[lower] + (values[upper] - values[lower]) * (p-lower)

def stats(values):
    ordered = sorted(values)
    median = statistics.median(ordered)
    q1,q3=quantile(ordered,.25),quantile(ordered,.75)
    return {'n':len(values), 'raw_ms':values, 'min_ms':ordered[0], 'max_ms':ordered[-1],
            'median_ms':median, 'p95_ms':ordered[math.ceil(len(ordered)*.95)-1],
            'q1_ms':q1,'q3_ms':q3,'iqr_ms':q3-q1,
            'mad_ms':statistics.median(abs(v-median) for v in values)}

def guard_ok(g):
    w=g['watcher']
    return (g['task_id']=='task-20261005-0001' and g['t0']==1791177710.0 and g['phase']=='armed'
            and w['running'] and w['lock_held'] and w['supervision_confirmed'] and w['last_error'] is None
            and 0 <= w['heartbeat_age_seconds'] < 60)

receipt=jread(SOURCE/'receipt.json')
routes=jread(SOURCE/'routes.json')
order=['A1','B1','A2','B2']
require('complete bounded ABAB receipt', receipt['order']==order and receipt['completed_phases']==order and receipt['error'] is None and receipt['elapsed_seconds']<receipt['max_seconds']==30)
require('UTC wall interval matches monotonic within 10ms', abs((receipt['finished_epoch']-receipt['started_epoch'])-receipt['elapsed_seconds'])<.01)
require('receipt UTC stamps correctly rounded', epoch(receipt['started_at_utc'])==math.floor(receipt['started_epoch']) and epoch(receipt['ended_at_utc'])==math.floor(receipt['finished_epoch']))
require('receipt guard and no-mutation assertions',guard_ok(receipt['guard_before']) and guard_ok(receipt['guard_after']) and receipt['database_unchanged'] and receipt['candidate_code_unchanged'])
require('patch identity',hashlib.sha256(read(SOURCE/'candidate-production.patch')).hexdigest()==receipt['candidate_patch_sha256'])
phase_results={}
identities={}
canonical_by_route={}
all_body_hashes={r['name']:set() for r in routes}
all_json_hashes={r['name']:set() for r in routes}
previous_finish=receipt['started_epoch']
common_env=None
for idx,phase in enumerate(order):
    p=SOURCE/phase
    identity=jread(p/'identity.json'); identities[phase]=identity
    env=jread(p/'http/environment.json')
    summary=jread(p/'http/summary.json')
    samples=[json.loads(line) for line in read(p/'http/samples.jsonl').decode().splitlines()]
    require(phase+' identity equals combined receipt',identity==receipt['phases'][idx])
    require(phase+' completed and stopped',identity['phase']==phase and identity['label']==('baseline' if phase.startswith('A') else 'candidate') and identity['completed'] and identity['error'] is None and identity['returncode']==0 and identity['server_returncode']==-15 and identity['port_closed'] and identity['inputs_unchanged'])
    require(phase+' temporal order',previous_finish<=identity['started_epoch']<identity['finished_epoch']<=receipt['finished_epoch'])
    previous_finish=identity['finished_epoch']
    require(phase+' UTC stamps',epoch(identity['started_at_utc'])==math.floor(identity['started_epoch']) and epoch(identity['ended_at_utc'])==math.floor(identity['finished_epoch']))
    require(phase+' code and database before/after recorded unchanged',identity['before']['code']==identity['after']['code'] and identity['before']['database_sha256']==identity['after']['database_sha256']==receipt['database_sha256'])
    require(phase+' guards active',guard_ok(identity['before']['guard']) and guard_ok(identity['after']['guard']))
    require(phase+' correct measurement environment',env['base_url']=='http://127.0.0.1:62607' and env['repeat']==20 and env['warmup']==3 and env['request_timeout_seconds']==3 and env['routes']==routes and env['max_seconds']<=25)
    env_fields={k:env[k] for k in ('base_url','routes','repeat','warmup','request_timeout_seconds','machine','python','cache_scope','timing')}
    if common_env is None: common_env=env_fields
    require(phase+' same environment',common_env==env_fields)
    require(phase+' 69 sequential successful samples',len(samples)==69 and [s['sequence'] for s in samples]==list(range(1,70)) and all(s['status']==200 and s['elapsed_ms']>0 and 'error' not in s and 'error_type' not in s for s in samples))
    require(phase+' raw sample timestamps inside phase rounded seconds',all(math.floor(identity['started_epoch'])<=epoch(s['at_utc'])<=math.floor(identity['finished_epoch']) for s in samples))
    require(phase+' sample UTC order',sorted(s['at_utc'] for s in samples)==[s['at_utc'] for s in samples])
    require(phase+' summary complete',summary==identity['summary'] and summary['sample_count']==69 and summary['aborted'] is None)
    server_lines=read(p/'server.log').decode().splitlines()
    server_identity=json.loads(server_lines[0])
    requests=[re.fullmatch(r'127\.0\.0\.1 - - \[([^]]+)\] "(\w+) (\S+) HTTP/1\.1" (\d+) -',line) for line in server_lines[1:]]
    require(phase+' all server lines parsed',all(requests))
    require(phase+' 73 server requests all GET 200',len(requests)==73 and all(m[2]=='GET' and m[4]=='200' for m in requests))
    counts=Counter(m[3] for m in requests)
    require(phase+' server request accounting',counts==Counter({'/api/instance':1,**{r['path']:24 for r in routes}}))
    expected_system=SOURCE/'baseline-system' if phase.startswith('A') else ROOT/'system-worktree'
    require(phase+' server correct read-only inputs',server_identity['read_only'] and server_identity['port']==62607 and Path(server_identity['system'])==expected_system and Path(server_identity['database'])==ROOT/'preview/.runtime/generation-base.sqlite3')
    result={'identity':{k:identity[k] for k in ('started_at_utc','started_epoch','ended_at_utc','finished_epoch','server_pid','server_returncode','port_closed')},'server_request_count':len(requests),'routes':{}}
    for ri,route in enumerate(routes):
        name=route['name']; rows=samples[ri*23:(ri+1)*23]
        require(phase+' '+name+' warmup and sample layout',all(s['name']==name and s['path']==route['path'] for s in rows) and [s['iteration'] for s in rows]==list(range(-2,21)) and [s['phase'] for s in rows]==['warmup']*3+['sample']*20)
        saved=jread(p/(name+'-response.json')); h=canonical(saved)
        expected_count={'comments-all':271,'source-refinement-v7':40,'source-refinement-v1':16}[name]
        require(phase+' '+name+' saved full response and anchors',isinstance(saved,list) and len(saved)==expected_count and all(c['anchor_state']['valid'] is True for c in saved))
        if name not in canonical_by_route: canonical_by_route[name]=h
        require(phase+' '+name+' all 23 canonical hashes equal independently saved body and baseline',all(s['json_sha256']==h==canonical_by_route[name] for s in rows))
        all_json_hashes[name].update(s['json_sha256'] for s in rows)
        all_body_hashes[name].update(s['body_sha256'] for s in rows)
        values=[s['elapsed_ms'] for s in rows[3:]]; computed=stats(values)
        require(phase+' '+name+' summary statistics exact',all(computed[k]==summary['results'][name][k] for k in ('n','min_ms','max_ms','median_ms','p95_ms')))
        semantic=identity['semantic_reads_after_samples'][name]
        require(phase+' '+name+' semantic read receipt exact',semantic['comments']==len(saved) and semantic['json_sha256']==h and semantic['matches_all_23_responses'] and semantic['matches_initial_baseline'] and semantic['all_anchors_valid'])
        computed.update(warmup_ms=[s['elapsed_ms'] for s in rows[:3]],bytes=sorted({s['bytes'] for s in rows}),canonical_sha256=h,response_count=len(saved))
        result['routes'][name]=computed
    phase_results[phase]=result
require('same baseline code between A1 A2',identities['A1']['before']['code']==identities['A2']['before']['code'])
require('same candidate code between B1 B2',identities['B1']['before']['code']==identities['B2']['before']['code'])
baseline_code=identities['A1']['before']['code'];candidate_code=identities['B1']['before']['code']
changed=[name for name in baseline_code if baseline_code[name]!=candidate_code[name]]
require('only expected two Python files differ',set(baseline_code)==set(candidate_code) and len(baseline_code)==30 and sorted(changed)==['review_desk/server.py','review_desk/store.py'])
require('frozen baseline source files match recorded hashes',all(hashlib.sha256(read(SOURCE/'baseline-system'/name)).hexdigest()==h for name,h in baseline_code.items()))
baseline_git_checks={name:hashlib.sha256(subprocess.check_output(['git','-C',str(ROOT/'system-worktree'),'show',receipt['baseline_commit']+':'+name])).hexdigest()==h for name,h in baseline_code.items()}
require('all baseline files match exact git commit',all(baseline_git_checks.values()))
require('all raw response hashes stable per route across 92 samples',all(len(h)==1 for h in all_body_hashes.values()))
comparisons={}
for route in routes:
    name=route['name']; comparisons[name]={'pairs':{}}
    for a,b in [('A1','B1'),('A2','B2')]:
        av=phase_results[a]['routes'][name];bv=phase_results[b]['routes'][name]
        delta=av['median_ms']-bv['median_ms']
        threshold=max(av['iqr_ms'],bv['iqr_ms'],3*av['mad_ms'],3*bv['mad_ms'])
        comparisons[name]['pairs'][a+'-'+b]={'median_reduction_ms':delta,'relative_median_reduction_percent':delta/av['median_ms']*100,'range_gap_ms':av['min_ms']-bv['max_ms'],'iqr_gap_ms':av['q1_ms']-bv['q3_ms'],'descriptive_variation_threshold_ms':threshold,'exceeds_descriptive_variation':delta>threshold and av['q1_ms']>bv['q3_ms']}
    comparisons[name]['cross_round_B1_max_minus_A2_min_ms']=phase_results['B1']['routes'][name]['max_ms']-phase_results['A2']['routes'][name]['min_ms']
    for role in ('A','B'):
        v1=phase_results[role+'1']['routes'][name]['median_ms'];v2=phase_results[role+'2']['routes'][name]['median_ms']
        comparisons[name][role+'_second_vs_first_median_percent']=(v2/v1-1)*100
result={'reviewer':'/root/reset_supervisor','reviewer_thread':'01a10a85-fd7a-7021-aa28-a867f6dea1d8','audited_at_utc':datetime.now(timezone.utc).isoformat(),'scope':'offline saved JSON, logs, patch, frozen source; no requests, database access or rerun','passed':True,'checks':checks,'environment':common_env,'baseline_commit':receipt['baseline_commit'],'candidate_head':receipt['candidate_head'],'candidate_patch_sha256':receipt['candidate_patch_sha256'],'changed_python_files':changed,'python_file_count':len(baseline_code),'baseline_commit_code_verification':baseline_git_checks,'database_sha256_from_runner_only':receipt['database_sha256'],'measurement_utc_interval':[receipt['started_at_utc'],receipt['ended_at_utc']],'measurement_elapsed_seconds':receipt['elapsed_seconds'],'phase_results':phase_results,'comparisons':comparisons,'canonical_hashes':canonical_by_route,'raw_body_hashes':{k:sorted(v) for k,v in all_body_hashes.items()},'request_counts':{'measured':240,'warmup':36,'post_sample_semantic':12,'readiness':4,'server_total':292},'input_file_sha256':files,'audit_elapsed_seconds':time.perf_counter()-started}
OUTPUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':True,'checks':len(checks),'audit_elapsed_seconds':result['audit_elapsed_seconds'],'comparison':comparisons},ensure_ascii=False,indent=2))
