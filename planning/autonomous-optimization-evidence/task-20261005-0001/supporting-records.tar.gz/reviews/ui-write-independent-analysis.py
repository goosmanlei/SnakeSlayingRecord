#!/usr/bin/env python3
"""Review saved UI/HTTP/history evidence only; never opens DB or a service."""
import collections
import datetime
import hashlib
import json
import statistics
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
U = BASE / 'ui-write-performance'
BR = BASE / 'browser/ui-write-reset-01'
OUT = Path(__file__).resolve().parent
OPS = ['W1-create', 'W2-edit', 'W3-project', 'W4-system', 'W5-accept', 'W5-revoke']
COMMITS = {'A': 'b874b959af9c918a482e8488dc25cb0204ab5772', 'B': '204c4696f0ecd4595b395a14520eacf0c54ef2bf'}
checks = []
def load(p): return json.loads(p.read_text())
def lines(p): return [json.loads(x) for x in p.read_text().splitlines()]
def canonical(row): return json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
def check(name, value): checks.append({'name': name, 'passed': bool(value)})
def stats(values):
    ordered = sorted(values)
    q1, _, q3 = statistics.quantiles(values, n=4, method='inclusive')
    return {'raw_ms': values, 'n': len(values), 'median_ms': statistics.median(values),
            'min_ms': ordered[0], 'max_ms': ordered[-1], 'range_ms': ordered[-1] - ordered[0],
            'q1_ms': q1, 'q3_ms': q3, 'iqr_ms': q3 - q1,
            'sample_stdev_ms': statistics.stdev(values)}

plan = load(U / 'plan.json')
initial = plan['initial_state']
anchor = load(U / 'text-anchor-protocol-correction.json')['anchor']
old = load(U / 'snapshot-logical-before.json')
decision_id = initial['decision_id']
all_rows, phase_reviews = [], {}
for phase in ['A', 'B']:
    run = U / 'runs' / (phase + '-measured')
    calls = lines(run / 'write-audit.jsonl')
    http = lines(run / 'http.jsonl')
    http_writes = [(i, h) for i, h in enumerate(http) if h['method'] != 'GET']
    after = load(run / 'logical-after.json')
    state = load(run / 'technical-state-after.json')
    receipt = load(run / 'receipt.json')
    identity = load(run / 'identity-before.json')
    identity_after = load(run / 'identity-after.json')
    samples = sorted([load(BR / f'{op}-{phase}-{n}.json') for op in OPS for n in range(4)], key=lambda x: x['tool_start_epoch_ms'])
    check(f'{phase}:24 calls/samples/http writes', len(calls) == len(samples) == len(http_writes) == 24)
    check(f'{phase}:receipt clean/stopped', receipt.get('error') is None and not receipt.get('final_check_error') and receipt['stop_signal'] == 15)
    check(f'{phase}:code/files identity', identity['code'] == identity_after['code'] and identity['files'] == identity_after['files'])
    check(f'{phase}:pristine clone', identity['database_sha256'] == plan['snapshot_sha256'] and not identity['code']['dirty'])
    check(f'{phase}:snapshot/inputs preserved', all(receipt[k] for k in ['code_unchanged', 'files_unchanged', 'snapshot_unchanged']))
    check(f'{phase}:all logged HTTP successful', all(h['status'] in (200, 201) and not h['error_type'] for h in http))
    for table, rows in old.items():
        kept = {canonical(row) for row in after[table]}
        protected = [row for row in rows if not (table == 'objects' and row['id'] == decision_id)]
        check(f'{phase}:old {table}', all(canonical(row) in kept for row in protected))
    check(f'{phase}:all unchanged material tables including content', all(after[t] == rows for t, rows in old.items() if t.startswith('material_')))
    check(f'{phase}:no new objects/calls/assets', {r['id'] for r in old['objects']} == {r['id'] for r in after['objects']})
    old_ids = {r['id'] for r in old['revisions']}
    new_revisions = sorted([r for r in after['revisions'] if r['id'] not in old_ids], key=lambda r:r['version'])
    check(f'{phase}:only decision revisions 5-12', len(new_revisions) == 8 and all(r['object_id'] == decision_id for r in new_revisions) and [r['version'] for r in new_revisions] == list(range(5, 13)))
    old_deps = {canonical(r) for r in old['dependencies']}
    check(f'{phase}:new dependencies only decisions', all(r['from_revision'] in {v['id'] for v in new_revisions} for r in after['dependencies'] if canonical(r) not in old_deps))
    check(f'{phase}:generation boundary', state['generation_accepted'] is None and state['acceptance_mode'] == 'content' and not state['preparation_complete'] and state['decision_version'] == 12 and state['can_accept'] and not state['can_revoke'])
    comment_ids = {}
    decisions = []
    for ix, (s, call, (http_ix, h)) in enumerate(zip(samples, calls, http_writes)):
        name = f"{s['id']}-{phase}-{s['index']}"
        p = s['probe']; sample = p['samples'][-1]; semantic = sample['semantic_at_ready']
        reqs = [r for r in p['requests'] if r['start_ms'] >= sample['start_ms']]
        writes = [r for r in reqs if r['method'] != 'GET']
        check(name + ':independent click/ready', sample['type'] == 'click' and sample['target']['label'] == s['expected']['button'] and len(p['samples']) == s['before']['sample_count'] + 1 and sample['completion_reason'] == 'stable' and sample['visibility_at_start'] == sample['visibility_at_end'] == 'visible' and not any(sample['pending_at_end'].values()) and not sample['request_error_count'] and s['actionError'] is None)
        check(name + ':identity/browser', p['metadata']['system_commit'] == COMMITS[phase] and p['metadata']['probe_sha256'] == '74a80b7f730a450f4fc00f5424120f8f60406e7fe9c4c65234e3d317958a804c' and p['browser']['viewport'] == {'width':1440,'height':900} and p['browser']['device_pixel_ratio'] == 1)
        check(name + ':HTTP audit join', len(writes) == 1 and writes[0]['method'] == call['method'] == h['method'] and writes[0]['url'] == call['path'] == h['path'] and writes[0]['status'] == call['status'] == h['status'] == s['expected']['status'])
        request_epoch = p['browser']['time_origin'] + writes[0]['start_ms']
        audit_epoch = datetime.datetime.fromisoformat(call['at_utc'].replace('Z','+00:00')).timestamp() * 1000
        check(name + ':audit within second-resolution timestamp', abs(request_epoch-audit_epoch) < 1500)
        matching_http = http[http_ix:http_ix + len(reqs)]
        check(name + ':write then exact refresh sequence', [(r['method'],r['url'],r['status']) for r in reqs] == [(r['method'],r['path'],r['status']) for r in matching_http])
        semantic_text = ' '.join(r['first'] + ' ' + r['last'] for r in semantic['regions'])
        body = call['request']; response = call['response']; index = s['index']; op = s['id']
        if op in ['W1-create', 'W2-edit']:
            expected_text = plan['comments'][index]['create' if op == 'W1-create' else 'edit']
            check(name + ':comment response/precise anchor', response['body'] == expected_text and response['target_object_id'] == initial['entity']['object_id'] and response['target_revision_id'] == initial['entity']['id'] and response['anchor'] == anchor and response['status'] == 'OPEN' and response['version'] == (1 if op == 'W1-create' else 2))
            cards = [c for c in s['observed']['commentCards'] if c['id'] == 'comment-' + response['id']]
            check(name + ':visible text and edit control', expected_text in semantic_text and len(cards) == 1 and expected_text in cards[0]['text'] and '编辑' in cards[0]['text'] and not s['observed']['editor'] and '- button "编辑"' in s['dom'])
            if op == 'W1-create': comment_ids[index] = response['id']
            else: check(name + ':same comment/version guard', response['id'] == comment_ids[index] and body['expected_version'] == 1)
        elif op in ['W3-project', 'W4-system']:
            scope, field, value = ('PROJECT','audience',plan['PROJECT_audience'][index]) if op == 'W3-project' else ('SYSTEM','ai_context_max_chars',plan['SYSTEM_ai_context_max_chars'][index])
            expected_body = {**initial['configurations'][scope]['body'], field:value}
            check(name + ':full config response/version', body['expected_version'] == index and response['version'] == index + 1 and response['body'] == expected_body)
            values = [c['value'] for c in s['observed']['controls'] if c['name'] == field]
            check(name + ':actual input and visible saved version', values == [str(value)] and f'配置版本 {index+1} · Schema 4' in semantic_text and str(value) in s['dom'] and '- button "保存配置" [disabled]' in s['dom'])
        else:
            action = 'accept' if op == 'W5-accept' else 'revoke'
            expected_version = 4 + len(decisions)
            record = response['records'][0]
            check(name + ':decision scope/mode/version', body['action'] == action and body['entity_id'] == initial['entity']['object_id'] and body['scope'] == initial['scope'] and body['acceptance_mode'] == 'content' and body['actor'] == '用户' and body['expected_version'] == expected_version and record['version'] == expected_version+1 and record['id'] == decision_id)
            if action == 'revoke': check(name + ':revoke exact preceding decision', body['decision_ref'] == {'object_id':decision_id,'revision_id':decisions[-1]['revision']})
            else: check(name + ':accept explicit scope no mistaken reference', body['decision_ref'] is None)
            expected_button = '取消采纳' if action == 'accept' else '采纳'
            check(name + ':actual result button', f'- button "{expected_button}"\n' in s['dom'] and expected_button in semantic_text)
            decisions.append(record)
        all_rows.append({'sample':name,'operation':op,'phase':phase,'index':index,'warmup':index==0,'original_false_checks':[k for k,v in s['checks'].items() if not v], 'ready_ms':sample['scenario_ready_ms'],'content_ready_ms':sample['content_ready_ms'],'semantic_capture_ms':sample['semantic_capture_ms'],'stability_confirm_ms':sample['stability_confirm_ms'],'tool_ms':s['tool_end_epoch_ms']-s['tool_start_epoch_ms'],'browser_write_fetch_ms':writes[0]['fetch_settled_ms']-writes[0]['start_ms'],'server_write_handler_ms':h['server_elapsed_ms'],'browser_refresh_fetch_ms':[r['fetch_settled_ms']-r['start_ms'] for r in reqs[1:]], 'server_refresh_handler_ms':[r['server_elapsed_ms'] for r in matching_http[1:]],'request_routes':[(r['method'],r['url']) for r in reqs],'comment_id':response.get('id') if op in ['W1-create','W2-edit'] else None,'exact_result_version':response.get('version') if op not in ['W5-accept','W5-revoke'] else response['records'][0]['version']})
    check(f'{phase}:four comments/eight history events', len(after['comments']) == 4 and len(after['comment_events']) == 8)
    for index, comment_id in comment_ids.items():
        events = sorted([e for e in after['comment_events'] if e['comment_id'] == comment_id], key=lambda e:e['id'])
        check(f'{phase}:full comment history {index}', [e['action'] for e in events] == ['CREATE','EDIT'] and [e['body'] for e in events] == [plan['comments'][index]['create'],plan['comments'][index]['edit']])
    for scope, field, values in [('PROJECT','audience',plan['PROJECT_audience']),('SYSTEM','ai_context_max_chars',plan['SYSTEM_ai_context_max_chars'])]:
        history = sorted([r for r in after['configuration_events'] if r['scope'] == scope], key=lambda r:r['version'])
        check(f'{phase}:complete config history {scope}', [r['version'] for r in history] == [1,2,3,4] and [json.loads(r['body']) for r in history] == [{**initial['configurations'][scope]['body'],field:value} for value in values])
    for i, revision in enumerate(new_revisions):
        payload = json.loads(revision['payload'])
        check(f'{phase}:decision history scope {i+5}', payload['acceptance_model'] == 'entity-content-v1' and payload['acceptance_scope'] == initial['scope'] and payload['actor'] == '用户' and payload['target'] == initial['scope']['entity'] and revision['id'] == decisions[i]['revision'])
        if i % 2: check(f'{phase}:revocation chain {i+5}', payload['previous_decision'] == {'object_id':decision_id,'revision_id':new_revisions[i-1]['id']} and payload['verdict'] == 'revoked')
    phase_reviews[phase] = {'receipt':receipt,'source_commit':identity['code']['commit'],'clone_inode':identity['clone_inode'],'initial_database_sha256':identity['database_sha256'],'http_count':len(http),'write_count':len(calls),'previous_audit_checks':len(load(run/'history-audit.json')['checks']),'counts_after':{k:len(v) for k,v in after.items()}}

check('independent clone inodes',phase_reviews['A']['clone_inode'] != phase_reviews['B']['clone_inode'])
metrics = ['ready_ms','content_ready_ms','semantic_capture_ms','stability_confirm_ms','tool_ms','browser_write_fetch_ms','server_write_handler_ms']
comparison = {}
for op in OPS:
    result = {}
    for phase in ['A','B']:
        formal = [r for r in all_rows if r['operation']==op and r['phase']==phase and not r['warmup']]
        result[phase] = {metric:stats([r[metric] for r in formal]) for metric in metrics}
    a,b=result['A']['ready_ms'],result['B']['ready_ms']
    result['ready_delta_B_minus_A_ms']=b['median_ms']-a['median_ms']
    result['ready_ranges_overlap']=max(a['min_ms'],b['min_ms']) <= min(a['max_ms'],b['max_ms'])
    result['causal_claim']='Not established: sequential AB, n=3 per arm, warmed repeat actions, frame scheduling and order confounding.'
    comparison[op]=result
evidence = sorted(set([Path(__file__)] + list(BR.glob('*')) + list(U.glob('*.json')) + [U/'serve.py',U/'audit.py'] + list((U/'runs/A-measured').glob('*.json')) + list((U/'runs/A-measured').glob('*.jsonl')) + list((U/'runs/B-measured').glob('*.json')) + list((U/'runs/B-measured').glob('*.jsonl'))))
result={'status':'passed_evidence_integrity_with_small_sample_timing_limits' if all(c['passed'] for c in checks) else 'review_findings','reviewed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'coverage_reviewer; no product implementation, browser operation, DB access or HTTP in this review','checks':checks,'failures':[c['name'] for c in checks if not c['passed']],'quantile_method':'inclusive linear quartiles (n=3 Q1=(min+median)/2, Q3=(median+max)/2); descriptive, not inferential','sample_plan':'48 real UI writes: six operations × two phases × one warmup plus three formal; 36 formal total','phase_reviews':phase_reviews,'comparisons':comparison,'samples':all_rows,'manifest':[{'file':str(p.relative_to(BASE)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in evidence]}
(OUT/'ui-write-independent.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'failures':result['failures'],'comparison':{op:{'A':result['comparisons'][op]['A']['ready_ms'],'B':result['comparisons'][op]['B']['ready_ms']} for op in OPS}},ensure_ascii=False))
