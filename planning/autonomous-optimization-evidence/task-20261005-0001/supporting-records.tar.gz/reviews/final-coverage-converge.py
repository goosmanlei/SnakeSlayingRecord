"""Apply the final, bounded conclusion update after the UX010 review exists."""
import argparse
import copy
import hashlib
import json
import subprocess
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--ux010-md', required=True)
parser.add_argument('--ux010-json', required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parents[3]
base = root / '.runtime/autonomous-optimization'
system = base / 'system-worktree'
final_system = '24e926d446a9424a8cbc3c8b9910aaa322ff9632'
assert subprocess.check_output(['git', '-C', str(system), 'rev-parse', 'HEAD'], text=True).strip() == final_system
assert hashlib.sha256((system/'review_desk/static/entity-review.js').read_bytes()).hexdigest() == 'f3f4fd0d3d6461012fd6701a61b3c2874ab9ae14b3790e32d3ca9d8a0449bcd3'
ux_md, ux_json = base / args.ux010_md, base / args.ux010_json
assert ux_md.is_file() and ux_json.is_file()
now = datetime.now(timezone.utc).isoformat()
matrix_path = base/'history-inventory/coverage-prioritized-checkpoint.json'
matrix_md = matrix_path.with_suffix('.md')
data = json.loads(matrix_path.read_text())
assert data['counts'] == {'通过': 57, '未验': 2, '部分': 2}
checkpoint = {k: copy.deepcopy(data[k]) for k in ['audited_at', 'counts', 'quality_convergence_gates', 'priority_next_five', 'final_coverage_reconciliation']}
checkpoint['json_sha256_before'] = hashlib.sha256(matrix_path.read_bytes()).hexdigest()
checkpoint['markdown_sha256_before'] = hashlib.sha256(matrix_md.read_bytes()).hexdigest()
checkpoint['row_conclusions'] = {r['id']: {k: copy.deepcopy(r[k]) for k in ['verified_scope', 'status', 'performance_status', 'performance_note', 'quality_gap']} for r in data['coverage']}
data['previous_conclusion_checkpoints'].append(checkpoint)
data['audited_at'] = now
data['method'] += ' 最终增量独审24e926d三文件diff，复核UX010非实施者反例/浏览器与57项聚焦回归；没有重跑后台或全套测试。'
rows = {r['id']: r for r in data['coverage']}
def source(row, *names):
    for name in names:
        path = str((base/name).relative_to(root))
        if path not in row['evidence']:
            row['evidence'].append(path)

for row in data['coverage']:
    if row['performance_status'] == 'FINAL_ABAB_SELECTED_ACTIONS_REVIEWED':
        row['performance_note'] = '312条正式交互已独审；仅适用于对应页签/版本/集场/媒体类型筛选/翻页中的实际测量动作。完整正确交互持续收益共7方向：制作拆解返回S001、素材筛选和翻页四方向、镜头场次双向。D2两方向24条正式旧样本目标pressed均为false，仅保留正文到达数值；新UX010功能通过没有改写旧性能样本。未测同页其他组合不借此覆盖。'
    if row['verified_scope'] == '桌面可信 click 后子页及限定正文内容一致；键盘左右/Home/End、前进后退、窄屏、快速切页竞态及未提交草稿未覆盖':
        row['verified_scope'] = '本行原样本证明桌面可信click后子页及限定正文一致；没有逐页穷举键盘、历史栈、窄屏、快速切换及草稿组合。共用导航/竞态和草稿的后续代表性验证分别见X-06、X-02及相应阅读器行，不能把原样本边界理解为全任务未验。'
rows['S3-03']['verified_scope'] = '剧本三/四、E01/E02、S001/S002/S003有序切换和准确上下文原样本有效；后续UX009补齐跨集/场草稿正文与身份保持，S3-04补齐旧评论定位，竞态集中X-06。全17集42场、末场和全部组合未穷举。'
source(rows['S3-03'], 'reviews/AO-UX009-independent.json')
rows['S3-04']['verified_scope'] = '剧本三第1集S002旧评论稳定后定位到“腰间挂着庙门钥匙”，完整原圈选可见；固定可见按钮3轮开合body scroll=450、mark top=525.671875均不变。后续UX009另有390宽剧本定位收起/键盘重开及草稿正文保持。跨段全部Unicode、其他全部旧版本、窄屏长场/atEnd与目录独立滚动组合未穷举；早期屏外按钮被CUA自动滚动的记录不作为页面漂移。'
r = rows['D2-04']
r['status'] = '通过'
r['verified_scope'] += ' 最终24e926d的现代实体双向切换、Enter/双击关系卡往返有真实页面原件及独审；准确旧实体/状态、失败和迟到响应以真实代码反例补界。'
r['quality_gap'] = 'UX010已在24e926d关闭：成功读取同步顶层active/aria-pressed，模态刷新不污染外层，跨打开/关闭迟到响应受容器身份保护。14独立反例、真实页面证据及8项维护回归（57项聚焦通过）已复核；全部13/6状态未逐一穷举。4歌10录音/原件及4个当前未生成版由204c469只读核对，代表性歌曲准确版本/评论/播放另有真实页复核。'
r['performance_status'] = 'FINAL_ENTITY_CONTENT_ONLY_OLD_SELECTION_DEFECT_FIXED_LATER'
r['performance_note'] = '旧312交互中的D2双向24条正式记录，目标按钮pressed全部false。因此两方向仅保留准确正文到达数值，不计完整正确交互收益。24e926d只新增功能复验，未重测该性能序列。'
source(r, args.ux010_md, args.ux010_json, 'reviews/ux010-d2-raw-audit.json', 'reviews/ux010-browser-independent.json', 'backend-investigation/merged-main-validation/browser-validation-context.json')
rows['D2-06']['quality_gap'] += ' 最终24e926d对应源码的关系卡Enter/双击打开和关闭已由根操作、另一独审核对；外层选中及准确路线恢复。'
source(rows['D2-06'], args.ux010_md, 'reviews/ux010-browser-independent.json')
rows['X-06']['quality_gap'] += ' UX010的14独立反例进一步覆盖读取失败、两阶段迟到与跨模态打开/关闭边界；真实页覆盖有序往返，不把VM调度反例冒充浏览器延迟注入。'
source(rows['X-06'], args.ux010_md, args.ux010_json)
rows['D3-05']['quality_gap'] = rows['D3-05']['quality_gap'].replace('最终系统读取核对', '204c469真实读取代码核对')
data['counts'] = dict(Counter(r['status'] for r in data['coverage']))
reconciliation = data['final_coverage_reconciliation']
reconciliation['at'] = now
reconciliation['system_reviewed'] = final_system
reconciliation['backend_song_run_system'] = '204c4696f0ecd4595b395a14520eacf0c54ef2bf'
reconciliation['pending_new_issue'] = None
reconciliation['ux010_resolution'] = {'status': 'closed_by_final_code_independent_counterexamples_and_real_browser_review', 'source': args.ux010_json, 'independent_counterexamples': 14, 'maintained_regressions_added': 8, 'focused_tests_passed': 57, 'previous_related_tests_passed': 81, 'performance_remeasured': False}
reconciliation['latest_song_browser'] = {'status': 'passed_representative_real_page_offline_independent_review', 'source': 'reviews/ux010-browser-independent.json', 'scope': 'two songs exact old versions/current empty versions; three exact comments; actual mute/play/pause; entity and relation-card return', 'not_claimed': 'all ten recordings browser traversal, audible content acceptance, or performance comparison'}
reconciliation['performance_claim_correction'] = {'old_complete_interaction_improved_directions': 9, 'current_complete_interaction_improved_directions': 7, 'excluded_directions': 'D2 both directions', 'reason': 'all 24 formal target pressed values false in preserved old raw evidence', 'source': 'reviews/ux010-d2-raw-audit.json'}
new_sources = [args.ux010_md, args.ux010_json, 'reviews/ux010-candidate-independent.json', 'reviews/ux010-browser-independent.json', 'reviews/ux010-d2-raw-audit.json', 'reviews/ux010-final-regression.log', 'reviews/final-coverage-style-audit.json', 'backend-investigation/merged-main-validation/browser-validation-context.json']
manifest_paths = [item['file'] for item in reconciliation['manifest']]
for name in new_sources:
    p = str((base/name).relative_to(root))
    if p not in manifest_paths:
        manifest_paths.append(p)
reconciliation['manifest'] = [{'file': p, 'sha256': hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in manifest_paths]
for gate in data['quality_convergence_gates']:
    if gate['id'] == 'G2':
        gate.update(blocking=False, scope='AO-UX010选中语义与模态迟到保护已关闭', needed='24e926d修复经14反例、57聚焦（含8新增回归）及根真实页/非实施者复核；CSS active类原已更新，已证明的原缺陷是aria-pressed不同步，AX active只表示焦点。旧D2 24正式样本仍只能支持正文路径，完整交互收益改7方向。')
    if gate['id'] == 'G5':
        gate.update(scope='真实最终交付实体', needed='最新歌曲只读/22表恢复及代表性真实页面已通过；最终系统已固定24e926d。仍须核验真实便携包、两仓最终候选、不可变发布包/preflight与恢复身份、可用隔离预览和准确清理回执；本矩阵未核定其成品，不宣称已完成。')
data['priority_next_five'] = [
 {'priority': 1, 'scope': '固定可审阅交付', 'why': '当前功能与后台门槛已关闭，真实成包仍待核', 'minimum': '便携包manifest、脱敏、解压后链接及报告/矩阵当前结论一致', 'not_required': '不重跑无变化的完整性能/后台检查'},
 {'priority': 2, 'scope': '固定代码发布身份', 'why': '源码通过不等于镜像和preflight通过', 'minimum': '准确双仓候选、main/origin/refs/heads/main目标、不可变镜像包与preflight/恢复身份', 'not_required': '不以任务数据库覆盖活库'},
 {'priority': 3, 'scope': '准确资源清理', 'why': '保留用户要求的worktree与分支', 'minimum': '核用途/归属/挂载，清失效试验资源并留回执；必要写入在_complete前', 'not_required': '不全局prune、不强删worktree、不在_complete后补改'},
 {'priority': 4, 'scope': '最终预览与候选展示', 'why': '批准对象必须是可核验成品', 'minimum': '保持隔离预览可用，展示准确候选和交付入口，保留执行时最新正式历史的发布约束', 'not_required': '不将新JS功能复验当完整性能重测'},
 {'priority': 5, 'scope': '据实交付限制', 'why': '已解释成本和外部边界继续有效', 'minimum': 'C2上传、方法故障探索、1024/标题裁切、定位成本、7方向性能口径保持一致', 'not_required': '不为未测组合扩大产品改动或宣称全面提速'},
]
data['corrections'].append({'at': now, 'topic': 'UX010 final bounded closure and original-scope reconciliation', 'previous': '57通过/2部分/2未验；UX010与最新歌曲真实页待独审；D2逐样本归属待核。', 'corrected': '24e926d经独审关闭UX010，最新歌曲代表性页闭合；58通过/1部分/2未验。旧D2 24正式目标pressed全部false，完整交互收益为7方向。原verified_scope未覆盖仅指原样本，补齐范围精确标注。', 'source': args.ux010_json})
matrix_path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')

lines = ['# 代表性功能验收与探索分层检查点', '',
 f'最终复核时间：{now}。覆盖5个主入口、12个子页、61项动作。当前58项代表性功能通过、1项部分、2项探索未验；C2上传保留外部权限限制，方法文件缺失/损坏保留探索未验。系统24e926d的UX010已独审关闭。通过只指该行明确的功能证据，不等于全部组合、性能收益或交付完成。', '',
 '当前字段按真实证据收敛。[机器矩阵](coverage-prioritized-checkpoint.json)保留原观察、旧反证、原独审限制和前次结论，均带各自时间与版本；原始浏览器/API数据未改写。原样本的“未覆盖”不再被用作后续已补齐项目的当前结论。', '',
 '280条页面、312条正式交互、48次真实页面写入及160动作补测均已有非实施者复核。页面/原交互固定b874b959与3b20d609，补测和写入固定204c469，使用6236对象/271评论冻结数据；最新6296对象/285评论单独用于兼容与恢复。完整交互双轮收益当前为7方向；旧D2两方向24条正式目标pressed均为false，只保留正文到达数值，新JS功能修复未重测性能。页面、正文到达、媒体完整加载/播放及含工具往返的键盘上界分别解释，见[页面](../reviews/final-page-independent.md)、[交互](../reviews/final-action-independent.md)、[写入](../reviews/ui-write-independent.md)、[补测](../reviews/supplement-independent.md)独审。', '',
 f'UX008记录选中、UX009会话内草稿和[UX010最终独审](../{args.ux010_md})已通过。UX009的35反例和27份故障记录证明同页面会话及准确身份，不承诺跨目标光标选区、刷新或崩溃持久恢复。UX010的14反例、真实页及57项聚焦测试（含8项新增回归）证明外层选中同步和模态迟到保护；原CSS active类已更新，AX [active]只表示焦点，不能据此宣称现场视觉样式错误。', '',
 '最新歌曲在204c469下只读核对4首歌10个录音版本/原件SHA、4个当前未生成版本、285个有效锚点及原271评论/300事件。一次[最新数据恢复](../reviews/final-coverage-song-restore.json)的22公共业务表与源副本原始行相同，10302修订、314事件及两条PCM历史payload不变；后续24e926d没有后台改动，复用原身份结果。普通恢复器拒绝两条约0.167微秒旧时长舍入，准确恢复须用`scripts/recover_song_publication.py`。根代表性真实页与独审已核对两歌旧版/未生成版、3评论及播放/暂停；没有遍历全部10录音或作内容认可。代码发布只切镜像/挂载，保留执行当时最新活库。', '',
 '技术采用/换版/409、历史判断、清单下载、区域轮廓及关闭暂停证据仍有效，不代表作品认可。C2上传一次被Chrome扩展file URL权限阻断；选择/默认恢复通过，上传及非法文件页面路径不写通过。', '',
 '## 质量收敛与限制', '']
for gate in data['quality_convergence_gates']:
    label = '交付成品待核' if gate['blocking'] else '已关闭或范围已解释'
    lines.append(f"- **{gate['id']} {gate['scope']}**（{label}）：{gate['needed']}")
lines += ['', '## 下一批有界优先序', '']
for item in data['priority_next_five']:
    lines.append(f"{item['priority']}. **{item['scope']}**：{item['minimum']}。{item['not_required']}。")
lines += ['', '## 逐项必要范围与探索限制', '', '| ID | 子页／动作 | 状态 | 必要范围及当前缺口 | 扩展探索／边界 |', '| --- | --- | --- | --- | --- |']
def cell(value):
    return str(value).replace('|','／').replace('\n',' ')
for row in data['coverage']:
    lines.append('| '+' | '.join(map(cell,[row['id'],row['subpage']+'／'+row['action'],row['status'],row['acceptance_required']+' '+row['quality_gap'],row['exploration']]))+' |')
matrix_md.write_text('\n'.join(lines)+'\n')
print(json.dumps({'matrix_counts': data['counts'], 'system': final_system, 'sources': len(reconciliation['manifest']), 'remaining_blocking_gates': [g['id'] for g in data['quality_convergence_gates'] if g['blocking']]}, ensure_ascii=False))
