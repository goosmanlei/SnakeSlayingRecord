#!/usr/bin/env python3
"""Supplement final-page-independent.py with saved phase identities/logs and reviewed label explanations.
Offline only: saved files and local Git objects. No HTTP, browser, database or test execution.
"""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent.parent
REVIEW=ROOT/'reviews';BROWSER=ROOT/'browser/final-page-abab-reset-01';STAGES=ROOT/'backend-investigation/page-final-abab'
report=json.loads((REVIEW/'final-page-independent.json').read_text())
phases=['A1','B1','A2','B2'];hashes={};checks=[]

def read(path):
    raw=path.read_bytes();hashes[str(path.relative_to(ROOT))]=hashlib.sha256(raw).hexdigest();return raw

def load(path):return json.loads(read(path))
def canonical(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def require(name,condition):
    checks.append({'check':name,'passed':bool(condition)})
    if not condition:raise AssertionError(name)
def epoch(value):return datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()*1000

def code_hash(commit):
    repo=ROOT/'system-worktree'
    names=subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','--name-only',commit,'--','review_desk'],text=True).splitlines()
    parts=[]
    for name in sorted(names):
        raw=subprocess.check_output(['git','-C',str(repo),'show',commit+':'+name])
        parts.append((name,hashlib.sha256(raw).hexdigest()))
    return {'sha256':canonical(parts),'file_count':len(parts),'files':dict(parts)}

identities={};stage_results={};git_code={}
for family in ('baseline','candidate'):
    git_code[family]=code_hash(report['git_commit_identities'][family]['commit'])
for phase in phases:
    p=STAGES/phase;before=load(p/'identity-before.json');after=load(p/'identity-after.json');receipt=load(p/'receipt.json')
    process=load(p/'process.json');environment=load(p/'environment.json');preflight=load(p/'preflight.json')
    before_guard=load(p/'guard-before.json');after_guard=load(p/'guard-after.json')
    rows=[json.loads(line) for line in read(p/'http.jsonl').decode().splitlines()]
    family='baseline' if phase.startswith('A') else 'candidate';commit=report['git_commit_identities'][family]['commit']
    require(phase+' exact clean code identity',before['system_commit']==commit and not before['product_dirty'] and before['product_tree_sha256']==git_code[family]['sha256'])
    require(phase+' before/after all fields equal',before==after)
    require(phase+' completed self process',receipt['stage']==process['stage']==phase and receipt['pid']==process['pid'] and receipt['port']==process['port']==62606 and receipt['stop_signal']==15 and receipt['error'] is None and receipt['identity_unchanged'] and not receipt.get('final_check_error'))
    expected_pid={'A1':56583,'B1':58560,'A2':59658,'B2':66644}[phase]
    require(phase+' expected PID',receipt['pid']==expected_pid)
    require(phase+' guard active',all(g['task_id']=='task-20261005-0001' and g['phase']=='armed' and g['t0']==1791177710 and g['watcher']['supervision_confirmed'] and g['watcher']['lock_held'] and g['watcher']['running'] and not g['watcher'].get('last_error') and g['watcher']['heartbeat_age_seconds']<45 for g in (before_guard,after_guard)))
    require(phase+' probe and adapter unchanged',all(hashlib.sha256(read(ROOT/'backend-investigation'/filename)).hexdigest()==before[field] for filename,field in [('probe.js','probe_sha256'),('probe_server.py','probe_server_sha256'),('page_readonly_probe_server.py','adapter_sha256')]))
    samples=[s for page in report['comparisons'] for s in page['phases'][phase]['samples']]
    require(phase+' 70 saved records match exact environment',len(samples)==70 and all(s['metadata']==environment for s in samples))
    require(phase+' records occur during server lifetime',all(epoch(receipt['started_at_utc'])<=s['start_epoch_ms']<=s['end_epoch_ms']<epoch(receipt['finished_at_utc'])+1000 for s in samples))
    require(phase+' direct preflight GET200 POST405',preflight['loopback_direct'] and [(r['method'],r['path'],r['status']) for r in preflight['requests']]==[('GET','/api/instance',200),('POST','/api/comments',405)] and [(r['method'],r['path'],r['status']) for r in rows[:2]]==[('GET','/api/instance',200),('POST','/api/comments',405)])
    rejected=[r for r in rows if r['method']=='POST'];errors=[r for r in rows if r['error_type'] or r['status']>=400 and r['method']!='POST']
    require(phase+' only expected readonly rejection',len(rejected)==1 and rejected[0]['path']=='/api/comments' and rejected[0]['status']==405 and rejected[0]['error_type'] is None)
    require(phase+' all other server errors are retained image broken pipes',all(r['method']=='GET' and r['status']==400 and r['error_type']=='BrokenPipeError' and r['path'].startswith('/api/production/files/') and r['path'].endswith('.png') for r in errors))
    broken_times=[]
    for r in errors:
        timestamp=epoch(r['at_utc']);near=[s['file'] for s in samples if s['page']=='D2' and s['start_epoch_ms']-2000<=timestamp<=s['end_epoch_ms']+2000]
        require(phase+' broken pipe timestamp adjacent to D2 records',bool(near))
        broken_times.append({**r,'nearby_D2_records':near,'timestamp_resolution':'1 second; nearby is not exact request ownership'})
    identities[phase]=before
    stage_results[phase]={'receipt':receipt,'environment':environment,'preflight':preflight,
                         'guard_before':before_guard,'guard_after':after_guard,'http_request_count':len(rows),
                         'http_counts':[{'method':m,'status':s,'error_type':e,'count':n} for (m,s,e),n in Counter((r['method'],r['status'],r['error_type']) for r in rows).items()],
                         'image_broken_pipes':broken_times,'first_http_utc':rows[0]['at_utc'],'last_http_utc':rows[-1]['at_utc']}
shared=['database_sha256','database_bytes','probe_sha256','probe_server_sha256','adapter_sha256','instance_config_sha256','input_metadata_sha256','input_file_count']
require('all four phase frozen data/probe/adapter/config identities equal',all(all(identities[p][k]==identities['A1'][k] for k in shared) for p in phases))
require('repeat code identities same within A and B',identities['A1']==identities['A2'] and identities['B1']==identities['B2'])
require('exact expected database snapshot',identities['A1']['database_sha256']=='5c6d00ee6efa7506201bbef46ffd69bde49f7300c4697fe66036e87ace7ed4f0' and identities['A1']['database_bytes']==163000320)
require('A1 proxy failure retained and absent from service HTTP status records',stage_results['A1']['preflight']['prior_attempt']=={'default_proxy_get_status':502,'server_http_log_absent':True,'excluded_from_samples':True} and not any(x['status']==502 for phase in phases for x in stage_results[phase]['http_counts']))
# These exact string changes were manually reviewed against complete CUA snapshots.
# Keep raw 30 semantic differences; normalization is a separately explained comparison.
replacements=[('无生成结果（含历史版本）','未生成'),('有生成结果（含历史版本）','已生成'),('生成结果（含历史版本）','生成状态'),('有生成结果','已生成'),('无生成结果','未生成'),('有结果','已生成'),('无结果','未生成')]
semantic=[]
for a,b in [('A1','B1'),('A2','B2')]:
    for page in report['comparisons']:
        candidates={s['index']:s for s in page['phases'][b]['samples']}
        for old in page['phases'][a]['samples']:
            new=candidates[old['index']];first=load(BROWSER/old['file']);second=load(BROWSER/new['file']);normalized=second['observation'];used=[]
            for after,before in replacements:
                count=normalized.count(after)
                if count:used.append({'candidate':after,'baseline':before,'count_in_observation':count})
                normalized=normalized.replace(after,before)
            equal=first['observation']==normalized
            require(page['page']+' '+a+'/'+b+' index '+str(old['index'])+' exact complete observation after reviewed labels',equal)
            semantic.append({'page':page['page'],'pair':a+'-'+b,'index':old['index'],'raw_semantic_equal':old['semantic_hash']==new['semantic_hash'],
                             'raw_full_observation_equal':first['observation']==second['observation'],'explicit_label_changes':used,'full_observation_equal_after_reviewed_labels':equal})
require('240 standard records and 40 additional C2',report['sample_files']==280 and sum(len(p['samples']) for c in report['comparisons'] for p in c['phases'].values())==280 and all(c['phases'][p]['main_reload']['n']==4 and c['phases'][p]['navigate']['n']==1 for c in report['comparisons'] for p in phases) and all(next(c for c in report['comparisons'] if c['page']=='C2')['phases'][p]['extra_reload']['n']==10 for p in phases))
summary={'task_id':'task-20261005-0001','reviewer':'/root/reset_supervisor','at_utc':datetime.now(timezone.utc).isoformat(),
         'passed':True,'checks':checks,'input_sha256':hashes,'phase_identities':identities,'committed_product_code_sha256':git_code,
         'stages':stage_results,'semantic_explanations':semantic,'explicit_label_mapping':replacements,
         'scope_note':'Read saved records and local Git objects only; database/media bytes and sockets not accessed.',
         'port_closed_note':'Root reported 62606 closed after own-PID TERM; phase receipts record TERM/finally identity, not an explicit port_closed field.'}
(REVIEW/'final-page-independent-evidence.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':True,'checks':len(checks),'code_files':{k:v['file_count'] for k,v in git_code.items()},'http_requests':sum(s['http_request_count'] for s in stage_results.values()),'broken_pipes':sum(len(s['image_broken_pipes']) for s in stage_results.values()),'normalized_observation_pairs':len(semantic)},ensure_ascii=False))
