import hashlib, json, os, signal, sqlite3, subprocess, sys, time
from pathlib import Path
from review_desk import material_archives as archives, material_storage as storage, production
from review_desk.store import Store, canonical

task = Path.cwd().resolve()
base = task / '.runtime/autonomous-optimization'
system = base / 'system-worktree'
frozen = base / 'preview/.runtime/generation-base.sqlite3'
original = base / 'preview/export'
run = base / 'schema6-roundtrip-reset-01'
run.mkdir(exist_ok=False)
started = time.monotonic()
receipt = {'format':'schema6-roundtrip-audit-v1','stages':[],'formal_writes':False}
expected = '5c6d00ee6efa7506201bbef46ffd69bde49f7300c4697fe66036e87ace7ed4f0'
def remaining():
    value = 900 - (time.monotonic() - started)
    if value <= 0: raise TimeoutError('900 second isolated validation budget reached')
    return value
def stage(name):
    remaining(); receipt['stages'].append({'name':name,'elapsed':time.monotonic()-started})
    print(json.dumps(receipt['stages'][-1]),flush=True)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            remaining(); h.update(block)
    return h.hexdigest()
def copy_file(src,dst):
    assert src.is_file() and not src.is_symlink(), str(src)
    dst.parent.mkdir(parents=True,exist_ok=True)
    # macOS APFS copy-on-write copy, never a hard link or a symlink.
    subprocess.run(['/bin/cp','-c',str(src),str(dst)],check=True,timeout=remaining())
def source_code():
    return {str(p.relative_to(system)):sha(p) for p in (system/'review_desk').rglob('*')
            if p.is_file() and '__pycache__' not in p.parts and p.suffix in {'.py','.js','.css','.html'}}
def cli(instance,command):
    stage(command+' '+instance.name)
    env=os.environ.copy();env['PYTHONPATH']=str(system)
    with (run/(instance.name+'-'+command+'.log')).open('w') as log:
        child=subprocess.Popen([sys.executable,'-m','review_desk','--instance',str(instance),command],
            cwd=system,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            rc=child.wait(timeout=remaining())
            if rc: raise RuntimeError(f'{command} exited {rc}; see log')
        except BaseException:
            if child.poll() is None:
                os.killpg(child.pid,signal.SIGTERM)
                try: child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid,signal.SIGKILL);child.wait()
            raise
def ro(path):
    db=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True);db.execute('PRAGMA query_only=ON');return db
def table_rows(db,table):
    # Full raw physical rows, including encoded revision envelopes and evidence JSON.
    rows=db.execute('SELECT * FROM "'+table.replace('"','""')+'"').fetchall()
    return sorted(canonical(list(row)) for row in rows)
def rows_hash(rows):
    h=hashlib.sha256()
    for row in rows:h.update(row.encode());h.update(b'\n')
    return h.hexdigest()
def physical_snapshot(path):
    db=ro(path)
    try:
        names=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND (name NOT LIKE 'sqlite_%' OR name='sqlite_sequence') ORDER BY name")]
        result={}
        for name in names:
            remaining();rows=table_rows(db,name)
            result[name]={'rows':len(rows),'sha256':rows_hash(rows)}
        return result
    finally:db.close()
try:
    stage('preflight')
    guard=subprocess.run([sys.executable,'scripts/autonomous_optimization_guard.py','check'],
        cwd=task,capture_output=True,text=True,timeout=remaining())
    g=json.loads(guard.stdout);assert guard.returncode==0 and g['phase']=='armed' and g['watcher']['supervision_confirmed']
    receipt['guard']={'phase':g['phase'],'supervision_confirmed':True}  # no lease data
    assert sha(frozen)==expected
    code=source_code();receipt['system_head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=system,text=True).strip()
    receipt['source_code_sha256']=code;receipt['snapshot_sha256']=expected
    manifest=json.loads((original/'manifest.json').read_text());assert manifest['schema_version']==6
    src,dst=run/'source',run/'empty'
    copy_file(frozen,src/'.runtime/review.sqlite3')
    assert not (dst/'.runtime/review.sqlite3').exists() and not (dst/'production').exists()
    frozen_rows=physical_snapshot(frozen);source_initial=physical_snapshot(src/'.runtime/review.sqlite3')
    receipt['source_initial_all_tables']=source_initial
    assert source_initial==frozen_rows,'copied source rows differ before any candidate reads'
    for instance in (src,dst):copy_file(base/'preview/config/instance.json',instance/'config/instance.json')
    layout=base/'preview/config/entity-relationship-layout.json'
    if layout.exists():copy_file(layout,src/'config/entity-relationship-layout.json')
    # Copy only manifest-listed assets; never seed restored production archives.
    for name,expected_hash in manifest['files'].items():
        if name.startswith('assets/'):
            copy_file(original/name,src/'export'/name)
            assert sha(src/'export'/name)==expected_hash,name
    stage('real cached definition mutation isolation')
    store=Store(src/'.runtime/review.sqlite3')
    try:
        key=store.db.execute('SELECT definition_id FROM material_definition_versions ORDER BY material_id,number LIMIT 1').fetchone()[0]
        with production.read_scope(store):
            first=storage.expand(store,key);clean=canonical(first);second=storage.expand(store,key)
            def mutate(value):
                if isinstance(value,dict):
                    for child in value.values():
                        if mutate(child):return True
                    value['__local_isolation_probe__']='not saved';return True
                if isinstance(value,list):value.append({'__local_isolation_probe__':'not saved'});return True
                return False
            assert mutate(first)
            assert canonical(second)==clean and canonical(storage.expand(store,key))==clean
        assert not hasattr(store,'_production_reads')
        receipt['actual_definition_isolation']={'definition_id':key,'passed':True}
    finally:store.close()
    source_before_export=physical_snapshot(src/'.runtime/review.sqlite3')
    assert source_before_export==source_initial,'candidate read/mutation isolation changed stored rows'
    assert not (src/'production').exists(),'source production archives were unexpectedly seeded'
    receipt['source_before_export_all_tables']=source_before_export
    cli(src,'export')
    source_after_export=physical_snapshot(src/'.runtime/review.sqlite3')
    receipt['source_after_export_all_tables']=source_after_export
    assert source_after_export==source_before_export,'source export changed one or more stored tables'
    assert not (src/'production').exists(),'export unexpectedly wrote source production archives'
    fresh=json.loads((src/'export/manifest.json').read_text())
    assert fresh==manifest,'source export differs from frozen public baseline; inspect before proceeding'
    for name in ['manifest.json',*fresh['files']]:copy_file(src/'export'/name,dst/'export'/name)
    assert not (dst/'.runtime/review.sqlite3').exists() and not (dst/'production').exists()
    cli(dst,'restore')
    stage('raw tables and exact logical history')
    before,after=ro(frozen),ro(dst/'.runtime/review.sqlite3')
    try:
        names={r[0] for r in before.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        restored={r[0] for r in after.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
        assert names-{'generation_publications'}==restored
        receipt['tables']={}
        for name in sorted(restored):
            remaining();left,right=table_rows(before,name),table_rows(after,name);assert left==right,name
            receipt['tables'][name]={'rows':len(left),'sha256':rows_hash(left)}
        receipt['outside_public_contract']={'generation_publications':len(table_rows(before,'generation_publications'))}
        old_seq=dict(before.execute('SELECT name,seq FROM sqlite_sequence'))
        new_seq=dict(after.execute('SELECT name,seq FROM sqlite_sequence'))
        event_max={name:after.execute('SELECT max(id) FROM '+name).fetchone()[0] for name in ('comment_events','configuration_events')}
        assert new_seq==event_max,'fresh restore event sequence differs from imported maximum ID'
        receipt['event_sequence_counters']={'source':old_seq,'restored':new_seq,'imported_max_id':event_max,
            'equal_for_this_snapshot':old_seq==new_seq,'contract':'reconstructed SQLite counters; not serialized bundle rows'}
        for db in (before,after):
            assert db.execute('PRAGMA integrity_check').fetchall()==[('ok',)]
            assert db.execute('PRAGMA foreign_key_check').fetchall()==[]
    finally:before.close();after.close()
    left,right=Store(src/'.runtime/review.sqlite3'),Store(dst/'.runtime/review.sqlite3')
    try:
        with production.read_scope(left),production.read_scope(right):
            logical={row['id']:row['payload'] for row in left.db.execute('SELECT id,payload FROM revisions')}
            count=0
            for row in right.db.execute('SELECT id,payload FROM revisions'):
                remaining();assert logical.pop(row['id'])==row['payload'],row['id'];count+=1
            assert not logical;receipt['exact_logical_revision_payloads']=count
        # Use restored DB's active resolver to exercise PERF002, including historical recipes.
        with archives.read_scope(right):
            count=0
            for row in right.db.execute('SELECT path,container FROM material_archive_files ORDER BY path'):
                remaining();document=json.loads(row['container']);path=dst/row['path']
                assert path.resolve().is_relative_to(dst.resolve()) and path.is_file() and not path.is_symlink()
                raw=archives.read_bytes(path)
                assert len(raw)==document['bytes'] and hashlib.sha256(raw).hexdigest()==document['sha256'],row['path']
                count+=1
            receipt['historic_archive_original_hashes']=count
    finally:left.close();right.close()
    restored_before_export=physical_snapshot(dst/'.runtime/review.sqlite3')
    receipt['restored_before_export_all_tables']=restored_before_export
    cli(dst,'export')
    restored_after_export=physical_snapshot(dst/'.runtime/review.sqlite3')
    receipt['restored_after_export_all_tables']=restored_after_export
    assert restored_after_export==restored_before_export,'restored export changed stored rows'
    stage('deterministic bundle and source preservation')
    again=json.loads((dst/'export/manifest.json').read_text());assert again==fresh
    for name in ['manifest.json',*fresh['files']]:assert sha(src/'export'/name)==sha(dst/'export'/name),name
    receipt['deterministic_export_files']=len(fresh['files'])+1
    assert physical_snapshot(src/'.runtime/review.sqlite3')==source_initial,'source clone changed during later verification'
    assert sha(frozen)==expected and source_code()==code
    receipt['passed']=True
except BaseException as exc:
    receipt['passed']=False;receipt['error']=type(exc).__name__+': '+str(exc)
    raise
finally:
    receipt['elapsed_seconds']=time.monotonic()-started
    (run/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'passed':receipt.get('passed'),'receipt':str(run/'receipt.json'),'elapsed_seconds':receipt['elapsed_seconds']},ensure_ascii=False),flush=True)
