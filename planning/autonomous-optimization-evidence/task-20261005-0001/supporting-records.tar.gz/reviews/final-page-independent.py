#!/usr/bin/env python3
"""Offline audit of completed final page ABAB records; never opens HTTP, browser or DB.
Run only after the root has released the measurement window. No source mutation.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import subprocess
from urllib.parse import urlsplit, parse_qsl

ROOT = Path(__file__).resolve().parent.parent
PAGES = {'A1':'制作思路／故事创作','A2':'制作思路／生产制作','S1':'故事创作／故事采编',
         'S2':'故事创作／故事结构','S3':'故事创作／剧本创作','D1':'制作设定／制作拆解',
         'D2':'制作设定／实体管理','D3':'制作设定／素材管理','P1':'全剧制作／镜头制作',
         'P2':'全剧制作／组合与历史','C1':'系统管理／故事项目','C2':'系统管理／系统与 AI'}
PHASES = ['A1','B1','A2','B2']
PROBE_SHA = '74a80b7f730a450f4fc00f5424120f8f60406e7fe9c4c65234e3d317958a804c'
NAME = re.compile(r'(?P<page>A1|A2|S1|S2|S3|D1|D2|D3|P1|P2|C1|C2)-(?P<phase>A1|B1|A2|B2)-(?P<index>\d+)\.json$')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return sha(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())


def quantile(values, p):
    values=sorted(values);at=(len(values)-1)*p;lo=math.floor(at);hi=math.ceil(at)
    return values[lo]+(values[hi]-values[lo])*(at-lo)


def stats(values):
    if not values:return {'n':0,'raw_ms':[]}
    median=statistics.median(values);q1=quantile(values,.25);q3=quantile(values,.75)
    return {'n':len(values),'raw_ms':values,'median_ms':median,'mean_ms':statistics.mean(values),
            'min_ms':min(values),'max_ms':max(values),'q1_ms':q1,'q3_ms':q3,'iqr_ms':q3-q1,
            'mad_ms':statistics.median(abs(x-median) for x in values),'p95_ms':quantile(values,.95)}


def comparison(a,b):
    if not a['n'] or not b['n']:return {'verdict':'MISSING_SAMPLES'}
    delta=a['median_ms']-b['median_ms']
    threshold=max(a['iqr_ms'],b['iqr_ms'],3*a['mad_ms'],3*b['mad_ms'])
    separated=b['q3_ms']<a['q1_ms'] if delta>0 else a['q3_ms']<b['q1_ms']
    above=abs(delta)>threshold and separated
    return {'baseline_n':a['n'],'candidate_n':b['n'],'median_reduction_ms':delta,
            'typical_variation_threshold_ms':threshold,'iqr_separated':separated,
            'candidate_max_below_baseline_min':b['max_ms']<a['min_ms'],
            'exceeds_descriptive_rule':above,
            'verdict':'OBSERVED_IMPROVEMENT' if above and delta>0 else 'SLOWER_SIGNAL' if above else 'BENEFIT_NOT_ESTABLISHED'}


def git_identity(repository, revision):
    # Local read-only Git object access. These hashes describe the commit, not proof
    # that a running server loaded it: runtime metadata and root freeze receipts do that.
    try:
        commit=subprocess.check_output(['git','-C',str(repository),'rev-parse',revision+'^{commit}'],text=True).strip()
        tree=subprocess.check_output(['git','-C',str(repository),'rev-parse',commit+'^{tree}'],text=True).strip()
        listing=subprocess.check_output(['git','-C',str(repository),'ls-tree','-r','-z',commit,'--','review_desk'])
        files={}
        for row in listing.split(b'\0'):
            if not row:continue
            meta,name=row.split(b'\t',1);mode,kind,blob=meta.decode().split()
            files[name.decode()]={'mode':mode,'kind':kind,'git_blob':blob}
        return {'commit':commit,'tree':tree,'review_desk_files':files}
    except subprocess.CalledProcessError as e:
        return {'requested_revision':revision,'error':'local Git lookup failed','returncode':e.returncode}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,default=ROOT/'browser/final-page-abab-reset-01')
    parser.add_argument('--output-prefix',type=Path,default=Path(__file__).with_suffix(''))
    parser.add_argument('--baseline-commit',default='b874b959af9c918a482e8488dc25cb0204ab5772')
    parser.add_argument('--candidate-commit',default='3b20d609')
    parser.add_argument('--probe-sha',default=PROBE_SHA)
    args=parser.parse_args()
    if not args.input.is_dir():parser.error('completed input directory does not exist; do not audit an active window')
    output=args.output_prefix.resolve()
    if not output.is_relative_to(ROOT/'reviews'):parser.error('write only this reviewer reviews directory')
    data={phase:defaultdict(list) for phase in PHASES};issues=[];all_errors=[];input_hashes={};auxiliary=[]
    observed_env=defaultdict(list)
    def check(label,passed,path):
        if not passed:issues.append({'file':path,'check':label})
        return bool(passed)
    for path in sorted(args.input.glob('*.json')):
        match=NAME.fullmatch(path.name)
        if not match:
            auxiliary.append({'file':path.name,'sha256':sha(path.read_bytes()),'role':'auxiliary identity or other record; not implicitly treated as measurement'})
            continue
        page,phase,index=match['page'],match['phase'],int(match['index'])
        raw=path.read_bytes();input_hashes[path.name]=sha(raw);d=json.loads(raw)
        try:
            probe=d['probe'];sample=probe['samples'][-1];semantic=sample['semantic_at_ready'];scenario=d['scenario']
            nav=probe['navigation'][-1];browser=probe['browser'];metadata=probe['metadata']
            requests=probe.get('requests',[]);resources=probe.get('resources',[])
            checks={}
            checks['page_identity']=scenario['id']==page
            checks['phase_identity']=d.get('phase')==phase
            checks['index_identity']=d.get('index')==index
            checks['probe_identity']=metadata.get('probe_sha256')==args.probe_sha
            wanted=args.baseline_commit if phase.startswith('A') else args.candidate_commit
            checks['system_commit']=str(metadata.get('system_commit','')).startswith(wanted)
            checks['same_loopback_port']=metadata.get('port')==62606 and urlsplit(sample['end_url']).netloc=='127.0.0.1:62606'
            checks['expected_browser']=bool(re.search(r'Chrome/154\.',browser.get('user_agent','')))
            checks['expected_viewport']=browser.get('viewport')=={'width':1440,'height':900} and browser.get('device_pixel_ratio')==1
            checks['original_assertions']=bool(d.get('assertion')) and all(value is True for value in d['assertion'].values())
            checks['stable_completion']=sample['completion_reason']=='stable'
            checks['all_pending_clear']=not any(sample.get('pending_at_end',{}).values()) and not any(probe.get('pending',{}).values())
            checks['all_samples_no_errors']=all(s.get('request_error_count')==0 and not s.get('failed_requests') for s in probe['samples'])
            request_errors=[{'kind':'fetch','index':i,'record':r} for i,r in enumerate(requests) if r.get('error') or r.get('body_error') or r.get('status') is None or not 200<=r.get('status',0)<400]
            resource_errors=[{'kind':'resource','index':i,'record':r} for i,r in enumerate(resources) if isinstance(r.get('responseStatus'),(int,float)) and r['responseStatus']>=400]
            unreported_resources=[{'name':r.get('name'),'responseStatus':r.get('responseStatus')} for r in resources if r.get('responseStatus') in (None,0)]
            checks['all_request_statuses_success']=bool(requests) and not request_errors and all(r.get('method')=='GET' for r in requests)
            checks['resource_statuses_no_http_errors']=not resource_errors
            checks['navigation_success']=200<=nav.get('responseStatus',0)<400
            checks['foreground']=sample['visibility_at_start']==sample['visibility_at_end']==browser.get('visibility')=='visible'
            checks['selected_tab']=any(c.get('label')==scenario['tabLabel'] and c.get('selected')=='true' for c in semantic['controls'])
            checks['nonempty_expected_region']=any(v['id']==scenario['regionId'] and v['length']>0 for v in semantic['regions'])
            checks['comments_closed']=not any(v['id']=='comment-panel' for v in semantic['regions'])
            checks['semantic_timing_definition']=abs(sample['scenario_ready_ms']-(semantic['capture_finished_ms']-sample['start_ms']))<.01
            checks['navigation_type']=nav['type']==('navigate' if index==0 else 'reload')
            checks['monotonic_observation_bounds']=d['observation_start_epoch_ms']<=d['observation_end_epoch_ms']
            checks['same_semantic_end_url']=sample['end_url']==semantic['url']==probe['url']
            for label,passed in checks.items():check(label,passed,path.name)
            errors=request_errors+resource_errors
            if sample.get('failed_requests'):errors.append({'kind':'sample_failed_requests','record':sample['failed_requests']})
            if errors:all_errors.append({'file':path.name,'errors':errors})
            controls=[{k:c.get(k) for k in ('id','label','tag','value','pressed','selected','disabled')} for c in semantic['controls']]
            headings=[{k:h.get(k) for k in ('id','label','tag')} for h in semantic['headings']]
            content={'headings':headings,'controls':controls,'regions':semantic['regions']}
            version_signals={'url_parameters':{k:v for k,v in parse_qsl(urlsplit(sample['end_url']).query) if any(t in k for t in ('version','revision','source','script','episode','scene'))},'controls_with_values':[c for c in controls if c.get('value') is not None]}
            env={k:metadata.get(k) for k in ('instance','machine','python','port','probe_sha256')}
            env.update({k:browser.get(k) for k in ('user_agent','viewport','device_pixel_ratio')})
            observed_env[canonical(env)].append(path.name)
            row={'file':path.name,'sha256':input_hashes[path.name],'page':page,'phase':phase,'index':index,
                 'navigation_type':nav['type'],'scenario_ready_ms':sample['scenario_ready_ms'],
                 'stability_proxy_ms':sample['content_ready_ms'],'semantic_capture_ms':sample['semantic_capture_ms'],
                 'tool_upper_bound_ms':d['observation_end_epoch_ms']-d['observation_start_epoch_ms'],
                 'start_epoch_ms':d['observation_start_epoch_ms'],'end_epoch_ms':d['observation_end_epoch_ms'],
                 'browser_time_origin_epoch_ms':browser.get('time_origin'),'end_url':sample['end_url'],
                 'metadata':metadata,'environment':env,'semantic':content,'semantic_hash':canonical(content),
                 'version_signals':version_signals,'full_observation_sha256':sha(d.get('observation','').encode()),
                 'checks':checks,'requests':requests,'resource_status_unknown':unreported_resources,
                 'resource_http_statuses':dict(Counter(str(r.get('responseStatus')) for r in resources)),
                 'request_errors':errors,'longtasks':probe.get('longtasks',[])}
            if page=='C2' and requests and sample['start_ms']==0:
                first=min(r['start_ms'] for r in requests);last=sample['last_network_at_ms'];ready=sample['scenario_ready_ms']
                static=[r for r in resources if r.get('initiatorType') in ('script','link')]
                row['c2_intervals']={'navigation_to_first_fetch_ms':first,'first_fetch_to_last_body_ms':last-first,
                                    'last_body_to_semantic_ms':ready-last,'scenario_ready_ms':ready,
                                    'last_static_resource_end_ms':max((r['responseEnd'] for r in static),default=0)}
                row['c2_header_waits']=[{'url':r['url'],'status':r.get('status'),'wait_ms':r['headers_ms']-r['start_ms']} for r in requests if 'headers_ms' in r]
                row['c2_static_resources']=static
            data[phase][page].append(row)
        except (KeyError,IndexError,TypeError,ValueError) as error:
            issues.append({'file':path.name,'check':'schema_parse','error':str(error)})
    comparisons=[];phase_bounds={}
    for phase in PHASES:
        rows=[x for page in PAGES for x in data[phase][page]]
        if rows:phase_bounds[phase]={'start_epoch_ms':min(x['start_epoch_ms'] for x in rows),'end_epoch_ms':max(x['end_epoch_ms'] for x in rows)}
    for first,second in zip(PHASES,PHASES[1:]):
        check('phase windows ordered without overlap: '+first+' '+second,first in phase_bounds and second in phase_bounds and phase_bounds[first]['end_epoch_ms']<=phase_bounds[second]['start_epoch_ms'],'GLOBAL')
    check('identical environment including instance/browser/viewport/probe',len(observed_env)==1,'GLOBAL')
    for page,label in PAGES.items():
        result={'page':page,'label':label,'phases':{},'adjacent_pairs':{},'semantic_comparisons':[]}
        for phase in PHASES:
            rows=sorted(data[phase][page],key=lambda x:x['index']);data[phase][page]=rows
            indices=[r['index'] for r in rows]
            check('unique complete standard indices 0..4',len(indices)==len(set(indices)) and all(i in indices for i in range(5)),phase+'/'+page)
            check('only C2 may have extra repeat indices',page=='C2' or indices==list(range(5)),phase+'/'+page)
            groups={'navigate':[r for r in rows if r['navigation_type']=='navigate'],
                    'main_reload':[r for r in rows if 1<=r['index']<=4 and r['navigation_type']=='reload'],
                    'extra_reload':[r for r in rows if r['index']>=5 and r['navigation_type']=='reload'],
                    'all_reload':[r for r in rows if r['navigation_type']=='reload']}
            result['phases'][phase]={'samples':rows,**{k:stats([r['scenario_ready_ms'] for r in values]) for k,values in groups.items()}}
            check('same scenario semantic content within phase',len({r['semantic_hash'] for r in rows})<=1,phase+'/'+page)
        for a,b in [('A1','B1'),('A2','B2')]:
            groups={k:comparison(result['phases'][a][k],result['phases'][b][k]) for k in ('main_reload','extra_reload','all_reload')}
            groups['navigate']={'baseline':result['phases'][a]['navigate'],'candidate':result['phases'][b]['navigate'],'inference':'single navigate per phase; no cold-cache or repeated-navigate claim'}
            result['adjacent_pairs'][a+'-'+b]=groups
            by_index={r['index']:r for r in data[b][page]}
            for old in data[a][page]:
                new=by_index.get(old['index'])
                if new is None:continue
                result['semantic_comparisons'].append({'pair':a+'-'+b,'index':old['index'],
                    'same_url':old['end_url']==new['end_url'],'same_headings':old['semantic']['headings']==new['semantic']['headings'],
                    'same_controls':old['semantic']['controls']==new['semantic']['controls'],
                    'same_region_captures':old['semantic']['regions']==new['semantic']['regions'],
                    'same_version_signals':old['version_signals']==new['version_signals'],
                    'same_semantic_hash':old['semantic_hash']==new['semantic_hash'],
                    'same_full_observation':old['full_observation_sha256']==new['full_observation_sha256']})
        verdicts=[result['adjacent_pairs'][pair]['main_reload']['verdict'] for pair in ('A1-B1','A2-B2')]
        result['main_reload_verdict']='BOTH_ROUNDS_OBSERVED_IMPROVEMENT' if all(v=='OBSERVED_IMPROVEMENT' for v in verdicts) else 'SLOWER_SIGNAL_REQUIRES_EXPLANATION' if 'SLOWER_SIGNAL' in verdicts else 'REPEATABLE_PAGE_BENEFIT_NOT_ESTABLISHED'
        if page=='C2':
            result['decomposition']={}
            for phase in PHASES:
                result['decomposition'][phase]={}
                for group,predicate in [('main_reload',lambda r:1<=r['index']<=4),('extra_reload',lambda r:r['index']>=5),('all_reload',lambda r:r['index']>=1)]:
                    rows=[r for r in data[phase][page] if predicate(r) and r['navigation_type']=='reload' and 'c2_intervals' in r]
                    keys=rows[0]['c2_intervals'].keys() if rows else []
                    result['decomposition'][phase][group]={k:stats([r['c2_intervals'][k] for r in rows]) for k in keys}
        comparisons.append(result)
    semantic_differences=[{'page':r['page'],**v} for r in comparisons for v in r['semantic_comparisons'] if not all(v[k] for k in ('same_url','same_headings','same_controls','same_region_captures','same_version_signals','same_semantic_hash'))]
    report={'task_id':'task-20261005-0001','reviewer':'/root/reset_supervisor','at_utc':datetime.now(timezone.utc).isoformat(),
            'scope':'offline completed page records; no HTTP, browser or database activity','input_directory':str(args.input),
            'sample_files':len(input_hashes),'input_sha256':input_hashes,'auxiliary_files':auxiliary,
            'probe_sha256':args.probe_sha,'phase_order':PHASES,'phase_bounds':phase_bounds,
            'git_commit_identities':{'baseline':git_identity(ROOT/'system-worktree',args.baseline_commit),'candidate':git_identity(ROOT/'system-worktree',args.candidate_commit)},
            'environment_groups':dict(observed_env),'method':{'quantiles':'Type 7 linear interpolation at (n-1)*p, including P95; identical to prior page audit',
            'p95':'n=4 per standard reload cell is a descriptive near-maximum quantile, not production tail latency',
            'mad':'median absolute deviation from median, unscaled milliseconds',
            'comparison':'adjacent A1/B1 and A2/B2 separately; main indices1..4 separate from C2 extras; no pooled navigate/reload inference',
            'classification':'absolute median difference > max(both IQR widths, both 3*MAD), plus separated IQR; descriptive non-preregistered rule, not statistical significance'},
            'issues':issues,'all_request_errors':all_errors,'semantic_differences_requiring_explanation':semantic_differences,
            'comparisons':comparisons,'limitations':['Navigation type does not establish cold OS/HTTP caches.',
            'Semantic capture includes visible text/control snapshots, not paint, complete long-text content, decoding, occlusion or focus readiness.',
            'Per-navigation metadata labels and local Git object identities do not alone prove runtime loaded-code or frozen DB hashes; root phase identity receipts are required.',
            'Resource HTTP status 0/missing is recorded as unknown, not silently counted as a confirmed successful status.',
            'Full observation differences may include focus/wording; none are automatically normalized away.',
            'Request waits include queueing, connection, service and browser body work; overlapping request/resource durations cannot be summed.',
            'C2 disjoint interval mean differences can be added; medians and overlapping resource durations cannot.',
            'An empty Long Task list does not prove no main-thread work or dropped frames.',
            'These comments-closed measurements do not validate comment interaction latency or absent finished-media playback.']}
    output.with_suffix('.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    lines=['# 最终页面 ABAB 独立复算','','此报告由已完成记录离线生成；待审查者解释异常和内容变化后，才可作为最终结论。',
           f"读取 {report['sample_files']} 份样本。输入检查异常 {len(issues)} 项，请求错误记录 {len(all_errors)} 份，待解释语义差异 {len(semantic_differences)} 项。",'',
           '标准 reload 每阶段 index 1–4，navigate index 0 单列；C2 额外样本保存在 JSON 的 extra_reload/all_reload，不悄然扩大其他页面样本量。单位 ms。', '',
           '| 页面 | A1 reload n/中位/范围 | B1 | A2 | B2 | 分轮判断 |','| --- | --- | --- | --- | --- | --- |']
    for result in comparisons:
        cells=[]
        for phase in PHASES:
            s=result['phases'][phase]['main_reload'];cells.append(f"{s['n']} / {s['median_ms']:.2f} / {s['min_ms']:.2f}–{s['max_ms']:.2f}" if s['n'] else 'MISSING')
        lines.append('| '+result['page']+' '+result['label']+' | '+' | '.join(cells)+' | '+result['main_reload_verdict']+' |')
    lines+=['','每个原始数组、IQR/MAD/P95、首次 navigate、全部请求及错误、精确控件/版本和文件 SHA 在同名 JSON。','',
            '所有变慢信号保留；不得因页面未改就省略，也不得以 API 改善替代页面改善。样本范围、重复方向和数据/版本差异需人工回读。','',
            '输入检查异常：','```json',json.dumps(issues,ensure_ascii=False,indent=2),'```']
    output.with_name(output.name+'-tables').with_suffix('.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps({'samples':len(input_hashes),'issues':len(issues),'request_error_files':len(all_errors),'semantic_difference_items':len(semantic_differences),'output':str(output)},ensure_ascii=False))

if __name__=='__main__':main()
