#!/usr/bin/env python3
"""Offline independent audit of completed action evidence. Never HTTP, browser or DB."""
from pathlib import Path
import json,re,hashlib,statistics,math,time
from collections import defaultdict,Counter
from datetime import datetime,timezone
from urllib.parse import urlsplit,parse_qsl

ROOT=Path(__file__).resolve().parent.parent
INPUT=ROOT/'browser/final-action-abab-reset-01'
BACK=ROOT/'backend-investigation/action-final-abab'
OUT=Path(__file__).with_suffix('')
PHASES=['A1','B1','A2','B2','A3','B3']
A='b874b959af9c918a482e8488dc25cb0204ab5772'
B='3b20d609448365103ebcf381776e33869913fe8b'
PROBE='74a80b7f730a450f4fc00f5424120f8f60406e7fe9c4c65234e3d317958a804c'
GROUPS=[('A','制作思路页签','A2-tab','A1-tab'),('S1','故事来源版本','S1-novel9','S1-reset-novel8'),('S2','结构版本','S2-version10','S2-reset-version8'),('S3scene','剧本场次','S3-scene2','S3-reset-scene1'),('S3version','剧本版本','S3-version3','S3-reset-version4'),('S3episode','剧本集次','S3-episode2','S3-reset-episode1'),('D1','制作拆解场次','D1-scene2','D1-reset-scene1'),('D2','实体切换','D2-aheng','D2-reset-liji'),('D3filter','素材类型筛选','D3-video','D3-reset-all'),('D3page','素材列表翻页','D3-page2','D3-reset-page1'),('P1','镜头制作场次','P1-scene2','P1-reset-scene1'),('P2','组合历史记录按钮','P2-record2','P2-reset-record1'),('C','系统管理页签','C2-tab','C1-tab')]
IDS={d for g,l,f,r in GROUPS for d in (f,r)}
NORM=[('无生成结果（含历史版本）','未生成'),('有生成结果（含历史版本）','已生成'),('生成结果（含历史版本）','生成状态'),('有生成结果','已生成'),('无生成结果','未生成'),('有结果','已生成'),('无结果','未生成')]
NAME=re.compile(r'(.+)-(A1|B1|A2|B2|A3|B3)-(\d+)\.json$')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def canon(x):return sha(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode())
def norm(s):
 for a,b in NORM:s=s.replace(a,b)
 return s
def quant(v,p):
 v=sorted(v);n=(len(v)-1)*p;l=math.floor(n);h=math.ceil(n);return v[l]+(v[h]-v[l])*(n-l)
def stats(v):
 if not v:return {'n':0,'raw_ms':[]}
 m=statistics.median(v);q1=quant(v,.25);q3=quant(v,.75)
 return {'n':len(v),'raw_ms':v,'median_ms':m,'min_ms':min(v),'max_ms':max(v),'q1_ms':q1,'q3_ms':q3,'iqr_ms':q3-q1,'mad_ms':statistics.median(abs(x-m) for x in v),'p95_ms':quant(v,.95)}
def compare(a,b):
 delta=a['median_ms']-b['median_ms'];threshold=max(a['iqr_ms'],b['iqr_ms'],3*a['mad_ms'],3*b['mad_ms']);separate=(b['q3_ms']<a['q1_ms']) if delta>0 else (a['q3_ms']<b['q1_ms']);above=abs(delta)>threshold and separate
 return {'median_reduction_ms':delta,'variation_threshold_ms':threshold,'iqr_separated':separate,'full_ranges_separated':(b['max_ms']<a['min_ms']) if delta>0 else (a['max_ms']<b['min_ms']),'exceeds_descriptive_rule':above,'verdict':'OBSERVED_IMPROVEMENT' if above and delta>0 else 'SLOWER_SIGNAL' if above else 'BENEFIT_NOT_ESTABLISHED'}
def epoch(s):return datetime.fromisoformat(s.replace('Z','+00:00')).timestamp()*1000
checks=[];issues=[]
def check(label,passed,where):
 x={'check':label,'passed':bool(passed),'where':where};checks.append(x)
 if not passed:issues.append(x)
 return bool(passed)
started=time.monotonic();stage={};server_errors=[];http_total=0;commonidentities=defaultdict(list);phasebounds=[]
for phase in PHASES:
 p=BACK/phase;receipt=json.loads((p/'receipt.json').read_text());before=json.loads((p/'identity-before.json').read_text());after=json.loads((p/'identity-after.json').read_text());env=json.loads((p/'environment.json').read_text());proc=json.loads((p/'process.json').read_text());guard={k:json.loads((p/(k+'.json')).read_text()) for k in ('guard-before','guard-after')}
 http=[json.loads(x) for x in (p/'http.jsonl').read_text().splitlines() if x.strip()];http_total+=len(http);errs=[{'line':i+1,**r} for i,r in enumerate(http) if r.get('method')!='GET' or r.get('status')!=200 or r.get('error_type')]
 if errs:server_errors.append({'phase':phase,'errors':errs})
 expectedstage={'A3':'A2','B3':'B2'}.get(phase,phase)
 check('receipt and process same PID, own TERM15, no final error',receipt['pid']==proc['pid'] and receipt['stop_signal']==15 and not receipt.get('error') and not receipt.get('final_check_error'),phase)
 check('exact before/after identity unchanged',before==after and receipt['identity_unchanged'] is True,phase)
 check('expected code and clean product',before['system_commit']==env['system_commit']==(A if phase[0]=='A' else B) and not before['product_dirty'],phase)
 check('known original probe',before['probe_sha256']==env['probe_sha256']==PROBE,phase)
 check('adapter stage explicitly matches supplement',receipt['stage']==expectedstage and env['label']=='page-final-'+expectedstage,phase)
 check('loopback server port',receipt['port']==proc['port']==env['port']==62606,phase)
 check('all saved HTTP GET200 without server error',not errs,phase)
 for k,v in guard.items():check('guard armed, matching reset T0 and supervised '+k,v['phase']=='armed' and v['t0']==1791177710 and v['watcher']['supervision_confirmed'] is True and v['watcher']['lock_held'] is True and v['watcher']['running'] is True and v['watcher']['last_error'] is None,phase)
 stable={k:v for k,v in before.items() if k not in ('system_commit','product_tree_sha256')};commonidentities[canon(stable)].append(phase)
 stage[phase]={'receipt':receipt,'environment':env,'identity':before,'guards':guard,'http_count':len(http),'http_statuses':dict(Counter(str(x.get('status')) for x in http)),'http_errors':errs,'console_saved':(p/'console.txt').exists(),'evidence_sha256':{f.name:sha(f.read_bytes()) for f in sorted(p.iterdir()) if f.is_file()}}
 phasebounds.append((phase,epoch(receipt['started_at_utc']),epoch(receipt['finished_at_utc'])))
check('identical frozen DB, input metadata, instance, measurement code all phases',len(commonidentities)==1,'global')
check('phase receipt windows monotonic no overlap',all(a[2]<=b[1] for a,b in zip(phasebounds,phasebounds[1:])),'global')
incident=json.loads((INPUT/'record-label-incident.json').read_text());moved={x['next']:x for x in incident['moved']}
rows=[];aux=[];allfiles={};raw_by_file={};event_keys=defaultdict(list);requests={};resources={};envgroups=defaultdict(list);record_errors=[];content_groups=defaultdict(list)
for p in sorted(INPUT.glob('*.json')):
 raw=p.read_bytes();allfiles[p.name]=sha(raw);d=json.loads(raw);m=NAME.fullmatch(p.name)
 if not m or m[1] not in IDS:
  aux.append({'file':p.name,'sha256':allfiles[p.name],'keys':list(d)});continue
 id,phase,index=m[1],m[2],int(m[3]);probe=d['probe'];s=probe['samples'][-1];sem=s['semantic_at_ready'];browser=probe['browser'];meta=probe['metadata'];before=d['before'];exp=d['expected'];u=dict(parse_qsl(urlsplit(s['end_url']).query,keep_blank_values=True));raw_by_file[p.name]=d
 c={
 'identity':d['id']==id and d['index']==index,
 'phase':d['phase']==phase or (phase=='A2' and id.startswith(('D1-','D2-')) and d['phase']=='B1' and p.name in moved),
 'exact_stage_metadata':meta==stage[phase]['environment'],
 'original_assertions':bool(d['assertion']) and all(v is True for v in d['assertion'].values()),
 'viewport_browser':browser['viewport']=={'width':1440,'height':900} and browser['device_pixel_ratio']==1 and bool(re.search(r'Chrome/154\.',browser['user_agent'])),
 'foreground':s['visibility_at_start']==s['visibility_at_end']==browser['visibility']=='visible',
 'stable':s['completion_reason']=='stable',
 'no_errors_or_pending':not s['failed_requests'] and s['request_error_count']==0 and not any(s['pending_at_end'].values()) and not any(probe['pending'].values()),
 'all_cumulative_samples_no_errors':all(not x.get('failed_requests') and x['request_error_count']==0 for x in probe['samples']),
 'click_one_new_event':s['type']=='click' and len(probe['samples'])==before['sample_count']+1,
 'previous_sample_unchanged':before['last_sample']==probe['samples'][before['sample_count']-1],
 'exact_before_and_after_url':before['url']==s['start_url'] and s['end_url']==sem['url']==probe['url'],
 'action_changes_route':s['start_url']!=s['end_url'],
 'expected_params':all(u.get(k)==v for k,v in exp.get('params',{}).items()),
 'expected_controls':all(any(all(c.get(k)==v for k,v in e.items()) for c in sem['controls']) for e in exp.get('controls',[])),
 'expected_regions':all(any(r['id']==e['id'] and r['length']>0 and (not e.get('includes') or e['includes'] in r['first']+' '+r['last']) for r in sem['regions']) for e in exp.get('regions',[])),
 'time_definition':abs(s['scenario_ready_ms']-(sem['capture_finished_ms']-s['start_ms']))<.01,
 'within_observation':d['observation_start_epoch_ms']<=browser['time_origin']+s['start_ms']<=browser['time_origin']+sem['capture_finished_ms']<=d['observation_end_epoch_ms'],
 'within_server_stage':epoch(stage[phase]['receipt']['started_at_utc'])<=d['observation_start_epoch_ms']<=d['observation_end_epoch_ms']<=epoch(stage[phase]['receipt']['finished_at_utc'])+1000,
 }
 for k,v in c.items():check(k,v,p.name)
 errs=[]
 for r in probe['requests']:
  requests[canon([browser['time_origin'],r.get('start_ms'),r.get('url'),r.get('method')])]=r
  if r.get('error') or r.get('body_error') or r.get('status') is None or not 200<=r.get('status',0)<400 or r.get('method')!='GET':errs.append(r)
 for r in probe.get('resources',[]):resources[canon([browser['time_origin'],r.get('startTime'),r.get('name')])]=r
 check('all cumulative fetches GET success',not errs,p.name)
 if errs:record_errors.append({'file':p.name,'errors':errs})
 key=canon([browser['time_origin'],s['id'],s['start_ms']]);event_keys[key].append(p.name)
 env={k:meta[k] for k in ('instance','python','machine','probe_sha256','port')};env.update({k:browser[k] for k in ('user_agent','viewport','device_pixel_ratio')});envgroups[canon(env)].append(p.name)
 controls=[{k:x.get(k) for k in ('id','label','tag','value','pressed','selected','disabled')} for x in sem['controls']];headings=[{k:x.get(k) for k in ('id','label','tag')} for x in sem['headings']]
 content={'headings':headings,'controls':controls,'regions':sem['regions']}
 category='diagnostic_unpaired' if id.startswith(('D1-','D2-')) and phase=='A1' else 'formal' if index>0 else 'warmup'
 row={'file':p.name,'sha256':allfiles[p.name],'id':id,'phase':phase,'raw_phase':d['phase'],'index':index,'category':category,'scenario_ready_ms':s['scenario_ready_ms'],'content_ready_ms':s['content_ready_ms'],'semantic_capture_ms':s['semantic_capture_ms'],'tool_upper_ms':d['observation_end_epoch_ms']-d['observation_start_epoch_ms'],'observation_start_epoch_ms':d['observation_start_epoch_ms'],'observation_end_epoch_ms':d['observation_end_epoch_ms'],'start_url':s['start_url'],'end_url':s['end_url'],'target':s['target'],'expected':exp,'event_key':key,'sample_id':s['id'],'time_origin':browser['time_origin'],'semantic':content,'semantic_hash':canon(content),'observation_sha256':sha(d['observation'].encode()),'observation_normalized_sha256':sha(norm(d['observation']).encode()),'checks':c}
 rows.append(row);content_groups[id,phase].append(row)
check('same browser instance measurement environment',len(envgroups)==1,'global')
check('no duplicate last-event identity across saved standard records',all(len(v)==1 for v in event_keys.values()),'global')
check('exactly sixteen phase relabelled standard originals preserved',sum(r['phase']!=r['raw_phase'] for r in rows)==16,'global')
check('no unexpected formal phase/ID/index',all(r['phase'] in (['A1','A2','B2','A3','B3'] if r['id'].startswith(('D1-','D2-')) else ['A1','B1','A2','B2']) and r['index'] in range(4) for r in rows),'global')
comparisons=[];semantics=[];chains=[]
for group,label,fwd,rev in GROUPS:
 pairs=[('A2','B2'),('A3','B3')] if group in ('D1','D2') else [('A1','B1'),('A2','B2')]
 phases=[p for pair in pairs for p in pair]
 for id in (fwd,rev):
  r={'group':group,'label':label,'id':id,'direction':'forward' if id==fwd else 'return','phases':{},'pairs':{}}
  for phase in phases:
   rr=sorted(content_groups[id,phase],key=lambda r:r['index']);ii=[r['index'] for r in rr];wanted=[1,2,3] if id=='P2-record2' and phase=='B1' else [0,1,2,3]
   check('complete selected indices with only documented P2 special warmup',ii==wanted,id+'/'+phase)
   check('identical exact URL within cell',len({r['end_url'] for r in rr})==1,id+'/'+phase)
   check('identical semantic within cell',len({r['semantic_hash'] for r in rr})==1,id+'/'+phase)
   r['phases'][phase]={'formal':stats([r['scenario_ready_ms'] for r in rr if r['index']>0]),'warmup':stats([r['scenario_ready_ms'] for r in rr if r['index']==0]),'files':[r['file'] for r in rr]}
  for ap,bp in pairs:
   r['pairs'][ap+'-'+bp]=compare(r['phases'][ap]['formal'],r['phases'][bp]['formal'])
   for index in range(4):
    aa=next((x for x in content_groups[id,ap] if x['index']==index),None);bb=next((x for x in content_groups[id,bp] if x['index']==index),None)
    if aa and bb:
     semcmp={'id':id,'pair':ap+'-'+bp,'index':index,'before_url_equal':aa['start_url']==bb['start_url'],'after_url_equal':aa['end_url']==bb['end_url'],'target_equal':aa['target']==bb['target'],'raw_semantic_equal':aa['semantic_hash']==bb['semantic_hash'],'raw_observation_equal':aa['observation_sha256']==bb['observation_sha256'],'known_label_normalized_observation_equal':aa['observation_normalized_sha256']==bb['observation_normalized_sha256']};semantics.append(semcmp)
     check('same exact before/after routes and clicked target across pair',semcmp['before_url_equal'] and semcmp['after_url_equal'] and semcmp['target_equal'],id+'/'+ap+'-'+bp+'/'+str(index))
  vs=[v['verdict'] for v in r['pairs'].values()];r['verdict']='BOTH_ROUNDS_OBSERVED_IMPROVEMENT' if all(v=='OBSERVED_IMPROVEMENT' for v in vs) else 'SLOWER_SIGNAL_REQUIRES_EXPLANATION' if 'SLOWER_SIGNAL' in vs else 'REPEATABLE_BENEFIT_NOT_ESTABLISHED';comparisons.append(r)
 for phase in phases:
  for index in range(4):
   ff=next((r for r in content_groups[fwd,phase] if r['index']==index),None);rr=next((r for r in content_groups[rev,phase] if r['index']==index),None)
   if ff and rr:
    passed=ff['end_url']==rr['start_url'] and ff['start_url']==rr['end_url'] and ff['observation_end_epoch_ms']<=rr['observation_start_epoch_ms']
    check('forward return exact route chain and monotonic time',passed,group+'/'+phase+'/'+str(index));chains.append({'group':group,'phase':phase,'index':index,'passed':passed})
report={'reviewer':'/root/reset_supervisor','task':'task-20261005-0001','at_utc':datetime.now(timezone.utc).isoformat(),'scope':'offline only, no browser/http/database/new measurement','input_files_sha256':allfiles,'input_json_count':len(allfiles),'standard_record_count':len(rows),'category_counts':dict(Counter(r['category'] for r in rows)),'auxiliary':aux,'stage_evidence':stage,'common_identity_groups':dict(commonidentities),'server_http_count':http_total,'server_errors':server_errors,'browser_unique_cumulative_fetches':len(requests),'browser_fetch_statuses':dict(Counter(str(x.get('status')) for x in requests.values())),'browser_record_errors':record_errors,'resource_response_statuses':dict(Counter(str(x.get('responseStatus')) for x in resources.values())),'unique_resources':len(resources),'check_count':len(checks),'issues':issues,'checks':checks,'rows':rows,'comparisons':comparisons,'paired_semantics':semantics,'chain_checks':chains,'environment_groups':{k:len(v) for k,v in envgroups.items()},'raw_label_mismatches':[r['file'] for r in rows if r['raw_phase']!=r['phase']],'method':{'timing':'scenario_ready_ms = semantic.capture_finished_ms - trusted click start_ms; stable DOM/network proxy then semantic capture; excludes tools overhead; not paint/complete media decode','warmups':'each direction stage index0 excluded; B1 P2 missing standard before/expected record retained as special warmup only','formal':'index1..3 each direction and selected stage, two pairs independently, no direction pooling','quantile':'Type7 linear interpolation (n-1)*p; n3 P95 descriptive only','MAD':'unscaled median absolute deviation','rule':'abs median delta > max(AIQR,BIQR,3*AMAD,3*BMAD) and nonoverlapping IQR; descriptive heuristic not significance','known_label_normalization':NORM},'elapsed_seconds':time.monotonic()-started}
OUT.with_suffix('.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
lines=['# 交互独立复算原始统计表','','| 操作方向 | A 第一轮 | B 第一轮 | A 第二轮 | B 第二轮 | 第一轮/第二轮 |','| --- | --- | --- | --- | --- | --- |']
for r in comparisons:
 cells=[]
 for phase,p in r['phases'].items():
  s=p['formal'];cells.append(f"{phase}: {s['median_ms']:.2f} [{s['min_ms']:.2f}–{s['max_ms']:.2f}]")
 lines.append('| '+' | '.join([r['id']]+cells+[' / '.join(v['verdict'] for v in r['pairs'].values())])+' |')
OUT.with_name(OUT.name+'-tables.md').write_text('\n'.join(lines)+'\n')
print(json.dumps({'json_count':len(allfiles),'standard_records':len(rows),'categories':report['category_counts'],'checks':len(checks),'issues':issues,'unique_fetches':len(requests),'server_http_count':http_total,'raw_semantic_mismatches':sum(not x['raw_semantic_equal'] for x in semantics),'normalized_observation_mismatches':sum(not x['known_label_normalized_observation_equal'] for x in semantics),'verdicts':{r['id']:r['verdict'] for r in comparisons},'elapsed_seconds':report['elapsed_seconds']},ensure_ascii=False,indent=2))
