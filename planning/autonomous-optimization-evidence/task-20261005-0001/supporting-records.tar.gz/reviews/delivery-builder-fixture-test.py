#!/usr/bin/env python3
"""Bounded synthetic package test. No real runtime evidence or credentials read."""
import sys
sys.dont_write_bytecode = True
from pathlib import Path
import tempfile,importlib.util,json,hashlib,tarfile,time,shutil
from unittest.mock import patch
REAL = Path(__file__).resolve().parent.parent/'delivery/build_evidence.py'
OUT = Path(__file__).resolve().parent
checks=[]
def check(name, ok):
    checks.append({'name':name,'passed':bool(ok)})
    assert ok,name

def tree_hash(root):
    return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}

def archive_content(output, name):
    manifest=json.loads((output/'manifest.json').read_text())
    row=next(x for x in manifest['files'] if x['path']==name)
    with tarfile.open(output/row['archive']) as tar:return tar.extractfile(name).read()

start=time.monotonic()
with tempfile.TemporaryDirectory(prefix='delivery-synthetic-',dir=OUT) as temporary:
    workspace=Path(temporary).resolve();root=workspace/'.runtime/autonomous-optimization'
    (workspace/'planning').mkdir();(workspace/'planning/autonomous-optimization-run-report.md').write_text('Synthetic test only\n')
    (root/'delivery').mkdir(parents=True);script=root/'delivery/build_evidence.py';script.write_bytes(REAL.read_bytes())
    spec=importlib.util.spec_from_file_location('synthetic_builder',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    def put(name,data):
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data if isinstance(data,bytes) else data.encode());return p
    fake='synthetic-digest-not-a-real-lease'
    raw=json.dumps({'lease_digest':fake,'note':"{'lease_token': '[REDACTED]'}",'t0':123}).encode()
    put('state.json',raw);plain=b'{ "phase" : "synthetic" }\n';put('startup-recovery.json',plain)
    put('browser/ok.json','{"ready":true}\n');put('backend-investigation/guard.json',json.dumps({'lease_digest':fake,'event':2}));put('reviews/old.md','# Synthetic old\n')
    put('ux009-storage-fault/receipt.json','{"synthetic":true,"passed":true}\n')
    put('browser/hidden.db',b'SQLite format 3\0synthetic');put('browser/.env.local','not-real-secret=1');put('browser/node_modules/ignored.js','ignored');put('browser/cache.db-wal',b'fake-sidecar')
    (root/'run-baseline.json').symlink_to(root/'browser/ok.json')
    oldreport=root/'completed-window-01a10a82-adf0-7103-a834-c8dec2229ea8/run-report.md';oldreport.parent.mkdir();oldreport.symlink_to(root/'reviews/old.md')
    output=workspace/'evidence'/m.TASK_ID
    first,retained=m.build_evidence(workspace,output)
    check('first build publishes three archives and verified manifest',len(first['archives'])==3 and not retained)
    check('new UX009 directory is included',any(x['path']=='ux009-storage-fault/receipt.json' for x in first['files']))
    check('explicit supplements and old report symlinks excluded','run-baseline.json' in first['excluded'] and str(oldreport.relative_to(root)) in first['excluded'] and not any(x['path']=='clock/original-window-report.md' for x in first['files']))
    check('databases environment dependency and sidecars excluded',all(x in first['excluded'] for x in ['browser/hidden.db','browser/.env.local','browser/node_modules/ignored.js','browser/cache.db-wal']))
    clock=archive_content(output,'clock/state.json');parsed=json.loads(clock)
    check('one pass handles recursive and embedded textual credentials',parsed['lease_digest']=='[REDACTED]' and 'synthetic-inner' not in parsed['note'] and fake.encode() not in clock)
    transforms=[x for x in first['sanitized_sources'] if x['artifact']=='clock/state.json']
    check('one original-to-final clock transformation',len(transforms)==1 and transforms[0]['source']=='state.json' and transforms[0]['source_sha256']==hashlib.sha256(raw).hexdigest() and transforms[0]['artifact_sha256']==hashlib.sha256(clock).hexdigest())
    check('unmodified clock exact bytes and no false redaction',archive_content(output,'clock/startup-recovery.json')==plain and not any(x['artifact']=='clock/startup-recovery.json' for x in first['sanitized_sources']))
    check('all manifest paths retain source mapping',all(x.get('source') and x.get('source_sha256') for x in first['files']))
    initial_hash=tree_hash(output);same,_=m.build_evidence(workspace,output)
    check('identical input rebuild is byte deterministic',tree_hash(output)==initial_hash)
    (root/'reviews/old.md').unlink();put('reviews/new.md','# Synthetic replacement\n')
    second,_=m.build_evidence(workspace,output)
    check('second generation removes stale readable and archived document',not (output/'readable/reviews/old.md').exists() and (output/'readable/reviews/new.md').exists() and not any(x['path']=='reviews/old.md' for x in second['files']))
    stable=tree_hash(output)
    bad=put('browser/malformed.json','{invalid')
    try:m.build_evidence(workspace,output)
    except json.JSONDecodeError:pass
    else:raise AssertionError('malformed source should fail')
    bad.unlink();check('source failure preserves previous complete package',tree_hash(output)==stable)
    opaque=put('browser/opaque.bin',b'SQLite format 3\0synthetic')
    try:m.build_evidence(workspace,output)
    except ValueError as e:assert 'database magic' in str(e)
    else:raise AssertionError('database magic should fail')
    opaque.unlink();check('database magic rejects unknown extension before publication',tree_hash(output)==stable)
    original_write=m.write_bundle
    def corrupt(*args):
        manifest=original_write(*args);(args[0]/'readable/reviews/new.md').write_text('corrupted staging copy');return manifest
    with patch.object(m,'write_bundle',corrupt):
        try:m.build_evidence(workspace,output)
        except ValueError as e:assert 'readable differs' in str(e)
        else:raise AssertionError('staging mismatch should fail')
    check('staging verification failure preserves previous complete package',tree_hash(output)==stable)
    replace=m.os.replace
    def failing_publish(src,dst):
        if Path(src).name.startswith('.'+m.TASK_ID+'.staging-') and Path(dst)==output:raise OSError('synthetic publish failure')
        return replace(src,dst)
    with patch.object(m.os,'replace',failing_publish):
        try:m.build_evidence(workspace,output)
        except OSError as e:assert 'synthetic publish failure' in str(e)
        else:raise AssertionError('publication failure should fail')
    check('failed directory publication restores exact previous complete package',tree_hash(output)==stable)
    check('no abandoned staging or previous directory after handled failures',not list(output.parent.glob('.'+m.TASK_ID+'.*')))
    escaped=workspace/'.runtime/autonomous-optimization/reviews'/m.TASK_ID
    try:m.build_evidence(workspace,escaped)
    except ValueError:pass
    else:raise AssertionError('output inside runtime must fail')
    check('output cannot recurse into source evidence tree',not escaped.exists())
    m.verify_bundle(output,json.loads((output/'manifest.json').read_text()))
    check('final prior package still verifies',True)
result={'at_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),'scope':'synthetic fixture only, no real lease, evidence, database, browser or HTTP','script_sha256':hashlib.sha256(REAL.read_bytes()).hexdigest(),'passed':all(x['passed'] for x in checks),'checks':checks,'elapsed_seconds':time.monotonic()-start,'fixture_removed':not workspace.exists()}
(OUT/'delivery-builder-fixture-test.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
