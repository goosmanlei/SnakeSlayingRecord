#!/usr/bin/env python3
"""Create one consistent technical backup and two independent writable clones."""
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import time

BASE = Path(__file__).resolve().parent
RUNTIME = BASE.parent
sys.path.insert(0, str(RUNTIME / 'backend-investigation'))
from page_readonly_probe_server import guard, sha, canonical_sha, COMMITS

MARKER = 'task-20261005-0001-technical-readiness-v1'
ENTITY = 'technical-d2-object'
TEXT_PREFIX = '隔离技术性能样本 '


def comment_body(kind, index):
    return TEXT_PREFIX + kind + ' ' + str(index) + '：仅技术数据，不表示作品意见。'


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def files(root):
    result = []
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if '.runtime' in relative.parts:
            continue
        if path.is_symlink():
            raise ValueError('symlink input refused: ' + str(relative))
        if path.is_file():
            result.append({'path': relative.as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)})
    return result


def inventory(db):
    db.row_factory = sqlite3.Row
    result = {}
    for row in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"):
        name = row['name']
        if not name.replace('_', '').isalnum():
            raise ValueError('unexpected table identifier')
        rows = [dict(r) for r in db.execute('SELECT * FROM "' + name + '"')]
        rows.sort(key=lambda x: json.dumps(x, sort_keys=True, ensure_ascii=False))
        result[name] = rows
    return result


def inspect_snapshot(path, system):
    sys.path.insert(0, str(system))
    from review_desk.store import Store
    from review_desk.material_storage import row_factory
    from review_desk import generation
    store = Store.__new__(Store)
    store.db_path = path
    store.db = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
    store.db.execute('PRAGMA query_only=ON')
    store.db.row_factory = row_factory(store)
    try:
        state = generation.snapshot(store, ENTITY)
        return {'entity': {k: state['entity'].get(k) for k in ('object_id', 'id', 'version', 'kind')},
                'status': state['status'], 'acceptance_mode': state['acceptance_mode'],
                'can_accept': state['can_accept'], 'can_revoke': state['can_revoke'],
                'decision_version': state['decision_version'], 'scope': state['scope'],
                'decision_scope': state.get('decision_scope'), 'revoke_target': state.get('revoke_target'),
                'preparation_complete': state['preparation']['complete'],
                'generation_accepted': generation.accepted(store, ENTITY),
                'decision_id': generation.decision_id(ENTITY),
                'configurations': store.configurations(),
                'comment_target_validated': bool(store.validate_target(ENTITY, state['entity']['id'], {'type': 'global'}))}
    finally:
        store.close()


def main():
    safe_guard = guard()
    source = RUNTIME / 'technical-readiness/instance'
    if source.resolve() != source or (source / '.runtime').is_symlink():
        raise ValueError('source path is not ordinary')
    marker = json.loads((source / 'technical-fixture.json').read_text())
    if marker.get('marker') != MARKER or marker.get('synthetic_only') is not True:
        raise ValueError('technical-only marker missing')
    source_db = source / '.runtime/review.sqlite3'
    if source_db.is_symlink() or not source_db.is_file():
        raise ValueError('source database is not ordinary')
    targets = [BASE / 'snapshot/instance', BASE / 'A/instance', BASE / 'B/instance']
    if any(p.exists() for p in targets) or (BASE / 'preparation-receipt.json').exists():
        raise ValueError('fresh output required; existing evidence is never overwritten')
    started = time.monotonic()
    before_files = files(source)
    target = targets[0]
    (target / '.runtime').mkdir(parents=True)
    target_db = target / '.runtime/review.sqlite3'
    receipt = {'status': 'preparing', 'guard': safe_guard,
               'source': '../technical-readiness/instance', 'source_live_backup': True,
               'source_copy_method': 'read-only SQLite connection.backup to new ordinary database; no live-file copy',
               'source_files_before': before_files, 'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
    try:
        # BEGIN establishes one read snapshot. The backup API copies that same snapshot.
        with sqlite3.connect(source_db.as_uri() + '?mode=ro', uri=True, timeout=10) as src:
            src.execute('PRAGMA query_only=ON')
            src.execute('BEGIN')
            original = inventory(src)
            with sqlite3.connect(target_db) as dst:
                def progress(status, remaining, total):
                    if time.monotonic() - started > 30:
                        raise TimeoutError('technical backup preparation exceeded 30 seconds')
                src.backup(dst, pages=128, progress=progress, sleep=0.01)
                cloned = inventory(dst)
                if original != cloned or list(dst.execute('PRAGMA foreign_key_check')):
                    raise ValueError('backup logical equality or foreign keys failed')
            src.rollback()
        for item in before_files:
            rel = Path(item['path']); output = target / rel
            output.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source / rel, output)
        after_files = files(source)
        if before_files != after_files or files(target) != before_files:
            raise ValueError('source ordinary files changed during backup/copy')
        if any(r['id'] == ENTITY and r['kind'] == 'ENTITY' for r in original['objects']) is False:
            raise ValueError('synthetic ENTITY missing')
        state = inspect_snapshot(target_db, RUNTIME / 'system-worktree')
        if state['acceptance_mode'] != 'content' or state['preparation_complete'] or state['generation_accepted'] is not None:
            raise ValueError('fixture is not content-only without generation permission')
        if any(r['body'].startswith(TEXT_PREFIX) for r in original['comments']):
            raise ValueError('write-performance namespace already present')
        snapshot_sha = sha(target_db)
        save(BASE / 'snapshot-logical-before.json', original)
        clone_details = {}
        for phase, clone in zip(('A', 'B'), targets[1:]):
            shutil.copytree(target, clone)
            path = clone / '.runtime/review.sqlite3'
            if sha(path) != snapshot_sha or path.stat().st_ino == target_db.stat().st_ino:
                raise ValueError('clone is not byte-identical independent database')
            save(clone / 'ui-write-copy.json', {'marker': 'task-20261005-0001-ui-write-performance-v1',
                 'synthetic_only': True, 'phase': phase, 'snapshot_db_sha256': snapshot_sha,
                 'entity': ENTITY, 'comment_revision': state['entity']['id'], 'initial_state': state,
                 'allowed_project_field': 'audience', 'allowed_system_field': 'ai_context_max_chars'})
            clone_details[phase] = {'instance': str(clone.relative_to(BASE)), 'database_sha256': sha(path),
                                    'inode': path.stat().st_ino, 'system_commit': COMMITS[phase]}
        receipt.update(status='prepared', snapshot_db_sha256=snapshot_sha,
                       snapshot_logical_sha256=canonical_sha(original),
                       table_counts={k: len(v) for k,v in original.items()},
                       original_object_ids=[r['id'] for r in original['objects']],
                       source_files_after=after_files, source_files_unchanged=True,
                       initial_state=state, clones=clone_details)
    except BaseException as exc:
        receipt.update(status='failed', error=type(exc).__name__ + ': ' + str(exc))
        raise
    finally:
        receipt.update(finished_at_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                       elapsed_seconds=time.monotonic()-started)
        save(BASE / 'preparation-receipt.json', receipt)
    print(json.dumps({'status': receipt['status'], 'database_sha256': receipt['snapshot_db_sha256'],
                      'counts': receipt['table_counts'], 'initial_decision': {k: receipt['initial_state'][k]
                       for k in ('status','acceptance_mode','can_accept','can_revoke','decision_version','generation_accepted')}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
