#!/usr/bin/env python3
"""Serve only a prepared synthetic write clone with the unchanged browser probe."""
import argparse
import functools
import json
import os
from pathlib import Path
import re
import signal
import sqlite3
import subprocess
import sys
import time

from prepare import BASE, RUNTIME, ENTITY, TEXT_PREFIX, comment_body, files, inventory, inspect_snapshot, save, sha, guard, COMMITS
sys.path.insert(0, str(RUNTIME / 'backend-investigation'))
from page_readonly_probe_server import EXPECTED_PROBE, T0, canonical_sha


def read_rows(path):
    with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as db:
        db.execute('PRAGMA query_only=ON')
        return inventory(db)


def product_identity(system):
    commit = subprocess.check_output(['git', '-C', str(system), 'rev-parse', 'HEAD'], text=True, timeout=10).strip()
    dirty = subprocess.check_output(['git', '-C', str(system), 'status', '--porcelain', '--', 'review_desk'], text=True, timeout=10)
    rows = [(p.relative_to(system).as_posix(), sha(p)) for p in sorted((system / 'review_desk').rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc']
    return {'commit': commit, 'dirty': dirty, 'tree_sha256': canonical_sha(rows)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', required=True, choices=['A','B'])
    parser.add_argument('--candidate-commit', help='required exact clean final commit for B; baseline A remains fixed')
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--max-seconds', default=1800, type=int)
    args = parser.parse_args()
    if not 1 <= args.max_seconds <= 1800:
        parser.error('limit must be 1..1800 seconds')
    if args.phase == 'B' and not re.fullmatch(r'[0-9a-f]{40}', args.candidate_commit or ''):
        parser.error('B requires --candidate-commit with an explicit full final commit')
    expected_commit = COMMITS['A'] if args.phase == 'A' else args.candidate_commit
    output = args.output.absolute()
    if output.resolve() != output or BASE not in output.parents or output.exists():
        parser.error('output must be a new ordinary directory inside ui-write-performance')
    instance = BASE / args.phase / 'instance'
    dbpath = instance / '.runtime/review.sqlite3'
    snapshot = BASE / 'snapshot/instance/.runtime/review.sqlite3'
    for path in (BASE, instance, instance / '.runtime', dbpath, snapshot):
        if path.resolve() != path or path.is_symlink():
            raise ValueError('symlink task path refused')
    marker = json.loads((instance / 'ui-write-copy.json').read_text())
    if (marker.get('marker') != 'task-20261005-0001-ui-write-performance-v1'
            or not marker.get('synthetic_only') or marker['phase'] != args.phase
            or marker['entity'] != ENTITY or dbpath.stat().st_ino == snapshot.stat().st_ino
            or sha(dbpath) != marker['snapshot_db_sha256'] or sha(snapshot) != marker['snapshot_db_sha256']):
        raise ValueError('exact pristine independent technical clone required')
    system = RUNTIME / ('system-baseline' if args.phase == 'A' else 'system-worktree')
    code_before = product_identity(system)
    if code_before['dirty'] or code_before['commit'] != expected_commit:
        raise ValueError('exact clean product commit required')
    if sha(RUNTIME / 'backend-investigation/probe.js') != EXPECTED_PROBE:
        raise ValueError('original browser probe changed')
    before = read_rows(dbpath)
    expected_before = json.loads((BASE / 'snapshot-logical-before.json').read_text())
    if before != expected_before:
        raise ValueError('clone logical data differs from frozen technical input')
    safe_guard = guard()
    before_files = files(instance)
    if [item for item in before_files if item['path'] != 'ui-write-copy.json'] != files(BASE / 'snapshot/instance'):
        raise ValueError('clone config/source/original files differ from frozen input')
    output.mkdir(parents=True)
    save(output / 'guard-before.json', safe_guard)
    save(output / 'identity-before.json', {'code': code_before, 'database_sha256': sha(dbpath),
                                          'files': before_files, 'clone_inode': dbpath.stat().st_ino})
    sys.path.insert(0, str(system))
    from review_desk import server as product_server
    from review_desk import generation
    original_handler = product_server.ReviewHandler
    original_server = product_server.ReviewServer

    class RestrictedHandler(original_handler):
        def _input(self, *a, **kw):
            value = super()._input(*a, **kw)
            self._write_request = value
            if self.path == '/api/comments':
                if (value.get('target_object_id') != ENTITY or value.get('target_revision_id') != marker['comment_revision']
                        or value.get('anchor') != {'block_id': 'technical', 'end_block_id': 'technical', 'start': 0, 'end': 7, 'quote': '可丢弃技术验收'} or value.get('source_id') is not None
                        or value.get('material_context') is not None or value.get('material_revision') is not None
                        or value.get('body') not in [comment_body('评论',i) for i in range(4)]):
                    raise ValueError('only marked exact technical ENTITY exact text-anchor comments are permitted')
            elif self.path.startswith('/api/comments/'):
                comment_id = self.path.rsplit('/', 1)[-1]
                current = self.server.store.comment(comment_id)
                if (value.get('action') != 'EDIT' or not current or current['target_object_id'] != ENTITY
                        or current['target_revision_id'] != marker['comment_revision']
                        or not current['body'].startswith(TEXT_PREFIX) or value.get('body') not in [comment_body('编辑',i) for i in range(4)]):
                    raise ValueError('only this technical comment EDIT is permitted')
            elif self.path.startswith('/api/configurations/'):
                scope = self.path.rsplit('/',1)[-1]
                field = {'PROJECT':'audience','SYSTEM':'ai_context_max_chars'}[scope]
                current = self.server.store.configuration(scope)['body']
                updates = value.get('updates')
                if not isinstance(updates, dict) or set(updates)-set(current):
                    raise ValueError('unknown configuration field refused')
                changed = {key for key,val in updates.items() if current[key] != val}
                allowed = ([TEXT_PREFIX + '受众 ' + str(i) for i in range(4)] if scope == 'PROJECT'
                           else [12001,12002,12003,12004])
                if changed - {field} or updates.get(field) not in allowed:
                    raise ValueError('only the predeclared noncredential configuration field/value may change')
            elif self.path == '/api/production/entity-decision':
                if (value.get('entity_id') != ENTITY or value.get('action') not in ('accept','revoke')
                        or value.get('acceptance_mode') != 'content' or value.get('actor') != '用户'
                        or value.get('scope',{}).get('entity',{}).get('object_id') != ENTITY):
                    raise ValueError('only original UI technical content accept/revoke is permitted')
            else:
                raise ValueError('write path refused')
            return value

        def _json(self, value, status=200):
            if self.command in ('POST','PATCH'):
                self._write_response = value
            return super()._json(value, status)

        def do_POST(self):
            if self.path not in ('/api/comments','/api/production/entity-decision'):
                self.close_connection = True
                return self._json({'error':'technical write allowlist'},405)
            return super().do_POST()

        def do_PATCH(self):
            if (self.path not in ('/api/configurations/PROJECT','/api/configurations/SYSTEM')
                    and not self.path.startswith('/api/comments/')):
                self.close_connection = True
                return self._json({'error':'technical write allowlist'},405)
            return super().do_PATCH()

        def do_PUT(self):
            self.close_connection = True
            return self._json({'error':'technical write allowlist'},405)
        do_DELETE = do_PUT

    class RestrictedServer(original_server):
        def __init__(self, address, instance_root, config):
            # The original product initializes only this independent writable clone.
            super().__init__(address, instance_root, config)
            if read_rows(dbpath) != before:
                self.server_close()
                raise ValueError('product initialization changed existing logical rows')
            state = generation.snapshot(self.store, ENTITY)
            if state['acceptance_mode'] != 'content' or generation.accepted(self.store,ENTITY) is not None:
                self.server_close()
                raise ValueError('technical no-generation boundary changed')
            save(output / 'startup.json', {'logical_rows_unchanged':True,
                   'decision_version':state['decision_version'],'can_accept':state['can_accept'],
                   'can_revoke':state['can_revoke'],'acceptance_mode':state['acceptance_mode'],
                   'generation_accepted':None, 'database_sha256':sha(dbpath)})

        def serve_forever(self, *a, **kw):
            # Keep the original timing method intact. Audit JSON is appended only
            # after that method has stopped its stopwatch and appended its log.
            klass = self.RequestHandlerClass
            measured = klass._measured
            @functools.wraps(measured)
            def audited(handler, action):
                try:
                    return measured(handler, action)
                finally:
                    if handler.command in ('POST','PATCH','PUT','DELETE'):
                        value = {'at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
                                 'method':handler.command,'path':handler.path,
                                 'status':getattr(handler,'_probe_status',None),
                                 'request':getattr(handler,'_write_request',None),
                                 'response':getattr(handler,'_write_response',None),
                                 'actual_operator':'Codex technical performance operation; UI actor value is preserved, not user approval'}
                        with (output / 'write-audit.jsonl').open('a') as stream:
                            stream.write(json.dumps(value,ensure_ascii=False)+'\n')
            klass._measured = audited
            return super().serve_forever(*a, **kw)

    product_server.ReviewHandler, product_server.ReviewServer = RestrictedHandler, RestrictedServer
    import probe_server
    receipt = {'phase':args.phase,'pid':os.getpid(),'port':62610,
               'started_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
               'stop_signal':None,'error':None}
    save(output / 'process.json', receipt)
    def stop(signum, frame):
        receipt['stop_signal'] = signum
        raise KeyboardInterrupt
    for signum in (signal.SIGINT,signal.SIGTERM,signal.SIGALRM):
        signal.signal(signum, stop)
    signal.alarm(max(1,min(args.max_seconds,int(T0+9*3600-time.time()))))
    sys.argv = ['probe_server.py','--system',str(system),'--instance',str(instance),
                '--port','62610','--label','ui-write-'+args.phase,'--output',str(output)]
    try:
        probe_server.main()
    except KeyboardInterrupt:
        if receipt['stop_signal'] == signal.SIGALRM:
            receipt['error'] = 'phase deadline; incomplete samples must not be marked complete'
    except BaseException as exc:
        receipt['error'] = type(exc).__name__ + ': ' + str(exc)
        raise
    finally:
        signal.alarm(0)
        try:
            after = read_rows(dbpath)
            save(output / 'logical-after.json',after)
            save(output / 'technical-state-after.json', inspect_snapshot(dbpath, system))
            code_after, after_files = product_identity(system), files(instance)
            receipt.update(code_unchanged=code_after==code_before,files_unchanged=after_files==before_files,
                           snapshot_unchanged=sha(snapshot)==marker['snapshot_db_sha256'],
                           database_sha256_after=sha(dbpath))
            save(output / 'identity-after.json', {'code':code_after,'files':after_files})
            save(output / 'guard-after.json', guard())
        except BaseException as exc:
            receipt['final_check_error'] = type(exc).__name__ + ': ' + str(exc)
        receipt['finished_at_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
        save(output / 'receipt.json',receipt)


if __name__ == '__main__':
    main()
