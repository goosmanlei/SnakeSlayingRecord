#!/usr/bin/env python3
"""Offline history checks only after a write probe has stopped; no HTTP or DB opens."""
import argparse
import json
from pathlib import Path
from prepare import BASE, ENTITY, TEXT_PREFIX, comment_body, save, canonical_sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', required=True, type=Path)
    args = parser.parse_args()
    evidence = args.evidence.absolute()
    if evidence.resolve() != evidence or BASE not in evidence.parents:
        parser.error('ordinary task evidence path required')
    before = json.loads((BASE / 'snapshot-logical-before.json').read_text())
    prepared = json.loads((BASE / 'preparation-receipt.json').read_text())
    after = json.loads((evidence / 'logical-after.json').read_text())
    state = json.loads((evidence / 'technical-state-after.json').read_text())
    receipt = json.loads((evidence / 'receipt.json').read_text())
    calls = [json.loads(line) for line in (evidence / 'write-audit.jsonl').read_text().splitlines()]
    decision_id = prepared['initial_state']['decision_id']
    exact_revision = prepared['initial_state']['entity']['id']
    checks, failures = {}, []
    def check(name, condition):
        checks[name] = bool(condition)
        if not condition: failures.append(name)
    check('receipt_clean',receipt.get('error') is None and not receipt.get('final_check_error'))
    for key in ('code_unchanged','files_unchanged','snapshot_unchanged'):
        check(key, receipt.get(key) is True)
    for table,rows in before.items():
        kept = {canonical_sha(row) for row in after.get(table,[])}
        protected = [row for row in rows if not (table == 'objects' and row['id'] == decision_id)]
        check('old_rows_preserved:' + table, all(canonical_sha(row) in kept for row in protected))
    check('no_object_addition_or_removal', {r['id'] for r in before['objects']} == {r['id'] for r in after['objects']})
    old_revision_ids = {r['id'] for r in before['revisions']}
    new_revisions = [r for r in after['revisions'] if r['id'] not in old_revision_ids]
    check('only_eight_decision_revisions',len(new_revisions)==8 and all(r['object_id']==decision_id for r in new_revisions))
    check('decision_versions_5_to_12', sorted(r['version'] for r in new_revisions)==list(range(5,13)))
    new_ids = {r['id'] for r in new_revisions}
    old_deps = {canonical_sha(r) for r in before['dependencies']}
    check('new_dependencies_from_decisions_only',all(r['from_revision'] in new_ids for r in after['dependencies'] if canonical_sha(r) not in old_deps))
    mutable = {'objects','revisions','dependencies','material_content','comments','comment_events','configurations','configuration_events'}
    for table in set(before) | set(after):
        if table not in mutable:
            check('untouched_table:' + table,before.get(table)==after.get(table))
    comments = after['comments']; events = after['comment_events']
    check('four_exact_edited_comments', len(comments)==4 and all(r['target_object_id']==ENTITY and r['target_revision_id']==exact_revision
          and json.loads(r['anchor'])=={'block_id': 'technical', 'end_block_id': 'technical', 'start': 0, 'end': 7, 'quote': '可丢弃技术验收'} and r['version']==2 and r['status']=='OPEN' for r in comments))
    check('eight_comment_events',len(events)==8)
    check('exact_four_create_bodies',sorted(r['body'] for r in events if r['action']=='CREATE')==sorted(comment_body('评论',i) for i in range(4)))
    check('exact_four_edit_bodies',sorted(r['body'] for r in events if r['action']=='EDIT')==sorted(comment_body('编辑',i) for i in range(4)))
    for comment in comments:
        history = sorted([r for r in events if r['comment_id']==comment['id']], key=lambda r:r['id'])
        check('comment_history:' + comment['id'],len(history)==2 and [r['action'] for r in history]==['CREATE','EDIT']
              and all(r['body'].startswith(TEXT_PREFIX) for r in history) and history[-1]['body']==comment['body'])
    configurations = {r['scope']:r for r in after['configurations']}
    for scope,field,values in [('PROJECT','audience',[TEXT_PREFIX+'受众 '+str(i) for i in range(4)]),
                               ('SYSTEM','ai_context_max_chars',[12001,12002,12003,12004])]:
        history = sorted([r for r in after['configuration_events'] if r['scope']==scope],key=lambda r:r['version'])
        check('config_versions:' + scope,[r['version'] for r in history]==[1,2,3,4])
        bodies = [json.loads(r['body']) for r in history]
        initial_body = prepared['initial_state']['configurations'][scope]['body']
        check('exact_allowed_config_history:' + scope,bodies==[{**initial_body,field:value} for value in values])
        row = configurations.get(scope,{})
        check('config_current:' + scope,row.get('version')==4 and json.loads(row.get('body','{}'))=={**initial_body,field:values[-1]})
    expected = [('POST','/api/comments',201,4),('PATCH','/api/comments/',200,4),
                ('PATCH','/api/configurations/PROJECT',200,4),('PATCH','/api/configurations/SYSTEM',200,4),
                ('POST','/api/production/entity-decision',201,8)]
    for method,path,status,count in expected:
        selected=[c for c in calls if c['method']==method and (c['path'].startswith(path) if path.endswith('/') else c['path']==path) and c['status']==status]
        check('success_count:'+method+':'+path,len(selected)==count)
    check('no_unexplained_write_status',all(c['status'] in (200,201) for c in calls) and len(calls)==24)
    decisions = [c for c in calls if c['path']=='/api/production/entity-decision' and c['status']==201]
    check('accept_revoke_four_cycles',[c['request'].get('action') for c in decisions]==['accept','revoke']*4)
    check('content_only_original_UI_actor',all(c['request'].get('entity_id')==ENTITY and c['request'].get('acceptance_mode')=='content'
         and c['request'].get('actor')=='用户' for c in decisions))
    check('final_no_generation_permission',state.get('generation_accepted') is None and state.get('acceptance_mode')=='content'
          and not state.get('preparation_complete') and state.get('decision_version')==12 and state.get('can_accept') and not state.get('can_revoke'))
    result={'status':'passed' if not failures else 'incomplete_or_failed','checks':checks,'failures':failures,
            'counts_after':{k:len(v) for k,v in after.items()},'actual_operator':'Codex technical performance operation, not user approval',
            'UI_actor_preserved':'用户','all_source_history_preservation_scope':'raw old rows except the expected decision object current head; old decision revisions and dependencies retained',
            'scope_limit':'This offline audit does not replace visible browser write-after-read assertions or constitute timing evidence. Unexpected 409 is kept and flagged; existing independent conflict tests remain separate.'}
    save(evidence / 'history-audit.json',result)
    print(json.dumps({'status':result['status'],'failed_checks':failures,'checks':len(checks)},ensure_ascii=False))
    if failures: raise SystemExit(1)


if __name__ == '__main__':
    main()
