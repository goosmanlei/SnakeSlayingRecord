"""Create a fresh, marked fixture. Never remove or replace an existing instance."""
import argparse
import copy
import json
import shutil
import tempfile
from unittest.mock import patch
from fixture_tools import BASE, MARKER, SCOPE, NEED, EPISODE, ACTOR, dump, sha, exact, inspect
from test_production import ProductionTest
from test_structure import direction, document
from review_desk import production as p
from review_desk.screenplay import import_screenplay, snapshot
from review_desk.structure import select_direction, import_structure


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--name', default='instance'); args = parser.parse_args()
    if not args.name.replace('-', '').isalnum(): raise ValueError('simple new child name required')
    target = BASE / args.name
    if target.exists() or target.is_symlink(): raise FileExistsError('refusing to replace ' + str(target))
    factory = tempfile.TemporaryDirectory
    f = ProductionTest()
    with patch('test_production.tempfile.TemporaryDirectory', side_effect=lambda: factory(prefix='.build-', dir=BASE)):
        f.setUp()
    assert f.root.resolve().parent == BASE and f.root.name.startswith('.build-')
    try:
        inputs = []
        def put(*records):
            value = {'format': 'production-import-v1', 'records': list(records)}
            p.import_records(f.store, value, validate_only=True)
            result = p.import_records(f.store, value); inputs.append(value); return result
        source = direction('technical-source', '纯技术音频夹具依据')
        source.update(blocks=[{'id': 'summary', 'text': '仅验证一秒静音原件、准确版本和采用流程。'}], notes='可丢弃技术数据，无故事人物或作品评价')
        f.store.put_source(source)
        selected = select_direction(f.store, source['id'], 0)
        structure = document(selected['revision']); structure['title'] = '技术夹具结构（未确认）'
        for section in structure['sections']:
            section.pop('visuals', None)
            section['blocks'] = [{'id': section['id'] + '-technical', 'text': '技术测试说明；不包含故事创作。'}]
        structure_result = import_structure(f.store, structure, 0)
        script = {'format': 'screenplay-edition-v1', 'id': 'technical-script', 'title': '技术测试分集',
                  'notes': '隔离浏览器功能夹具，不是故事版本', 'review_status': 'pending', 'duration_kind': 'estimate',
                  'basis': {'story': exact(f.store, source['id']), 'structure': {'object_id': 'story-structure', 'revision_id': structure_result['revision']}},
                  'episodes': [{'id': EPISODE, 'number': 1, 'title': '技术分集一', 'estimated_seconds': 1,
                                'blocks': [{'id': 'tone', 'text': '播放一秒合成静音，检查准确文件引用。'}],
                                'scenes': [{'id': 'technical-scene-source', 'heading': '技术音频场', 'location': '测试台', 'time': '测试时', 'estimated_seconds': 1, 'block_ids': ['tone']}]}]}
        import_screenplay(f.store, script)
        source_ref = {**exact(f.store, EPISODE), 'scene_id': 'technical-scene-source', 'block_ids': ['tone']}
        put(f.spec(SCOPE, 'PREPARATION', source=source_ref, checked=True, occurrences=[], notes='隔离技术夹具；无人物状态要求'))
        need = f.requirement(NEED, SCOPE); need['payload']['title'] = '一秒技术音频槽位'
        put(need)
        # Reuse the existing local PCM helper; it performs no network/media generation.
        component = f.media()
        voice = p.record(f.store, 'voice'); first_payload = copy.deepcopy(voice['payload'])
        first_payload.update(title='技术静音原件 · 修订二（关联需求）', candidate_requirements=[exact(f.store, NEED)])
        put({'object_id': 'voice', 'kind': 'ASSET', 'expected_version': voice['version'], 'payload': first_payload})
        older = p.record(f.store, 'voice')
        next_payload = {**first_payload, 'title': '技术静音原件 · 修订三（元数据更新）'}
        put({'object_id': 'voice', 'kind': 'ASSET', 'expected_version': older['version'], 'payload': next_payload})
        baseline = inspect(f.store)
        assert len(snapshot(f.store)['versions']) == 1
        assert baseline['readiness']['required_count'] == 1 and baseline['readiness']['missing_count'] == 1
        assert not baseline['adoptions'] and not baseline['judgments'] and not baseline['foreign_key_check']
        marker = {'marker': MARKER, 'synthetic_only': True, 'operator': ACTOR, 'scope': SCOPE,
                  'requirement': NEED, 'episode': EPISODE, 'asset': 'voice', 'component': component,
                  'old_usable_revision': older['id'], 'current_revision': exact(f.store, 'voice')['revision_id'],
                  'constructor': 'ProductionTest.setUp/media/spec/requirement; unused constructor episode is retained',
                  'browser_url': 'http://127.0.0.1:62609/?workspace=production.workspace&production_tab=history&production_object=' + SCOPE}
        dump(f.root / 'technical-fixture.json', marker)
        # The CLI loads this before opening Store, unlike dictionary-mode ReviewServer.
        (f.root / 'config').mkdir(exist_ok=True)
        dump(f.root / 'config/instance.json', {'id': MARKER, 'title': '可丢弃技术采用与下载验收'})
        dump(f.root / 'build-inputs.json', {'source': source, 'structure': structure, 'screenplay': script, 'production_imports': inputs,
                                        'media_method': 'ProductionTest.media: local 48000 Hz mono 16-bit PCM silence, 48000 frames'})
        dump(f.root / 'baseline.json', baseline)
        f.store.close(); f.store = None
        shutil.copytree(f.root, target)
        dump(BASE / (args.name + '-build-receipt.json'), {'instance': args.name, 'database_sha256': sha(target / '.runtime/review.sqlite3'),
             'audio_sha256': sha(target / 'export/assets' / component['file']), 'baseline_adoptions': 0, 'baseline_judgments': 0,
             'scope': marker['scope'], 'old_usable_revision': marker['old_usable_revision'], 'current_revision': marker['current_revision']})
        print(json.dumps(marker, ensure_ascii=False, indent=2))
    finally:
        if f.store is not None: f.store.close()
        f.tmp.cleanup()


if __name__ == '__main__': main()
