"""Add five synthetic D2 records; never decide, generate, or replace history."""
import argparse
import copy
import hashlib
import json
import signal
import socket
import sqlite3
import subprocess
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

from fixture_tools import BASE, MARKER, instance_path, Store, p
from review_desk import generation as g

IDS = ('technical-d2-object', 'technical-d2-peer', 'technical-d2-state',
       'technical-d2-relation', 'technical-d2-need')
EPISODE = 'technical-script-e1'
LABELS = ('技术关联一', '技术关联二')


def stamp():
    return datetime.now(timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def signature(rows):
    return hashlib.sha256(canonical(rows).encode()).hexdigest()


def output_path(name):
    candidate = BASE / name
    if candidate.parent != BASE or candidate.name != name or candidate.exists() or candidate.is_symlink():
        raise ValueError('output must be a new filename in technical-readiness')
    return candidate


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def inventory(db):
    db.row_factory = sqlite3.Row
    names = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    tables = {}
    for name in names:
        if not name.replace('_', '').isalnum():
            raise ValueError('unexpected table name')
        rows = [dict(r) for r in db.execute('SELECT * FROM "' + name + '"')]
        rows.sort(key=canonical)
        tables[name] = rows
    return tables


def unchanged(before, after, changed_objects=()):
    for table, rows in before.items():
        current = {canonical(r) for r in after[table]}
        for row in rows:
            if table == 'objects' and row['id'] in changed_objects:
                continue
            if canonical(row) not in current:
                raise AssertionError('preexisting row changed: ' + table)


def summary(tables):
    return {'table_counts': {k: len(v) for k, v in tables.items()},
            'table_sha256': {k: signature(v) for k, v in tables.items()},
            'object_heads': tables['objects']}


def specification(oid, kind, title, **fields):
    return {'object_id': oid, 'kind': kind, 'expected_version': 0,
            'payload': {'format': 'production-' + p.KINDS[kind] + '-v1', 'title': title,
                        'blocks': [{'id': 'technical', 'text': '可丢弃技术验收；不是故事内容或作品采纳。'}], **fields}}


def batch_ref(oid):
    return {'object_id': oid, 'revision_id': '@' + oid}


def document(store):
    episode = p.record(store, EPISODE)
    if episode['kind'] != 'EPISODE' or not episode['payload']['title'].startswith('技术'):
        raise ValueError('expected synthetic source episode')
    source = {'object_id': EPISODE, 'revision_id': episode['id'],
              'scene_id': 'technical-scene-source', 'block_ids': ['tone']}
    p.source_check(store, source)
    records = []
    for oid, label in ((IDS[0], '纯技术测试物'), (IDS[1], '纯技术关联物')):
        records.append(specification(oid, 'ENTITY', label + '（可丢弃）', entity_type='prop',
                       subtype='hand_prop', aliases=[], facts=['只用于隔离界面技术验收'],
                       choices=[], unknowns=[], sources=[source], production_description=''))
    records.append(specification(IDS[2], 'STATE', '纯技术完整状态（可丢弃）',
                   entity=batch_ref(IDS[0]), state_model='complete-v1',
                   dimensions={'structure': '技术测试外形', 'condition': '初始技术状态',
                               'contents': '无故事内容', 'placement': '隔离测试台'},
                   reference_media='audio', sources=[source], facts=[], choices=[], unknowns=[],
                   production_description=''))
    records.append(specification(IDS[3], 'RELATION', '纯技术关系（可丢弃）',
                   relation_type='entity', entities=[batch_ref(IDS[1]), batch_ref(IDS[0])],
                   label=LABELS[0], direction='forward', category='use', basis='script',
                   sources=[source], applies_to=[source]))
    records.append(specification(IDS[4], 'REQUIREMENT', '纯技术未完成音频方案（可丢弃）',
                   scope=batch_ref(IDS[2]), slot='overall', required=True,
                   purpose='仅验证内容采纳不授予生成许可', media_type='audio', usage='post_audio',
                   entities=[batch_ref(IDS[0])], states=[batch_ref(IDS[2])],
                   specification={'reference_role': 'overall'}))
    return {'format': 'production-import-v1', 'expected_heads': {EPISODE: episode['id']}, 'records': records}


def check_stopped():
    with socket.socket() as sock:
        sock.settimeout(0.2)
        if sock.connect_ex(('127.0.0.1', 62609)) == 0:
            raise ValueError('stop this task technical service on 62609 before database writes')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--instance', required=True)
    parser.add_argument('--action', choices=['seed', 'advance-relation'], required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = output_path(args.output)
    root = instance_path(args.instance)
    if root != BASE / 'instance':
        raise ValueError('only the already marked technical-readiness/instance is allowed')
    marker = json.loads((root / 'technical-fixture.json').read_text())
    if marker.get('synthetic_only') is not True or marker.get('marker') != MARKER or marker.get('episode') != EPISODE:
        raise ValueError('synthetic marker scope differs')
    for child in (root / 'technical-fixture.json', root / 'config', root / 'config/instance.json'):
        if child.is_symlink():
            raise ValueError('symlink fixture configuration refused')
    check_stopped()
    task_root = BASE.parent.parent.parent
    guard = json.loads(subprocess.check_output(['python3', 'scripts/autonomous_optimization_guard.py', 'check'], cwd=task_root))
    if guard['phase'] != 'armed' or not guard['watcher']['supervision_confirmed'] or guard.get('stop'):
        raise ValueError('task guard not armed with confirmed supervision')
    path = root / '.runtime/review.sqlite3'
    with sqlite3.connect(path.resolve().as_uri() + '?mode=ro') as read:
        before = inventory(read)
        if list(read.execute('PRAGMA foreign_key_check')):
            raise ValueError('preexisting foreign key error')
    heads = {r['id']: r for r in before['objects']}
    for oid, kind in ((EPISODE, 'EPISODE'), ('technical-scene', 'PREPARATION'),
                      ('technical-audio-need', 'REQUIREMENT'), ('voice', 'ASSET')):
        if heads.get(oid, {}).get('kind') != kind:
            raise ValueError('original fixture object missing or kind changed: ' + oid)
    if args.action == 'seed' and any(oid in heads for oid in IDS):
        raise ValueError('all five new IDs must be absent; never overwrite partial work')
    before_path = output_path(output.stem + '-before.json')
    save(before_path, {'at': stamp(), 'action': args.action, 'instance': str(root.relative_to(task_root)),
                       'snapshot': summary(before), 'all_rows': before})
    receipt = {'started_at': stamp(), 'action': args.action, 'synthetic_only': True,
               'actor': 'Codex technical fixture; not user acceptance',
               'before_receipt': before_path.name, 'before': summary(before),
               'guard': {'phase': guard['phase'], 'observed_at': guard['observed_at']},
               'status': 'started'}
    started = time.monotonic()
    store = None
    try:
        signal.signal(signal.SIGALRM, lambda signum, frame: (_ for _ in ()).throw(TimeoutError('30 second bound')))
        signal.alarm(30)
        store = Store(path)
        if inventory(store.db) != before:
            raise AssertionError('Store initialization changed preexisting rows')
        if args.action == 'seed':
            payload = document(store)
        else:
            seed = json.loads((BASE / 'd2-seed-receipt.json').read_text())
            if seed.get('status') != 'passed' or seed.get('action') != 'seed':
                raise ValueError('successful original seed receipt required')
            allowed = {r['object_id']: r for r in seed['exact_added_records']}
            if set(allowed) != set(IDS):
                raise ValueError('seed whitelist differs')
            for oid in IDS:
                row = p.record(store, oid)
                if row['version'] != 1 or row['id'] != allowed[oid]['id']:
                    raise ValueError('technical record already changed: ' + oid)
            relation = p.record(store, IDS[3])
            if relation['kind'] != 'RELATION' or relation['payload'].get('relation_type') != 'entity' or relation['payload'].get('label') != LABELS[0]:
                raise ValueError('only original technical relationship label may change')
            value = copy.deepcopy(relation['payload']); value['label'] = LABELS[1]
            payload = {'format': 'production-import-v1',
                       'expected_heads': {oid: allowed[oid]['id'] for oid in IDS},
                       'records': [{'object_id': IDS[3], 'kind': 'RELATION', 'expected_version': 1, 'payload': value}]}
        receipt['input'] = payload
        receipt['validation'] = p.import_records(store, payload, validate_only=True)
        if inventory(store.db) != before:
            raise AssertionError('validate_only changed data')
        receipt['import'] = p.import_records(store, payload)
        after_import = inventory(store.db)
        unchanged(before, after_import, (IDS[3],) if args.action == 'advance-relation' else ())
        expected = set(IDS) if args.action == 'seed' else set()
        if {r['id'] for r in after_import['objects']} - set(heads) != expected:
            raise AssertionError('unexpected object additions')
        if args.action == 'seed':
            view = g.snapshot(store, IDS[0])
            receipt['entity_state'] = {key: view[key] for key in ['status', 'scope', 'acceptance_mode', 'can_accept', 'can_revoke', 'decision_version', 'preparation']}
            receipt['generation_acceptance'] = g.accepted(store, IDS[0])
            receipt['requirement_readiness'] = g.readiness(store, IDS[4])
            if view['acceptance_mode'] != 'content' or not view['can_accept'] or view['decision_version'] != 0 or view['preparation']['complete'] or receipt['generation_acceptance'] is not None or receipt['requirement_readiness']['ready']:
                raise AssertionError('fixture must allow content acceptance but no generation permission')
            receipt['exact_added_records'] = [p.record(store, oid) for oid in IDS]
        else:
            receipt['relation_after'] = p.record(store, IDS[3])
        after = inventory(store.db)
        if after != after_import:
            raise AssertionError('read-only verification changed records')
        for kind in ('CALL', 'ASSET', 'JUDGMENT'):
            if [r for r in after['objects'] if r['kind'] == kind] != [r for r in before['objects'] if r['kind'] == kind]:
                raise AssertionError('forbidden media/decision mutation')
        if list(store.db.execute('PRAGMA foreign_key_check')):
            raise AssertionError('foreign key error after import')
        receipt.update(status='passed', after=summary(after), original_rows_preserved=True,
                       validate_only_unchanged=True, verification_read_only=True,
                       foreign_key_check=[], no_recognition_or_media_call=True)
    except BaseException as exc:
        receipt.update(status='failed', error=repr(exc), traceback=traceback.format_exc())
        raise
    finally:
        signal.alarm(0)
        if store is not None:
            store.close()
        receipt.update(finished_at=stamp(), elapsed_seconds=time.monotonic()-started)
        save(output, receipt)
    print(json.dumps({'status': receipt['status'], 'action': args.action, 'receipt': str(output.relative_to(task_root)),
                      'elapsed_seconds': receipt['elapsed_seconds']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
