"""Only this task's disposable technical instances; no production paths."""
import copy
import hashlib
import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
SYSTEM = BASE.parent / 'system-worktree'
sys.path[:0] = [str(SYSTEM), str(SYSTEM / 'tests')]
from review_desk import production as p
from review_desk.store import Store

MARKER = 'task-20261005-0001-technical-readiness-v1'
SCOPE = 'technical-scene'
NEED = 'technical-audio-need'
EPISODE = 'technical-script-e1'
ACTOR = 'Codex technical fixture; not user acceptance'


def dump(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def instance_path(value):
    value = Path(value).absolute()
    resolved = value.resolve()
    if resolved.parent != BASE or resolved != value or value.is_symlink():
        raise ValueError('instance must be a direct nonsymlink child of technical-readiness')
    if json.loads((value / 'technical-fixture.json').read_text()).get('marker') != MARKER:
        raise ValueError('technical fixture marker missing')
    if (value / '.runtime').is_symlink() or (value / '.runtime/review.sqlite3').is_symlink():
        raise ValueError('symlink database refused')
    return value


def exact(store, oid):
    row = p.record(store, oid)
    return {'object_id': oid, 'revision_id': row['id']}


def adoption(store, revision, oid='technical-adoption', version=0):
    return {'object_id': oid, 'expected_version': version, 'payload': {
        'format': 'production-relation-v1', 'title': '技术音频采用（可丢弃）',
        'blocks': [{'id': 'adoption', 'text': '隔离技术验收，不是作品采用'}],
        'relation_type': 'adoption', 'scope': exact(store, SCOPE), 'slot': 'dialogue',
        'asset': {'object_id': 'voice', 'revision_id': revision}, 'component_id': 'original',
        'usage': 'post_audio', 'reason': '隔离技术验收，不是作品采用',
        'range': {'start_seconds': 0.1, 'end_seconds': 0.9}}}


def advance_upstream(store):
    current = p.record(store, EPISODE)
    if current['version'] != 1:
        raise ValueError('upstream already advanced; preserve existing history')
    if not p.readiness(store, SCOPE)['inputs_ready']:
        raise ValueError('perform technical adoption/package verification before upstream mutation')
    payload = copy.deepcopy(current['payload'])
    payload['title'] = '技术分集 · 仅标题修订二'
    deps = [dict(r) for r in store.db.execute('SELECT to_revision AS revision_id, role FROM dependencies WHERE from_revision=?', (current['id'],))]
    result = store.put_object(EPISODE, 'EPISODE', payload, expected_version=1, dependencies=deps)
    return {'old': {'object_id': EPISODE, 'revision_id': current['id']},
            'new': {'object_id': EPISODE, 'revision_id': result['revision']},
            'readiness': p.readiness(store, SCOPE)}


def inspect(store):
    return {'scope': exact(store, SCOPE), 'requirement': exact(store, NEED),
            'episode': exact(store, EPISODE), 'voice_history': p.snapshot(store, object_id='voice')['history'],
            'readiness': p.readiness(store, SCOPE),
            'adoptions': [r for r in p.current_records(store, {'RELATION'}) if r['payload'].get('relation_type') == 'adoption'],
            'judgments': p.current_records(store, {'JUDGMENT'}),
            'foreign_key_check': [list(r) for r in store.db.execute('PRAGMA foreign_key_check')]}
