"""Serve a marked technical fixture only; shutdown never deletes its evidence."""
import argparse
import json
from fixture_tools import instance_path, MARKER
from review_desk.server import ReviewServer

parser = argparse.ArgumentParser(); parser.add_argument('--instance', required=True); parser.add_argument('--port', type=int, default=62609)
args = parser.parse_args()
if args.port != 62609: raise ValueError('this fixture is assigned port 62609')
root = instance_path(args.instance)
with ReviewServer(('127.0.0.1', args.port), root, {'id': MARKER, 'title': '可丢弃技术采用与下载验收'}) as server:
    print(json.dumps({'instance': str(root), 'url': f'http://127.0.0.1:{args.port}', 'synthetic_only': True}), flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
