"""Snapshot or advance only a marked synthetic fixture; preflight uses a new copy."""
import argparse
import copy
import json
import shutil
from fixture_tools import BASE, SCOPE, ACTOR, dump, sha, instance_path, Store, p, adoption, advance_upstream, inspect
from review_desk.store import Conflict


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--instance', required=True)
    parser.add_argument('--action', choices=['inspect', 'advance-upstream', 'preflight'], default='inspect')
    parser.add_argument('--output', required=True); args = parser.parse_args()
    root = instance_path(args.instance); output = (BASE / args.output).resolve()
    if output.parent != BASE or output.exists(): raise ValueError('output must be a new file inside technical-readiness')
    source_sha = sha(root / '.runtime/review.sqlite3')
    if args.action == 'preflight':
        clone = BASE / 'preflight-instance'
        if clone.exists(): raise FileExistsError('preserve existing preflight; choose a fresh workspace for another run')
        shutil.copytree(root, clone); root = instance_path(clone)
    store = Store(root / '.runtime/review.sqlite3')
    try:
        if args.action == 'inspect': result = inspect(store)
        elif args.action == 'advance-upstream': result = advance_upstream(store)
        else:
            marker = json.loads((root / 'technical-fixture.json').read_text())
            old = marker['old_usable_revision']; current = marker['current_revision']
            request = adoption(store, old); p.adopt(store, request)
            first = inspect(store); assert first['readiness']['inputs_ready'] and first['readiness']['package_available']
            p.write_package(store, SCOPE, root / 'package-old')
            p.adopt(store, adoption(store, current, version=1))
            try: p.adopt(store, adoption(store, old, version=1))
            except Conflict as error: conflict = str(error)
            else: raise AssertionError('stale adoption unexpectedly committed')
            advanced = advance_upstream(store); changes = advanced['readiness']['requirements'][0]['pending_changes']
            assert changes, 'synthetic upstream change must be visible on readiness'
            change = changes[0]
            def decision(action, version):
                return {'object_id': 'technical-change-decision', 'expected_version': version, 'payload': {
                    'format': 'production-judgment-v1', 'title': '普通目标变更技术复核', 'blocks': [{'id': 'notes', 'text': '可丢弃技术判断'}],
                    'target': change['target'], 'verdict': 'impact_resolved', 'actor': ACTOR, 'reason': '技术验收；不评价故事作品',
                    'change': {'old': advanced['old'], 'new': advanced['new'], 'action': action}}}
            p.judge(store, decision('keep', 0)); after_keep = inspect(store)
            p.judge(store, decision('rework', 1)); after_rework = inspect(store)
            assert len(after_keep['readiness']['requirements'][0]['pending_changes']) == len(changes) - 1
            assert len(after_rework['readiness']['requirements'][0]['pending_changes']) == len(changes)
            try: p.judge(store, decision('replace', 1))
            except Conflict as error: judgment_conflict = str(error)
            else: raise AssertionError('stale judgment unexpectedly committed')
            assert [r['payload']['change']['action'] for r in p.snapshot(store, object_id='technical-change-decision')['history']] == ['rework', 'keep']
            original = instance_path(args.instance)
            assert sha(original / '.runtime/review.sqlite3') == source_sha
            result = {'technical_only': True, 'source_unchanged': True, 'adoption_request': request, 'after_old_adoption': first,
                      'adoption_conflict': conflict, 'upstream_change': advanced, 'after_keep': after_keep,
                      'after_rework': after_rework, 'judgment_conflict': judgment_conflict,
                      'adoption_history': p.snapshot(store, object_id='technical-adoption')['history'],
                      'judgment_history': p.snapshot(store, object_id='technical-change-decision')['history']}
        dump(output, result); print(str(output))
    finally: store.close()


if __name__ == '__main__': main()
